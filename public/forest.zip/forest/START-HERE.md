# Start here

This folder is forest, by k-d studio: a guided way from an idea to a shipped product, inside Claude Code.

1. **Rename this folder** after your idea, if you haven't already.
2. **Open it in Claude Code** — in the Claude app, or by running `claude` inside it in Terminal.
3. **Say yes when Claude Code asks whether you trust the folder.** It asks that the first time you open any folder.
4. **Type `/pack`.**

That's it. `/pack` asks who you are, who this is for and what you're making, then sets the project up around you. From then on, open the same folder and type `/trail` to carry on.

The folder looks almost empty because forest lives in a hidden folder called `.claude`. Claude Code sees it; you never need to open it. Everything forest writes for you goes in `project/`, and the product you build goes in `app/`.

`README.md` has the full picture. `BUILDING.md` is for when you hand the brief to whoever builds it.
