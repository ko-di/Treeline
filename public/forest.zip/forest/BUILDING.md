# Building from the brief

The kit's output is a brief, not a build. This is how you take it somewhere that builds.

By the time Camp 5 opens you have 7 or 8 files written at different times for different readers. No build tool, human or otherwise, should be handed that pile. `/camp build` compiles them into one file, `project/BRIEF.md`, that stands on its own.

**`project/BRIEF.md` is the thing you hand over.** Everything else is supporting material you attach when asked.

## What's in the folder

| File | What it's for | Send it? |
|---|---|---|
| `project/BRIEF.md` | The compiled brief: scope, phases, feel, decisions, what's still open | Always |
| `project/design/design.md` | Tokens, type scale, components, states, in [Google's design.md format](https://github.com/google-labs-code/design.md) | If there's an interface |
| `project/3-decide/prd.md` | The full requirements, longer than the brief's summary | If they ask for detail |
| `project/decisions/*.md` | Why each call was made | If someone questions a decision |
| `project/compass.json` | The structured record, machine-readable | Rarely; the brief covers it |
| `project/EVIDENCE.md` | What you know and how you know it, written for an outsider | If they challenge the premise, or to an investor |
| `project/2-learn/synthesis.md`, `weather.md` | The research in full, and the working record behind `project/EVIDENCE.md` | If they want the detail underneath |

Don't send `project/research/` to anyone outside the project. It has real people's words in it.

## Getting the brief early

You don't have to reach Camp 5. Ask at any point:

> compile the brief

`/camp build` will write `project/BRIEF.md` from whatever exists and tell you which parts are thin. A brief compiled at Camp 3 is missing its design section and says so. That's often exactly what you want before commissioning design work.

## Claude Code, in the same folder

The simplest path, and the one the kit is shaped for. The files are already there, so there's nothing to attach. Type:

```
/camp build
```

It reads the phases in `project/map.md` and starts at the first one not ticked. It asks whether you want them one at a time or straight through. Then for each phase it reads the requirement in the PRD and builds it. It reviews it with `/review` and tests it with `/test`. It compares the result against `project/design/design.md`, commits, and ticks the phase.

It stops when a phase needs a decision the brief does not answer. Or when the review turns up something that changes a later phase. Or when a library or schema change would be needed that nobody agreed to. It never pushes.

If you would rather drive it by hand:

```
Read project/BRIEF.md and project/design/design.md. Build phase 1.
Use the tokens as written. Ask before adding any library.
```

## Claude in the browser, or Claude Design

For when you want to explore an interface before committing to code.

Attach `project/BRIEF.md` and `design.md`. Then:

```
Here's the brief and the design system for a [platform].
Build phase 1 as an 'artifact'. Use the tokens in design.md exactly.
They came from references the client chose, not from your defaults.
Don't add features that aren't in the Scope: In list.
```

Keep the last line. Scope creep in generated interfaces is usually additive and usually plausible, so it is hard to spot. Your `Out` list is the check against it, which is why the brief carries it verbatim.

## v0, Lovable, Bolt, Figma Make

These want a shorter prompt than a document. Paste the brief's first 3 sections, the one-liner, What this is for, and Scope, then the phase you want:

```
[paste: one-liner, What this is for, Scope]

Build this, phase 1 only:
[paste: Phase 1 from the brief]

Visual direction: [paste: How it should feel]
```

Attach `design.md` if the tool takes files. It is a published format, so a tool that knows it will read the tokens directly. If it doesn't take files, paste the YAML front matter. Those tokens carry the identity, and generated defaults will otherwise take over.

## A developer or an agency

Send `project/BRIEF.md`, `design.md` and `prd.md`. Point them at the Decisions already made section before they start. It exists so you don't re-argue things you settled weeks ago with someone who wasn't there.

If they're picking up a client project, run `/handoff` instead. It packages all of this properly, verifies access transfers, and names what's deliberately missing.

## When what comes back isn't what you wanted

Normal. Work through it in this order, because the first 2 are cheap and the third is not.

**1. Check the brief, not the tool.** Open `project/BRIEF.md` and find the section that should have prevented it. Usually one of:

- The thing you didn't want is in `Scope: In` because the PRD was loose
- `How it should feel` says something that fits anything, such as "clean", "modern" or "minimal"
- `feeling.antiPatterns` is empty, so nothing said what it must never look like
- A phase says "done when: it works" instead of naming something observable

Fix the brief and rebuild. A vague brief produces a plausible wrong answer. Asking again with the same brief produces a different plausible wrong answer.

**2. Check it against the design.** If the brief was right, the drift is in the build:

```
Compare this against project/design/design.md. List every divergence:
tokens, type scale, component states, spacing. Don't fix anything yet.
```

Then decide each one. Sometimes the build is better than the design, in which case update `design.md` to match. Do not leave a divergence unnamed. That is how a design system ends up unused.

**3. If the shape itself is wrong**, that's a Camp 4 problem, not a build problem. Go back: `/camp shape`. Regenerating from the same design with a different tool will produce the same shape in a different accent colour.

**Record the call.** If it was a real decision, `/rationale` files it. The next person to ask why the dashboard works that way may well be you.

## Projects with no interface

A CLI, a newsletter, a service, an API, something physical. `/sketch` detects this from `project/compass.json.product.platform` and does voice and identity instead of tokens, so `design.md` will have a Voice section and no token tables.

The brief works the same way. Send `project/BRIEF.md` on its own, and lean on How it should feel. For these projects it carries the whole identity, because there is nothing to look at that could carry it instead.

## After it's built

Back to the trail. `/trail` closes Camp 5 and moves to Camp 6, where `/ship` runs the checks and pushes, and `/summit` verifies what actually went live.

The build happening somewhere else doesn't take the project out of the kit. Tick the phases in `project/map.md` as they land and the trail carries on from where you left it.
