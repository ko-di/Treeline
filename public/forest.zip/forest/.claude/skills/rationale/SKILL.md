---
name: rationale
description: |
  Capture the WHY behind a single decision. Writes one file to
  project/decisions/[date]-[topic].md with the decision, the
  alternatives considered, and the reasoning. Use when the user
  says: "rationale", "capture this", "document this", "why did we",
  "decision", "log this", or after a non-trivial choice in any camp.
user-invocable: true
---

# /rationale — capture the why

## Voice

You are a careful witness. You record what was decided, what was considered, and what was reasoned — without adding gloss. Future-you will thank present-you for this.

## What this skill does

`/rationale` writes one file per significant decision. The file lives at `project/decisions/[YYYY-MM-DD]-[short-topic].md`. The decision is the artifact; the file is the receipt.

It is a **single-decision command**. One decision per invocation. If the user has three decisions to capture, run `/rationale` three times.

It does not auto-trigger. The user invokes it when they want a decision recorded. (Skills like `/sketch` or `/scout` may *suggest* `/rationale` — they don't run it.)

## Read first

1. [`../../forest/references/QUESTIONING.md`](../../forest/references/QUESTIONING.md) — the conversation to capture a decision is short, structured, and uses Open + Guided modes.
2. [`../../forest/references/TEXTURE.md`](../../forest/references/TEXTURE.md) — the "Decision filed" texture moment.
3. The current `project/compass.json` — for context about what's being decided about.
4. `project/decisions/` — to avoid duplicate filenames.
5. `.forest/role.md` — the user's help style, which sets how much scaffolding every question carries.

## Flow

### 1. Open with the decision

Single Open question:

> **What's the decision, in one sentence?**
> *Why I'm asking:* in three months you'll remember what you chose but not why. This is the bit that fades.

The user types one sentence. Echo briefly:

> *"Got it — [restated decision]. Capturing."*

If the answer isn't actually a decision (e.g., a question, a problem, a feature idea): challenge once.

> *"That reads more like a [question / problem / idea]. A decision has a command and a chosen path. Try again — what specifically did you choose?"*

If the user can't sharpen: file it anyway as *"Open question — to be decided"* with a note. Don't refuse to capture.

### 2. Capture alternatives

Single Open or Guided question depending on style mode:

> **What else did you consider? List them. One line each.**

The user lists. If they say *"nothing else, this was the only option"*: that itself is a decision worth recording.

> *"Got it — no alternatives considered. Filing that explicitly."*

If they list 1–3 alternatives, capture them.

### 3. Capture the reasoning

Single Open question:

> **Why this and not the others? One paragraph.**

The user writes. No suggestions — the reasoning has to be theirs.

If the user writes a single sentence: that's enough. If they write a wall of text: that's also fine. The kit captures what the user gives it.

### 4. Capture the cost

Optional but valuable. Use Branch mode:

> **Does this decision close a door?**
> *Why I'm asking:* the ones that are hard to undo are worth more thought than the ones that aren't. "No" is a perfectly common answer.
> **A. Yes** — name what's now off the table because of this choice.
> **B. No** — this is reversible if it turns out wrong.
> **C. Skip** — file without this section.

If A: capture what's foreclosed.
If B: capture as *"Reversible — can revisit at [trigger condition or time]."*
If C: skip.

### 5. Generate the filename

Format: `[YYYY-MM-DD]-[short-topic].md`

- Date: today, ISO 8601, in the user's local timezone.
- Topic: 2–4 lowercase words, hyphens between them, derived from the decision sentence. Strip articles and filler.
  - *"We chose Next.js over SvelteKit."* → `2026-04-30-stack-choice.md`
  - *"Drop the second user persona — only build for solo instructors."* → `2026-04-30-narrow-audience.md`
  - *"Use Sanity for the CMS."* → `2026-04-30-cms.md`

If a file with the same name already exists: append `-2`, `-3`, etc. Do not overwrite.

### 6. Write the file

Format:

```markdown
# [Decision sentence — verbatim from the user]

**Date:** [YYYY-MM-DD]
**Camp:** [current camp from project/map.md]
**Status:** Filed

## What was chosen
[The decision, in one paragraph if needed]

## Alternatives considered
[List, one per line. Or "None considered — only option."]

## Reasoning
[The user's reasoning, verbatim]

## What this closes
[If captured in Beat 4. Otherwise omit this section.]

## Reversibility
[Reversible / not reversible / unknown]
```

No commentary. No editorialising. The file is what was said.

### 7. Index in `project/map.md`

Open `project/map.md`, scroll to the **Decisions** section at the bottom. Add one line in the format the existing decisions use:

```
- 2026-04-30 — [short topic phrase] — [filename as relative link]
```

If the timeline mermaid block is present, also append the decision to the timeline. (One line, no rationale — the rationale is in the file.)

### 8. Texture moment

Per `TEXTURE.md`, render the "Decision filed" texture:

```
Decision filed at project/decisions/2026-04-30-stack-choice.md.
```

One line. No flourish. The file is the acknowledgment.

## Outputs

| File | What it contains |
|---|---|
| `project/decisions/[date]-[topic].md` | The full decision record |
| `project/map.md` | One new line in Decisions index, optional timeline append |

## Anti-patterns

- Capturing more than one decision per invocation. If the user runs `/rationale` and starts naming three decisions, capture the first one and tell them to run `/rationale` again for each subsequent decision.
- Editorialising the decision. The kit does not say *"smart choice"* or *"sound reasoning."* It records what was said.
- Generating the reasoning. The reasoning has to come from the user. If they don't have one, the file says so: *"Reasoning: gut decision — no formal reasoning recorded."*
- Overwriting an existing file with the same date and topic. Append `-2`, `-3`, etc.
- Suggesting a different decision. The kit captures decisions; it does not lobby for alternatives. If the user asks *"is this a good decision?"* — that's a different conversation, not `/rationale`.

## When `/rationale` is not the right skill

- The user wants to walk through trade-offs before deciding → that's a regular conversation in the relevant camp's working skill (`/scout`, `/sketch`, etc.).
- The user wants to capture a research insight → `/gather`.
- The user wants to document the design system → `/sketch` writes design.md.
- The user wants to retrospect at trail end → `/retro`.
