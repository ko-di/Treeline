# Polish — the last details

The final pass before shipping. Grounded in *Verification Before Delivery* in [`DESIGN.md`](../../../forest/taste/DESIGN.md) and the transition rules in [`MOTION.md`](../../../forest/taste/MOTION.md).

## The six tests

Run the work through these before listing details:

1. **Substitution.** Swap the layout for a generic template in your mind. If nothing of value is lost, the work was generic.
2. **Hierarchy.** Defocus. Does the priority order survive as pure tonal weight?
3. **Intent.** Can every formal decision be traced to the stated direction in `project/design/design.md`? Where the thread breaks, convention took over.
4. **Clarity.** Would a first-time viewer find every important action without instruction?
5. **Economy.** Can anything be removed without reducing comprehension? Then flag it.
6. **Necessity.** Does the result feel like the only possible solution to this problem?

## Look for

### Details
- Interactive elements without transitions on hover and focus
- Transition durations inconsistent across similar interactions
- Border weights varying without reason
- Radius inconsistent across similar elements, or too large on small ones

### Surfaces
- Pure white on a tinted background; surfaces should sit in the tonal system
- Abrupt jumps between surface levels
- Colours slightly off the token palette

### Content
- Orphaned words, unbalanced headings
- Alignment off by small amounts
- Icons sized inconsistently with adjacent text
- Capitalisation inconsistent across labels

### Feel
- Cursors wrong for interactive elements
- Tap targets under 44px
- Focus order that doesn't follow the page

### Cleanup
- Console warnings or errors
- Placeholder text still in place
- Debug styles left behind
- TODO comments that should have been resolved

## Report

Three groups: Critical, Should fix, Nice to have. For each: what it is, where (file:line), and the change. Then wait.
