# Distill — strip to the essence

Grounded in Reduce until it breaks ([`DESIGN.md`](../../../forest/taste/DESIGN.md)): remove things until something essential is lost. What survives is the actual design. The same holds for code.

## Look for

### Complexity
- Wrapper components or nested containers that add nothing
- Utilities abstracted for a single use
- Helpers, higher-order components and context providers that add indirection without value
- State management heavier than the problem

### Dead weight
- Unused imports and exports
- Dead code paths, commented-out code
- Props accepted and never read
- Styles defined and never applied
- Dependencies imported but not meaningfully used

### Redundancy
- Duplicated logic that should be one thing, or the opposite, a forced abstraction over code that merely looks alike
- Repeated inline values that should be tokens
- One component doing 2 jobs, or 2 doing one

### Over-engineering
- Flags for features that shipped
- Compatibility shims for code that's gone
- Error handling for states that cannot occur
- Configuration for things that never change

## Report

Group by the 4 headings above. For each: what it is, where (file:line), and what you would do. Then wait.
