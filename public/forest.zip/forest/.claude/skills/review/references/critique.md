# Critique — the full design review

Run on request, not inside the 5-check pass. A critique asks whether the direction is right; the pass asks whether the execution is. Read all of [`DESIGN.md`](../../../forest/taste/DESIGN.md), [`BRAND.md`](../../../forest/taste/BRAND.md), [`MOTION.md`](../../../forest/taste/MOTION.md), [`INSPIRATIONS.md`](../../../forest/taste/INSPIRATIONS.md) and [`STACK.md`](../../../forest/taste/STACK.md), plus `project/design/design.md` and `project/compass.json`.

## 1. The context

Answer the 3 questions DESIGN.md starts from, using `project/compass.json` (`purpose.beneficiary`, `feeling`) and `design.md`:

- **Who, specifically, will use this?** A real person, a real moment, real conditions.
- **What is the task?** Name the verb.
- **How should it feel?** This should show in every decision.

If the code and the compass can't answer these, ask before reviewing. A critique without them is opinion.

## 2. Walk through as people

Take the beneficiary from the compass and 1 or 2 other plausible people. For each, walk the interface and note 4 things. What they see first. Whether it's the right thing. Where they get stuck. Whether the experience matches the intended feeling.

## 3. Check the principles

Against each principle in DESIGN.md:

- **Nothing without reason.** Can every element justify its presence? What's here by convention rather than intention?
- **Intent through every layer.** Does the direction constrain type, colour, spacing and rhythm, or is it an accent colour on a generic layout?
- **Reduce until it breaks.** What can go without losing meaning?
- **Against the Arbitrary.** Would several AI agents given the same prompt produce this? Then it was generated, not designed.
- **The 6 tests**: substitution, hierarchy, intent, clarity, economy, necessity.

## 4. Check against the references

Would this sit comfortably among the work in INSPIRATIONS.md? Editorial restraint, typography doing the work, images with room, a confident quietness, a visible system. If it reads as a template, a SaaS landing page or a framework default, say so. Name the reference it should be reaching towards, and what's missing.

## Report

Context · walkthroughs · principle findings with locations · reference alignment · recommendations in priority order. Then wait. Nothing changes without a yes.
