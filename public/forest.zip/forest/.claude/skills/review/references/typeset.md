# Typeset — typography

Typography is the primary medium, not formatting. The weight of a heading, the size of a caption, the tracking of a label: these set the character of the whole work. Grounded in Expose the Unconscious Decision and Errors of Practice in [`DESIGN.md`](../../../forest/taste/DESIGN.md), and checked against the type scale in `project/design/design.md`.

## Look for

### Hierarchy
- Is there one type scale, used consistently, with sizes stepping in meaningful ratios?
- Defocus the page: can the priority order be read from weight and size alone?
- Too many competing sizes or weights, flattening the hierarchy

### Weight
- Bold where semibold would do, the most common error
- The same kind of element carrying different weights on different pages
- Heading levels not distinguished by weight

### Rendering
- Headings without balanced wrapping (`text-wrap: balance`)
- Body text without `text-wrap: pretty`, leaving orphans and widows
- Line height too tight or too loose for the size
- Letter spacing wrong for the context (tight display type, loose small caps)

### Tokens
- Hardcoded font sizes instead of the scale
- Hardcoded text colours instead of tokens
- Similar components using the scale differently

### Readability
- Measure too wide: body text rarely wants more than 65–75 characters
- Contrast below AA between text and its background
- Captions or labels too small to read comfortably

## Report

Group by severity. For each: what is wrong, where (file:line), and the specific fix. Then wait.
