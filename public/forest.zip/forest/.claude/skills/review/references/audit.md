# Audit — technical quality

Accessibility, performance, compliance with the project's own system, states, and code quality. Grounded in [`DESIGN.md`](../../../forest/taste/DESIGN.md) and the performance rules in [`STACK.md`](../../../forest/taste/STACK.md).

## Look for

### Accessibility
- Semantic HTML missing: `div` soup where `nav`, `main`, `section`, `article` belong
- Images without meaningful `alt`
- Interactive elements not reachable by keyboard
- No visible focus style
- Contrast below WCAG AA
- ARIA missing where semantics alone aren't enough
- Form fields without labels

For an audit to a standard, with a report and manual passes, the user runs `/a11y-audit`. This check catches what code reading can catch.

### Performance
- Images without dimensions, optimisation or a CDN
- Animation on anything other than `transform` and `opacity`
- `backdrop-blur` on elements that move with scroll
- Scroll hijacking; native scroll is the rule
- Client-side rendering where a server component would do
- Large imports that could load on demand
- `will-change` without a measurement to justify it

### Tests
- No tests at all: P2, and the fix is `/test`
- Critical flows uncovered
- Tests with no accessibility check

### The system
- Hardcoded colours instead of tokens
- The same component treated differently on different pages
- Mixed depth methods
- More than one accent competing

### States
- Missing hover, focus, active or disabled states
- Empty states that look broken rather than pointing to an action
- Loading states that don't match the resolved layout
- Error states unstyled or browser-default

### Code
- `"use client"` where it isn't needed
- Prop drilling that should be composition
- Missing types where they matter
- Console output and debugging artefacts left behind

## Report

A table: `| Grade | Area | Finding | Where | Fix |`, P0 first, then a one-line count by grade. Then wait.
