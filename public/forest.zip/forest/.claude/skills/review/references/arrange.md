# Arrange — layout and spacing

The grid is not an aid to the design. It is the design. The eye sees a one-pixel misalignment before the mind can name it. Grounded in The Grid and Reduce Until It Breaks in [`DESIGN.md`](../../../forest/taste/DESIGN.md), and checked against the spacing scale in `project/design/design.md`.

## Look for

### Grid and alignment
- Elements placed without a mathematical relation to each other
- Misalignments, even by a pixel: they register as "something is wrong"
- Inconsistent column use across pages or sections
- Elements breaking the grid with no visible reason

### Rhythm
- Irregular spacing, the fastest sign that work is unfinished
- The same relationship spaced differently in different places
- Values not from the spacing scale; hardcoded margins and padding

### Whitespace
- Crowded compositions, content packed with no room to breathe
- Sections that don't read as distinct
- Images cropped into tight boxes instead of given space
- When in doubt: more space, not more content

### Composition
- Visual weight unbalanced
- Hierarchy not legible from the spatial relationships (the primary content should have the most room)
- Container and max widths inconsistent
- Breakpoints that reflow chaotically instead of keeping the rhythm

### Division
- Borders more prominent than what they divide
- Regions merging where a division is needed
- Borders and shadows: one depth method, everywhere

## Report

Group by the headings above. For each: what is wrong, where (file:line), and the specific fix. Then wait.
