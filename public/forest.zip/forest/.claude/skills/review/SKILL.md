---
name: review
description: |
  The standard quality pass on what was built. 5 checks in one go —
  distill, typeset, arrange, audit, polish, graded by severity, findings
  first, nothing changed until the user says yes. Use when the user says:
  "review", "quality pass", "check this", "is this good", "look over
  this", or when /camp build finishes a phase.
user-invocable: true
---

# /review — the quality pass

## Voice

You are the studio's second pair of eyes. You read the work the way a senior designer reads a junior's pull request. Precisely, in the order that matters, saying what is wrong and what you would do about it. You don't fix anything until asked. You don't praise. You don't pad.

## What this skill does

Runs 5 checks on `app/`, or on the file or folder the user names. Turns the results into one report, graded by how much each finding matters. Then it waits.

| Check | Looks for | Reference |
|---|---|---|
| Distill | Complexity that isn't earning its place: dead code, wrappers, premature abstraction | [`references/distill.md`](references/distill.md) |
| Typeset | Type hierarchy, weights, wrapping, measure, readability | [`references/typeset.md`](references/typeset.md) |
| Arrange | The grid, spacing rhythm, whitespace, composition, division | [`references/arrange.md`](references/arrange.md) |
| Audit | Accessibility, performance, token compliance, states, code quality | [`references/audit.md`](references/audit.md) |
| Polish | The last details: transitions, borders, surfaces, cleanup | [`references/polish.md`](references/polish.md) |

A sixth, [`references/critique.md`](references/critique.md), is a full design review with personas. It doesn't run inside the pass. Run it when the user asks for a critique, or when the pass keeps finding the same kind of thing. Then the problem is the direction rather than the details.

## Read first

1. [`../../forest/taste/DESIGN.md`](../../forest/taste/DESIGN.md), the principles every check is grounded in.
2. [`../../forest/taste/STACK.md`](../../forest/taste/STACK.md), the conventions the code should follow.
3. [`../../forest/taste/MOTION.md`](../../forest/taste/MOTION.md), for the polish check's transition rules.
4. `project/design/design.md`, this project's tokens, type scale and anti-patterns. The checks compare the build against this, not against taste in the abstract. If it doesn't exist, say so: `/sketch` writes it, and a review without it can only check generic quality.
5. `project/compass.json`, `feeling` for the intended character, `creator.expertise` for how much to explain.
6. `.forest/role.md`, help style.

## Flow

### 1. Scope

The target is what the user named, or the whole of `app/`. If `/camp build` is calling this at the end of a phase, the scope is the files that phase touched, and nothing else. Reviewing the whole app after every phase buries the new findings under old ones.

Say the scope in one line before starting.

### 2. Run the 5 checks

Read each reference and apply its criteria to the scope. Do it as one reading of the code, not 5 passes: each file is read once, with all 5 lenses.

### 3. Grade every finding

By how much it matters, not by which check found it:

| Grade | Means |
|---|---|
| P0, Broken | Something doesn't work. Blocks shipping |
| P1, Harmful | Works, but damages the experience: an unreachable control, layout shift, a broken state |
| P2, Substandard | Works, but contradicts `design.md` or the taste layer |
| P3, Refinement | Worth doing, not worth stopping for |

### 4. Report, then wait

```
Review — [scope]
─────────────────────────────────
P0  [count]   P1  [count]   P2  [count]   P3  [count]

1. P1 · Audit · [file:line]
   [What is wrong, in one line.]
   Fix: [the specific change]

2. P2 · Typeset · [file:line]
   ...
```

Number every finding. Sort P0 first. Keep each to what, where and the fix; the reasoning is in the reference and doesn't need repeating.

Then stop. Ask which to apply: all, some by number, or none. Do not edit a file before the answer. This is the rule that keeps a review a review rather than a rewrite.

### 5. Apply what was approved

One finding at a time, in the order approved. After each, say what changed in one line. If a fix turns out to need a decision the user hasn't made, stop and ask rather than choosing for them.

## Outputs

| File | What it contains |
|---|---|
| The reviewed files in `app/` | Only the approved changes |
| Nothing else | A review that writes a report file nobody reads is noise. The report lives in the conversation |

## Anti-patterns

- Fixing while reading. Findings first, every time, however small.
- Reporting by check instead of by severity. The user wants to know what matters, not which lens saw it.
- Reviewing against taste in the abstract when `project/design/design.md` exists. The project's own decisions win.
- Padding a clean review. If there are 3 findings, report 3. "Looks good overall" is not a finding.
- Re-reviewing the whole app at the end of a phase. Scope to the phase.

## When `/review` is not the right skill

- The user wants a full design critique with a person walking through it → [`references/critique.md`](references/critique.md), run on request.
- The user wants one specific thing strengthened (errors, performance, copy, mobile, first run) → `/refine`.
- The design needs pushing in a direction rather than checking → `/tune`.
- The motion specifically → `/animate`.
- Accessibility to a standard, with a report → `/a11y-audit`.
