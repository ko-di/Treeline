---
name: publish
description: |
  Gets a project from a folder on the machine to an address on the
  internet. Covers git, a code host account, the repository, the
  hosting account, environment variables and a domain. Runs once per
  project; `/ship` handles every push after it. Use when the user says:
  "put it online", "publish", "get it live", "host this", "deploy it",
  "I don't have GitHub", or when `/ship` finds no remote to push to.
user-invocable: true
---

# /publish — from a folder to an address

## Voice

You are the person who has done this 100 times and remembers what it was like the first time. Nothing here is obvious. Every account, every setting, every wait is named. You never say "just" and you never assume a step was understood because it was short.

## What this skill does

`/publish` is the one-time setup that `/ship` depends on. It reads the ground, then walks 6 stages, checks each before asking, and stops at the first one that needs the user to leave.

1. Reads what already exists, so no stage is asked about twice.
2. Git on the machine.
3. An account with a code host, where the files live.
4. The project's repository, and the first push up to it.
5. A hosting account, which turns those files into a page.
6. Environment variables and a domain, if the project has either.

It ends when the project has an address a stranger can open. After that, `/ship` pushes and the host rebuilds, with no further setup.

`/ship` and `/publish` do not overlap. `/ship` runs the quality gate, commits and pushes to a remote that exists. `/publish` is what makes that remote exist. When `/ship` finds no remote, it says so and hands over to here.

## Read first

1. [`../../forest/references/PURPOSE.md`](../../forest/references/PURPOSE.md). Why the kit exists.
2. [`../../forest/references/BRIDGES.md`](../../forest/references/BRIDGES.md). Every stage below is a bridge. The pre-departure format, the return rules and the 5-step limit all apply.
2b. [`../../forest/references/TEXTURE.md`](../../forest/references/TEXTURE.md), which holds the rendering format for a bridge handoff and its return pickup. `BRIDGES.md` says when to bridge; this says how it looks.
3. [`../../forest/references/FORMAT.md`](../../forest/references/FORMAT.md), how a reply is laid out: what becomes a set of options, a table or a numbered list.
4. [`../../forest/references/QUESTIONING.md`](../../forest/references/QUESTIONING.md). Every question here, and the rule that no stop happens without a route.
5. `.forest/role.md`, the user's help style.
6. `project/compass.json`, for `deployment` and `techStack`. Both get written here.

## The rule this skill exists for

`BRIDGES.md` says a bridge over 5 steps is a project of its own. Getting somebody from no account to a live address is about 20 steps. That is why it is a skill and not a bridge, and why it is split into stages that each fit the limit.

Nobody is sent across 2 bridges at once. One stage, one return, then the next.

## The words this needs

Say each of these the first time it comes up, in about this many words, then use the term plainly after that.

| Word | What to say |
|---|---|
| Git | The thing that keeps versions of your work, so you can go back |
| Code host | Where the files live. GitHub, usually |
| Repository | This project's own place on the code host |
| Remote | The copy of your project that lives on the code host |
| Push | Sending your latest work up to that copy |
| Hosting | What turns those files into a page somebody can open. Vercel, usually |
| Deploy | The hosting service reading your files and building the page |
| Environment variable | A secret the code needs and nobody else should read |
| `.gitignore` | A list of files that never leave your machine |
| Domain | The name people type. Optional |
| DNS | The system that turns a name into an address |
| Record | A line that tells the internet where your name points |

**Never say `host` on its own.** The code host and the hosting service are different companies, and the reader has to know which one is meant.

## Flow

### 1. Read the ground before asking anything

Run these and say what came back in 2 lines. Never ask what can be read.

| What to check | How |
|---|---|
| Git on the machine | `git --version` |
| A repository here | `git rev-parse --show-toplevel` |
| A remote, the copy on the internet | `git remote -v` |
| That the remote answers | `git ls-remote --exit-code origin` |
| The GitHub command line tool, which can make the repository for you | `gh --version` |
| A host already connected | `vercel.json`, `netlify.toml`, `.github/workflows/`, or `deployment` in `project/compass.json` |
| Secrets the build needs | `.env.local`, `.env.example`, and any `process.env` read in `app/` |

Then show the whole run as one numbered list, per `FORMAT.md`, with the stages already done marked as done. Somebody who cannot see the end cannot judge whether to start.

### 2. Git on the machine

Skip when `git --version` answers.

This is the bridge `/ship` refers to and that `BRIDGES.md` never defined.

```
Git is the thing that keeps versions of your work. It is not
installed on this machine yet, and the rest of publishing needs it.

Bridge:

1. Go to github.com/git-guides/install-git and follow the part for
   your computer, Mac or Windows.
2. On Mac, the page offers a download and also a Terminal command.
   Take the download.
3. When it finishes, come back here.

Type /publish when you are back. Nothing you have done so far is lost.
```

**On return:** run `git --version` again. If it still answers nothing, say so plainly and offer the other route on that page rather than repeating the same one.

### 3. An account with a code host

Skip when a remote already answers.

Ask first, with the `AskUserQuestion` tool per `FORMAT.md`, because the answer changes every later stage:

> Where should the code live?
> Why this matters: the host is where your work is kept and where the site builds from. Moving later is possible and annoying.
>
> - GitHub. The one most hosting services expect. Free for this
> - GitLab. Also free. Fewer hosting services connect to it in one step
> - Somewhere else, or an account that already exists

The bridges below are written for GitHub, because that is what most people pick and what the hosting bridge in stage 5 expects. On any other answer, do not read the GitHub steps out. Write the same 3 to 5 steps for the host they named, per `BRIDGES.md`'s pattern for any provider. Say once that the hosting stage may need a different route.

Then, for a user with no account:

```
A GitHub account is where your project will live. It is free, and
you will use it for every project after this one.

Bridge:

1. Go to github.com/signup.
2. Use an email you will still have in 2 years.
3. Pick a username. It appears in your project's address, so pick
   one you would put on a card.
4. Confirm the email GitHub sends.

Type /publish when the account exists. You do not need to make a
repository, the next stage does that.
```

**On return:** ask for the username, once. Record it in `project/compass.json` under `deployment.host` and `deployment.account`. Never ask for a password or a token in chat, per `BRIDGES.md`.

### 4. The repository, and the first push

A repository is this project's own place on the host. Say that once, in those words, before doing it.

Check for the `gh` command first. When it answers, the kit can do this stage without a bridge:

1. Confirm what is about to be published. Read the file list aloud in one line, and name anything that looks like a secret.
2. Check `.gitignore` covers `.env.local`, `.env`, `node_modules` and `app/node_modules`. Add what is missing and say what was added.
3. Ask whether the repository should be private or public, with the `AskUserQuestion` tool per `FORMAT.md`. Private is the default here. Public means anybody can read every file, including the ones nobody meant to publish.
4. Create it, set the remote, push.

Without `gh`, bridge instead:

```
Your project needs a repository, its own place on GitHub.

Bridge:

1. Go to github.com/new.
2. Name it after your project. Lower case, hyphens rather than spaces.
3. Select 'Private' unless you want the files readable by anybody.
4. Do not tick any box under 'Initialize this repository with'. Your
   folder already has the files.
5. Copy the web address it shows you. It ends in .git.

Paste that address here when you are back.
```

**On return:** set the remote, push, and confirm the push landed by reading the remote back. Then say the address a person can open, not the one ending in `.git`.

### 5. Hosting

A repository holds the code. A host turns it into a page somebody can open. Say that once, too.

Offer hosts with the `AskUserQuestion` tool. Do not name a paid tier when a free one fits, per `BRIDGES.md`. The worked steps below are Vercel's. On Netlify, Cloudflare Pages or anything else, write that provider's 3 to 5 steps instead and keep the return the same: an address pasted back.

```
Your code is on GitHub. Hosting is what turns it into an address.

Bridge:

1. Go to vercel.com/new and sign in with GitHub.
2. Choose the repository you made in the last stage.
3. Vercel reads the project and fills the build settings in. Change
   nothing unless it says it cannot tell what the project is.
4. Select 'Deploy' and wait. The first one takes about [duration].

Paste the address it gives you when it is done. It ends in
vercel.app.
```

**On return:** open the address with `curl -I` and say plainly what number came back. A 200 means the page is there. On anything other than 200 or a redirect, do not guess: hand straight to `/debug`, which reads the host's build log and translates it. First deploys fail often. Hand it to `/debug` rather than guessing at it.

Record the address in `project/compass.json` under `deployment.url`.

### 6. Environment variables, and a domain

Only when the project has them. Skip both in silence otherwise.

**Environment variables.** An environment variable is a secret the code needs and nobody else should read, such as a key for sending email. Say that the first time it comes up, then use the term.

The kit never takes a secret in chat. Write `.env.local` locally, confirm `.gitignore` covers it, and bridge the user to paste the same values into the host's own settings page. Say plainly that the host needs its own copy, because the file never leaves the machine. A build that works locally and fails on the host is usually this, and that surprise is worth spending a sentence to prevent.

**A domain.** Optional, and never assumed. The address from stage 5 is a real address that works.

```
Your site is live at [the vercel.app address]. A domain of your own
is optional.

Bridge:

1. Buy the name at Cloudflare or Namecheap. Expect about £10 to £15 a year.
2. In Vercel, go to your project, then 'Settings', then 'Domains',
   and add the name.
3. Vercel shows you 1 or 2 records. Copy them into the DNS page at
   the company you bought the name from, exactly as shown.
4. Wait. Usually minutes, sometimes a few hours. Nothing is broken
   while you wait.

Paste the domain here when it loads.
```

### 7. Close

Write `deployment` to `project/compass.json`: `codeHost`, `account`, `repo`, `url`, `domain`. Tick Camp 6's `Deployed` box in `project/map.md`, which is the box `STATE.md` reads to decide a build project has summited. There is no separate publish box.

Then say what changed, in the shape `FORMAT.md` sets:

```
Live at [address].

From here, /ship pushes your work and the host rebuilds on its own.
You do not come back to /publish for this project.
```

## Outputs

| File | What it gets |
|---|---|
| `project/compass.json` | `deployment.codeHost`, `.account`, `.repo`, `.url`, `.domain` |
| `.gitignore` | `.env.local`, `.env`, `node_modules`, checked and repaired |
| `.env.local` | Written locally, never committed, never pasted in chat |
| `project/map.md` | Camp 6's `Deployed` box ticked, Last updated set |

## What this skill will not do

- Accept a password, a token or an API key through chat. Files only, per `BRIDGES.md`.
- Make the repository public without being asked.
- Buy a domain, or name a price as though it were fixed.
- Push to a remote nobody agreed to.
- Carry on past a failed deploy. That is `/debug`'s moment, and it is named rather than guessed at.

## Anti-patterns

- Sending somebody across 2 bridges at once. One stage, one return.
- Asking what `git remote -v` would have answered.
- Saying "just" before any step in this skill. Nothing here is obvious to somebody doing it the first time.
- Reading a build log aloud in the host's words. Translate it, per `/debug`.
- Treating DNS as a small step. It is the one most people give up on, and it deserves the wait explained.
- Skipping the private-or-public question because private is the default. The consequence is worth 1 question.
