---
name: handoff
description: |
  Package the project for client or agency handoff. Fires Challenge 8
  (the cold-read challenge) before packaging. Verifies access
  transfers (credentials, repos, CMS, deployment), assembles the
  handoff doc, lists what's in the package and what's deliberately
  omitted. Use when the user says: "handoff", "package", "deliver",
  "wrap up", "client delivery", or after /retro on a client project.
user-invocable: true
---

# /handoff — package for handoff

## Voice

You are a careful packager. You assume the receiving party will never speak to the user again. You verify what's there, name what isn't, and produce the document the client can read cold and continue from.

## What this skill does

`/handoff` produces a packaged delivery for a client or successor team. It does 5 things:

1. **Fires Challenge 8:** the cold-read challenge. Before anything is packaged.
2. **Verifies access transfers:** repo access, CMS access, deploy access, domain ownership.
3. **Compiles the handoff document:** `project/HANDOFF.md` at project root, structured for someone who has never seen this work.
4. **Lists the package contents:** what's in, what's out, with reasons.
5. **Surfaces brand and design system exports:** if `project/design/design.md` exists, package it for downstream use.

It runs once per project. Re-running updates `project/HANDOFF.md` but doesn't re-fire the challenge or re-verify access (the user has already done that work).

## Read first

1. [`../../forest/references/PURPOSE.md`](../../forest/references/PURPOSE.md).
2. [`../../forest/references/CHALLENGE.md`](../../forest/references/CHALLENGE.md). Challenge 8 fires here. Render exactly per spec.
3. [`../../forest/references/TEXTURE.md`](../../forest/references/TEXTURE.md). Bridge handoff and return formats for access transfers.
4. The full project state. `project/HANDOFF.md` is a synthesis of `project/compass.json`, `project/SUMMIT.md`, `project/retro.md`, `project/decisions/`, and `project/design/design.md`.
5. `.forest/role.md`, the user's help style, which sets how much scaffolding every question carries.

## Flow

### 1. Gate-check

Read `project/compass.json`. Detect mode:

| Field | Mode |
|---|---|
| `creator.name` says client / agency / freelance | Client mode, full handoff |
| `creator.name` is the user's own name + product mode | Self-handoff (rare but possible, user wants to walk away from their own project) |
| Empty | Ask: "Is this a handoff to a client, an agency, or are you handing off your own project?" |

Read `project/compass.json.mode`. `client` runs the full flow below; `product` runs the shortened one.

If `mode` is empty, the project was packed before the field existed. Ask once: "Is this a client delivery or your own project?" Write the answer to `project/compass.json.mode` so nothing has to ask again. Don't read `.forest/role.md` for this. It is gitignored, so on a cloned or handed-over project it may not exist at all. That is exactly the situation `/handoff` runs in.

If self-handoff: lighter version. Skip the access-transfer beats, just compile the document. The user keeps access.

### 2. Fire Challenge 8

Render exactly per `CHALLENGE.md`:

```
─── Challenge ───────────────────────────────────
  If the client never spoke to you again, could
  they carry on from this folder alone?

  Why this matters: handoffs drift towards what
  you meant to include.

  Read the first 3 files cold, then tell
  me what's thin.
─────────────────────────────────────────────────
```

Wait for engagement.

**Acceptable:** the user opens the folder (`project/`, `project/decisions/`, `project/compass.json`, `project/SUMMIT.md`, `project/retro.md`) and walks through it. Names what's complete, names what's missing.

If they name gaps. Capture them. The next beat is filling them.

> "Got 3 gaps:
>   · Brand voice doc never written
>   · No staging environment URL captured
>   · The 'why Sanity' decision exists in chat but not in project/decisions/
>
> Fix these before packaging? Or accept and document the gaps?"

Branch:
- **A.** Fix → exit `/handoff`, send the user to fill the gaps. They re-run `/handoff` when done.
- **B.** Accept → proceed, the gaps go into `project/HANDOFF.md` § "Known omissions."

**If it's "it's all there"** without a walk-through, ask once: "Worth a cold read to be sure. Open the first 3 files as if you'd never seen them, and tell me where you'd get stuck."

### 3. Verify access transfers (client mode only)

Walk through the inventory. For each item:
- ✓ if the access has been transferred and confirmed
- ⊙ if pending, bridge out
- ✗ if not applicable

Items to verify:

| Item | What to confirm |
|---|---|
| Source code repo | Client has admin or write access; user (you) is no longer the only admin |
| Deployment platform (Vercel or Netlify) | Client owns the project, billing is on their account |
| Domain registrar | Domain is in the client's registrar account, not the user's |
| DNS | Pointed at the right deployment, TTL settings sane |
| CMS (Sanity or Contentful) | Client has admin access; client owns the dataset/space |
| Email provider (Resend / Postmark) | API keys rotated to client's account, sender domain verified under client |
| Analytics | Client has dashboard access; tracking ID owned by client |
| Auth provider (Auth.js / OAuth apps) | OAuth client IDs registered under client's account |
| Database (Turso / Neon / Supabase) | Client owns the database, billing is theirs |

For each item that's not confirmed, render a small bridge per `BRIDGES.md`:

```
[Item] not yet transferred. Bridge:

1. [Specific steps for that provider]
2. Confirm receipt with the client.
3. Type /handoff when done.
```

When all are ✓ or ✗ (with reason for ✗), continue.

### 4. Assemble brand and design system exports

If `project/design/design.md` exists, package it for downstream use:

- Create `project/handoff/` if it isn't there. `/pack` doesn't scaffold it, deliberately. Most projects are product mode and never need one, and an empty directory in every clone would be noise.
- Copy `project/design/design.md` to `project/handoff/design.md` so the client can find it. Copy, never move: `project/design/design.md` stays where `/sketch` put it and where every later skill expects it.
- If the project has a brand mark in `project/design/brand/`, copy to `project/handoff/brand/`.
- Include a one-line note: "The brand framework behind this work is forest, by k-d studio. It is licensed to the maker, not part of the handover."

Don't redistribute private taste-layer content.

### 5. Compile `project/HANDOFF.md`

Write to project root. Structure:

```markdown
# [Project name] — Handoff

**Delivered:** [date]
**Built for:** [client/team name]
**Original beneficiary:** [purpose.beneficiary]
**Status:** [Live at URL / staging / paused]

---

## What this is

[product.oneLiner — one sentence]

[product.howItWorks — paragraph]

## What you have

The complete folder:
  · `project/compass.json` — vision, audience, product, brand, stack
  · `project/` — working files per stage
  · `project/decisions/` — every significant decision with reasoning
  · `project/research/` — original research notes
  · `project/SUMMIT.md` — final summary at ship
  · `project/retro.md` — what worked, what didn't (if filed)
  · `project/handoff/` — design system exports

## How it works (the build)

**Stack:**
[techStack — with one-line rationale per choice]

**Where it lives:**
  · Code: [repo URL]
  · Deploy: [URL]
  · CMS: [URL if applicable]
  · Domain: [domain + registrar]

**How to update:**
  · Change content via [CMS / direct code]
  · Deploy by [push to main / manual deploy via …]
  · Roll back by [revert and re-deploy / specific steps]

## Decisions to know about

[List of project/decisions/*.md as one-liners. Group by camp if useful.]

## Known omissions

[If Challenge 8 surfaced gaps and the user accepted them — list here, with reasoning.]

## Access — confirmed transferred

  ✓ [Item] — [account / URL / where to log in]
  ✓ [Item] — [account / URL]
  ✗ [Item] — [reason it's N/A]

## Continuing the work

If you (the receiving team) want to continue building:

1. Clone the repo and run `[setup command]`.
2. Read `project/compass.json` for context. Read `project/SUMMIT.md` for the summary.
3. Read recent `project/decisions/` to understand the latest moves.
4. Use the same trail (forest) or your own process — the folder
   stands alone, regardless of tooling.

## Contact

[Whether the user is available for follow-up questions, and on what terms.
The user fills this in.]

---

*Made with forest by k-d studio. The folder is yours. The trail is walked.*
```

### 6. Bridge return — confirm receipt

After packaging, suggest the user share the `project/HANDOFF.md` and the repo with the client:

```
project/HANDOFF.md packaged at project root.

  Bridge:
  1. Share the repo with the client (already done if access is transferred).
  2. Send them project/HANDOFF.md as the entry point.
  3. Schedule one 30-min walkthrough call if useful.

  Type /handoff received when the client confirms.
```

When the user confirms receipt: tick "Handoff package built" in `project/map.md`. The trail's last loop closes.

### 7. Close

```
Packaged. The folder is theirs.
```

No further suggestion. The trail ends here.

## Outputs

| File | What it contains |
|---|---|
| `project/HANDOFF.md` | The handoff document |
| `project/handoff/design.md` | Copy of `project/design/design.md`, so the client can find it |
| `project/handoff/brand/` | Brand mark exports if any |
| `project/map.md` | "Handoff package built" ticked |
| `project/decisions/[date]-handoff-omissions.md` | If gaps were accepted (Beat 2) |

## Anti-patterns

- Skipping Challenge 8. Even when the user is confident, the cold-read forces a real check.
- Generating handoff content the user hasn't approved. The voice is the user's, the gaps are the user's, the contact terms are the user's.
- Skipping the access-transfer verification. The most common handoff failure is the client losing access to a domain or DNS the user still owned.
- Handing over forest itself (`.claude/`). It is licensed to the maker, not to the client. Only `project/` and `app/` are part of the package.
- Adding a marketing-toned thank-you section. The kit's voice is dignified, not fawning.
- Auto-running `/retro` if it hasn't been done. If `project/retro.md` doesn't exist, suggest `/retro` after handoff, the user picks.

## When `/handoff` is not the right skill

- The user wants to retrospect → `/retro`.
- The user wants to verify the deploy → `/summit`.
- The user is not handing off to a client (it's their own product) → use the lighter self-handoff path.
