---
name: system
description: |
  Document the design system from the code as built, tokens, components,
  layout patterns, motion, and the gaps, into project/design/design-system.md.
  Also extracts repeated patterns into tokens and components on request.
  Use when the user says: "document the design system", "what tokens do
  we have", "extract this", "pull this into a component", or before
  /handoff.
user-invocable: true
---

# /system — document what was built

## Voice

You are the systems designer who makes the implicit explicit. You read the code as it is, not as the design said it would be, and you write down what you find, gaps included.

## What this skill does

It has 2 jobs:

1. **Document.** Scan `app/` and write `project/design/design-system.md`. Record the tokens actually in use, every component with its states, and the layout and motion patterns. Record where the build has drifted from `project/design/design.md`.
2. **Extract.** On request, find patterns repeated 3 or more times and pull them into tokens and components. See [`references/extract.md`](references/extract.md).

`design.md` is the intent; `design-system.md` is the record. The difference between them is the most useful thing this skill produces.

## Read first

1. [`../../forest/taste/DESIGN.md`](../../forest/taste/DESIGN.md), Uniformity, and the token principle.
2. [`../../forest/taste/MOTION.md`](../../forest/taste/MOTION.md), to name the motion patterns in use.
3. [`../../forest/taste/STACK.md`](../../forest/taste/STACK.md), token and component conventions.
4. `project/design/design.md`, the intended system, to compare against.
5. `.forest/role.md`, help style.

## Flow

1. **Scan tokens:** CSS custom properties, theme and config files, colour definitions, spacing and type values in use.
2. **Inventory components:** each with its file, props, variants, and states. Default, hover, focus, active, disabled, loading, error, empty.
3. **Layout patterns:** page templates, grid use, responsive behaviour.
4. **Motion patterns:** which MOTION.md patterns are in use, with their tokens.
5. **Compare with `design.md`:** tokens that drifted, components missing states, values that escaped the system, decisions in the code that the design never made.
6. **Present** the document before writing it. Wait for a yes.

## The document

`project/design/design-system.md`:

```markdown
# Design system — [product.name]
As built, [date]. Intent is in design.md; this is the record.

## Tokens
[By category: colour, spacing, type, motion. Name, value, where used.]

## Colour
[Palette with values, semantic roles, dark mode if present.]

## Type
[Every level: size, weight, line height, use.]

## Spacing
[The scale, with use.]

## Components
[Each: purpose, file, props, variants, states.]

## Layout
[Templates, grid, responsive behaviour.]

## Motion
[Patterns in use, with tokens.]

## Drift from design.md
[What the build does that the design didn't say, and what the design said that the build doesn't do.]

## Gaps
[Missing states, inconsistent tokens, undocumented components.]
```

## Outputs

| File | What it contains |
|---|---|
| `project/design/design-system.md` | The system as built |
| `app/` | Extractions, only on request and only after approval |

## Anti-patterns

- Writing the design as intended rather than as built. That's `design.md`'s job.
- Hiding the drift. It is the point.
- Extracting a pattern with 2 instances. Wait for 3.

## When `/system` is not the right skill

- Deriving the design in the first place → `/sketch`.
- Fixing the drift → `/tune normalise`.
- Handing the folder to someone else → `/handoff`, which includes this document.
