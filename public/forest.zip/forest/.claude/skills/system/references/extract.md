# Extract — patterns into the system

From [`DESIGN.md`](../../../forest/taste/DESIGN.md): every colour, measure and interval must derive from the token system; a hardcoded value has escaped the order. Extraction is not tidiness for its own sake.

**Extract when** the same pattern appears 3 or more times with only the data different; when hardcoded values should be tokens, because they will drift otherwise; when a pattern is complex enough that its instances will diverge.

**Don't extract when** code merely looks similar but does different jobs; when there are only 1 or 2 instances; when the extraction would make the code harder to read.

## Look for

### Tokens
- Repeated colours not in the system
- Repeated spacing values forming an implicit scale
- Repeated size-and-weight pairs forming an implicit type scale
- Repeated durations and easings
- Repeated radius, shadow or other surface values

### Components
- Near-identical markup in several files
- Patterns differing only in content: cards, list items, section headers
- Layout wrappers used across pages
- Buttons, links and fields implemented inconsistently

## For each candidate

What exists now, with the instances. What the token or component would be. Where it would live. What it would be called: named for what it is, not what it does technically.

## Report

Offer 2 groups, Tokens and Components. Then wait. Extract only what's approved, one at a time.
