---
name: map
description: |
  Show the project state at a glance. Renders the trail diagram with
  camp states, surfaces what's done and what's not, lists open
  decisions and any deferred challenges. Use when the user says:
  "map", "where am I", "show me the state", "status", "show progress",
  or "lay it out." The visual orientation command.
user-invocable: true
---

# /map — show the state

## Voice

You are a clean reporter. You show what is, you don't editorialise. The user reads the map and decides what to do.

## What this skill does

`/map` renders the project's current state in 4 blocks:
1. A header, project, beneficiary, one-liner.
2. The trail diagram with camp states (the existing Mermaid block in `project/map.md`).
3. A short tally. Current camp, ticked vs unticked count, deferred challenges.
4. The latest decisions, and any pending bridges.

It is a status command. Purely informational. It writes nothing. The user runs it to orient, then picks the next command.

## Read first

1. [`../../forest/references/TEXTURE.md`](../../forest/references/TEXTURE.md), `/map` does not invent texture. It surfaces what's in `project/map.md`.
2. [`../../forest/references/STATE.md`](../../forest/references/STATE.md), how position is read. `/map` reports it; it never works it out its own way. Includes the one-time offer for projects started before 1.1.0.
3. `.forest/role.md`, the user's help style, which sets how much scaffolding every question carries.
4. The current `project/map.md`, `project/compass.json`, and the contents of `project/decisions/`.

Deliberately not `BRIDGES.md`. `/map` lists the bridges already recorded in `project/map.md`; it never emits one, so it doesn't need the doc that governs emitting them. `/map` is the cheapest command in the kit and should stay that way.

## Flow

### 1. Detect state

If `project/map.md` doesn't exist: "Nothing to show yet, this one hasn't been packed. `/pack` scaffolds the folder and draws the first map."

Otherwise, read the position per `STATE.md`, then read:
- `project/map.md`, full file.
- `project/compass.json`, for `product.oneLiner`, `purpose.beneficiary`, `meta.createdAt`.
- `project/decisions/` directory. List filenames sorted by date desc.

### 2. Render the 4 blocks

**Block 1, header**

```
forest · [project name] · started [createdAt date]
Building for [beneficiary] — "[product.oneLiner]"
```

If `purpose.beneficiary` is empty: omit the second line. (The kit refuses to fabricate.)

**Block 2, trail diagram**

Print the mermaid block exactly as it is in `project/map.md`. Do not modify it. If the user is in a renderer that doesn't display Mermaid (raw terminal), the code-fenced block still reads cleanly as a structural sketch.

**Block 3, tally**

```
Current camp: [name]
Status: [active · parked · shipped · turned-back]   (omit the line when active)
Camps closed: [N] of 6
Open in current camp: [count] checkboxes ticked of [count] total
Decisions filed: [N]
Deferred: [list, or "none"]
Phases: [N] of [N] shipped (only once project/BRIEF.md exists)
Last moved: [date]   (only if more than 21 days ago)
```

If there's nothing to say in a line, omit the line.

**Block 4. Recent decisions, pending bridges, and the thread** (only if any exist)

```
Recent decisions:
  · [filename] — [first line of file as title]
  · [filename] — [first line of file as title]
  · [filename] — [first line of file as title]

Pending bridges:
  · [what the user was sent out to do, and where it lands when they return]

Last session:
  · [the most recent line from project/memory/session.md]
```

Up to 3 decisions, most recent first. Filenames as markdown links: `[2026-04-30-stack.md](project/decisions/2026-04-30-stack.md)`.

A bridge is pending when `project/map.md` records one that hasn't come back, an interview to run, a mark to draw, a domain to buy. Read them from `project/map.md`; `/map` never invents a bridge, and omits the heading entirely when there are none.

### 3. Close

One line, no flourish:

```
Type /compass for the next move, or /trail to continue.
```

## Outputs

Nothing. `/map` is read-only.

## Anti-patterns

- Editorialising. "Looking great so far", no. Show the state, end.
- Generating a Mermaid diagram from scratch. Use the one in `project/map.md`. If `project/map.md`'s diagram is out of sync with the camp states, that's a `/trail` problem, not a `/map` problem.
- Showing more than 3 recent decisions. The user wants orientation, not history.
- Padding with "next steps" beyond the closing one-liner. The user came for the state. `/compass` is for the next move.

## When `/map` is not the right skill

- The user wants the next move → `/compass`.
- The user wants to walk the trail → `/trail`.
- The user wants to do work → `/camp [name]` or the camp's working skill.
