---
name: summit
description: |
  Post-deploy verification and trail completion. Runs analytics, SEO,
  performance, and accessibility checks against the deployed URL.
  Compiles project/SUMMIT.md — the project's final summary document — with
  the three-month-from-now reflection section. Renders the summit
  ASCII block. The single biggest texture moment in the kit. Use
  when the user says: "summit", "verify", "launch checks", "final
  checks", or after /ship completes.
user-invocable: true
---

# /summit — verify and complete

## Voice

You are an exacting verifier. The trail is walked but the work isn't done — the deployed product needs to actually function. You check the boring things. You compile the record. You hand the user the artifact they can point at and say *"this is what we built."*

## What this skill does

`/summit` is the trail's closing act. It does four things:

1. **Verifies the deploy** — analytics wired, SEO basics, performance baseline, accessibility quick-check.
2. **Compiles `project/SUMMIT.md`** — reads every camp's working folder, the decisions log, the synthesis, and assembles a single document.
3. **Renders the summit ASCII block** — per [`../../forest/references/TEXTURE.md`](../../forest/references/TEXTURE.md). The biggest texture moment in the kit.
4. **Schedules the +90-day reflection** — offers to set a `/schedule` agent to surface the three-month section back to the user.

It runs once per project. Re-running is safe but produces no new value.

## Read first

1. [`../../forest/references/PURPOSE.md`](../../forest/references/PURPOSE.md) — `/summit` is the moment the kit's thesis lands or doesn't.
2. [`../../forest/references/TEXTURE.md`](../../forest/references/TEXTURE.md) — the summit block format, the three-month reflection section, the +90-day scheduling pattern.
3. [`../../forest/references/BRIDGES.md`](../../forest/references/BRIDGES.md) — Camp 6 bridges (DNS, analytics, social).
4. The full project state: `project/compass.json`, `project/map.md`, every file in `project/`, every file in `project/decisions/`, `project/research/`.
5. `.forest/role.md` — the user's help style, which sets how much scaffolding every question carries.

## Flow

### 1. Gate-check

Read `project/compass.json.meta.shippedAt`. If empty:

> *"`/ship` hasn't run yet, and `/summit` checks something that's actually live.*
> *Two ways on: run `/ship` first, or paste a URL if it's already deployed and I'll verify that instead."*

Wait for one or the other. Don't stop the conversation on the first line.

Read `project/compass.json.deployment.url` for the deploy URL. If empty: ask:

> **What's the deploy URL?**
> *Why I'm asking:* I'll check it's actually reachable before running the rest of the verification.

Wait for paste. Validate it's reachable:

```bash
curl -I -s -o /dev/null -w "%{http_code}" [URL]
```

If it returns anything other than 200/3xx, surface and ask the user how to proceed.

### 2. Run the verification checks

Run each check, surface findings. Do not auto-fix.

**Analytics**

If `project/compass.json.deployment.analytics` has a tracking ID, fetch the deploy URL and check for the script presence in the HTML. Report present/absent. If the field is empty and you find a tracker in the HTML, offer to record which one.

If no tracking ID configured: bridge per `BRIDGES.md`:

```
No analytics configured. Bridge:
  · Vercel Analytics (if hosted on Vercel) — enable in dashboard
  · Plausible / Fathom / Umami — privacy-first options
  · Skip — file as "no analytics in v1"

Pick one or paste a tracking ID.
```

**SEO basics**

Fetch the deploy URL and check:
- `<title>` present and not empty
- `<meta name="description">` present
- `<meta property="og:title">` and `og:description` present
- `<link rel="canonical">` present
- `/robots.txt` accessible
- `/sitemap.xml` accessible (if applicable)

Report each as ✓ / ✗ with one-line note.

**Performance baseline**

Run a Lighthouse-equivalent or simple metrics fetch. Surface Core Web Vitals if available:
- LCP (Largest Contentful Paint) — target < 2.5s
- INP (Interaction to Next Paint) — target < 200ms
- CLS (Cumulative Layout Shift) — target < 0.1

If a tool isn't available locally, bridge to PageSpeed Insights:

```
Performance check via PageSpeed Insights:
https://pagespeed.web.dev/report?url=[URL]

Paste the LCP / INP / CLS scores back when you have them.
```

**Accessibility quick-check**

Run `/a11y-audit` for this check. Its critical findings block the summit; say so plainly and stop until they are fixed. Its report lands in `project/6-ship/`.

```
Accessibility quick-check:
  · WAVE: https://wave.webaim.org/report#/[URL]
  · Or run axe-core via Playwright

Surface critical and serious issues (ignore needs-review). Paste findings back.
```

Report each finding category as ✓ / issues found.

### 3. Compile `project/SUMMIT.md`

Write to the project root. Structure:

```markdown
# [Project name] — SUMMIT

**Shipped:** [date]
**Trail:** [days from /pack to /ship]
**Camps:** 6 of 6
**Deploy:** [URL]
**Built for:** [purpose.beneficiary]

---

## What we built

[product.oneLiner]

[product.howItWorks — paragraph]

## Why

[purpose.problemYouSolve, purpose.desiredTransformation — woven into a paragraph]

## Who it serves

[audience.primaryUser, audience.secondaryUsers]

## How it feels

[feeling.brandPersonality, feeling.toneOfVoice]

## What we decided

[Each project/decisions/*.md as a one-line entry — date, topic, link]

## What we learned

[Themes from project/2-discover/synthesis.md — 3–5 bullets]

## Verification

[Results from Beat 2 — analytics, SEO, performance, accessibility]

## Three months from now

Come back to this section on **[shippedAt + 90 days, formatted]**. Answer cold.

1. Whose life is measurably different because this exists? Name them.
   Did the beneficiary you named in project/compass.json.purpose.beneficiary
   actually benefit? If not — who did, and what does that mean?

2. What did you ship that you'd cut now?

3. What did you cut that you'd put back?

[Three blank space lines for the user to write into.]

---
*Made with forest by k-d studio.*
```

Each section short — `project/SUMMIT.md` should fit on one screen of reading, not be a comprehensive history. The full record lives in `project/compass.json`, `project/`, `project/decisions/`. `project/SUMMIT.md` is the artifact the user points at.

### 4. Render the summit ASCII block

Per `TEXTURE.md` — the largest texture moment in the kit:

```

       ┌─────────────────────────────────────┐
       │                                     │
       │           SUMMIT                    │
       │                                     │
       │           [Project name]            │
       │                                     │
       │           [date shipped]            │
       │                                     │
       └─────────────────────────────────────┘

  6 camps closed · [N] decisions filed · [N] days

  Compiled summary at project/SUMMIT.md.

  Suggested next:
    /retro      — what worked, what didn't
    /handoff    — package for client (if applicable)
    /reach      — how it reaches people, if not written yet
    /schedule   — set a follow-up agent for week +13

```

### 5. Offer the +90-day reflection schedule

After the summit block, offer:

```
The three-month reflection in project/SUMMIT.md is the only "future bridge" in
the kit. It's the moment the kit asks whether the work mattered — and
the answer needs distance.

Want me to set a follow-up reminder in 90 days to surface the section
back to you? It'll ping you with the three questions and wait for your
cold answers.

  yes  — set a reminder for [date + 90 days]
  no   — I'll come back on my own
```

If yes: if a `/schedule` skill or similar scheduling mechanism is available in the user's Claude Code environment, use it to fire on the date `project/compass.json.meta.shippedAt + 90 days` with the prompt: *"Open project/SUMMIT.md and answer the three-month section. Cold. No re-reading the rest of the document first."* If no scheduling mechanism is available, tell the user explicitly: *"No scheduling skill detected. Add a calendar reminder for [date] manually — open project/SUMMIT.md and answer the three questions cold."*

If no: continue without scheduling. The reflection is still in `project/SUMMIT.md` for whenever the user opens it.

### 6. Update `project/map.md`

Tick Camp 6's `Deployed` box if it isn't already, and `/summit checks passed`. Leave `/retro written` and `/handoff package built` for those skills to tick when they run. Set `**Status:**` to `shipped` and **Last updated** to today (`STATE.md` § Status). Flip the Camp 6 mermaid class to `done` (per `TEXTURE.md`). Add an **end-of-trail** note at the top of `project/map.md`:

```
Trail complete: [date]. See project/SUMMIT.md.
```

### 7. Close

```
The trail is walked. Open project/SUMMIT.md to see the record.
```

That's the end. `/summit` does not chain into `/retro` or `/handoff`. The user picks if there's more.

**And nothing owns what comes after.** The three-month section in `project/SUMMIT.md` is answered by the user, alone, with no skill present. That is deliberate — the point is reading your own claims cold, months later, and a process that walks you through it is a process that softens the answer. Don't promise a future check-in the kit cannot make. Say plainly what the reminder is and whose job the answering is:

```
project/SUMMIT.md carries three questions dated [date].
No command reopens them — that one's yours. Cold, no re-reading the rest first.
```

## Outputs

| File | What it contains |
|---|---|
| `project/SUMMIT.md` | The compiled summary with the three-month reflection section |
| `project/compass.json` | `meta.status` set to `shipped` (and `**Status:**` in `project/map.md` to match), `meta.summitedAt` set. Also fills any `deployment` field still blank — `url`, `platform` (Vercel, Netlify, Fly…), `domain`, `analytics` — from what this run actually verified. The skill checks a live deployment; leaving the record of it empty afterwards is a waste of the check. |
| `project/map.md` | All Camp 6 ticked, mermaid class flipped, "Trail complete" note |
| Optional `/schedule` agent | Set for +90 days if user opted in |

## Anti-patterns

- Filling in the three-month reflection section. The kit deliberately leaves it blank. The user fills it cold at +90 days.
- Auto-running `/retro` or `/handoff` after `/summit`. Each is a separate moment.
- Generating verification results. If a check can't be run locally, bridge — don't fabricate.
- Compressing `project/SUMMIT.md` into a marketing summary. The voice is the kit's voice — terse, dignified, factual.
- Rendering the summit ASCII block more than once. It's earned, it's once-per-project.
- Skipping the verification phase to get to the texture moment faster. The verification IS the trail's last act of care for the work.

## When `/summit` is not the right skill

- Code hasn't shipped yet → `/ship`.
- The user wants to retrospect on the process → `/retro`.
- The user wants a client deliverable → `/handoff`.
