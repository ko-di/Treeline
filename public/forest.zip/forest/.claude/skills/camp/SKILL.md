---
name: camp
description: |
  Jump to a specific camp and work there directly. Takes a camp name
  as argument: /camp frame, /camp learn, /camp decide, /camp
  shape, /camp build, /camp ship. Use when the user says: "camp
  [name]", "go to [name]", "work on [camp]", "jump to [camp]", or
  names a stage explicitly. Out-of-order navigation when /trail's
  sequential walk isn't right.
user-invocable: true
---

# /camp — jump to a specific camp

## Voice

You are a guide who respects the user's judgement about where to work. They know what they need. You open the door.

## What this skill does

`/camp [name]` opens a specific camp out of the trail's normal sequence and runs the appropriate working skill for that camp. Used when the user wants to work on something specific. Usually because they have an idea or a concern they want to address now, not when the linear trail order would surface it.

The kit does not enforce sequential order through `/camp`. That's `/trail`'s job. `/camp` is the escape hatch, the user gets to break order if they have reason to.

## Read first

1. [`../../forest/references/PURPOSE.md`](../../forest/references/PURPOSE.md).
2. [`../../forest/references/CHALLENGE.md`](../../forest/references/CHALLENGE.md). If jumping to a camp out of order skips a transition challenge, it still fires later when `/trail` reaches that transition. Don't fire those from `/camp`. Challenge 6 is the exception: it is an in-camp challenge and `/camp build` owns it (see Camp 5 below).
3. [`../../forest/references/STATE.md`](../../forest/references/STATE.md), `/camp` reads position and never writes it. It also carries the one-time rename offer for projects started before 1.1.0. Working out of order ticks boxes and leaves the trail where it is.
4. `.forest/role.md`, the user's help style.
5. The current `project/map.md` and `project/compass.json`.
6. [`../../forest/references/FORMAT.md`](../../forest/references/FORMAT.md), how a reply is laid out: what becomes a set of options, a table or a numbered list.

## Flow

### 1. Parse the argument

Valid arguments: `frame`, `learn`, `decide`, `shape`, `build`, `ship`.

Also valid: a camp number (`1` through `6`).

**The old names still work.** Before 1.1.0 these camps were called intake, discover, define and design. If the user types one, do not make them look it up. Run the right camp and name the new word once, in passing:

> "That's Learn now. Same camp, clearer name. Opening it."

Say it once per session, not every time.

Invalid: anything else. Respond:

> "Which camp? frame, learn, decide, shape, build, or ship.
> Working out of order is fine, `/camp` exists for exactly that. The trail will still know where you've been."

Wait for the user to pick.

### 2. Route to the working skill

| Camp | Working skill |
|---|---|
| 1, Frame | This skill, `/camp` runs Camp 1 in-place (see § 4, Camp-specific flow, below) |
| 2, Learn | `/scout` |
| 3, Decide | This skill, Camp 3 has no dedicated working command; runs in-place |
| 4, Shape | This skill offers the design method that fits the team and the time (see § 4, Camp 4), then `/sketch` |
| 5, Build | This skill, Camp 5 has no dedicated working command; runs in-place |
| 6, Ship | `/ship` |

For Camps 2, 4, and 6: hand off to the dedicated working skill. Print "Walking Camp [N], [name]. Running `/[skill]`." and load that skill.

For Camps 1, 3, and 5: run the camp directly via this skill, see the camp-specific flows below.

### 3. Surface what's already in the camp

Read `project/[N]-[name]/` and list what's there:

```
Camp [N] — [name]
Files in this camp:
  · [file 1]
  · [file 2]
  · (empty, nothing filed yet)

Open checkboxes from project/map.md:
  · [unticked item 1]
  · [unticked item 2]
```

This sets context. The user knows what they're walking into.

### 4. Camp-specific flow

#### Camp 1 — Frame

If `project/1-frame/idea.md` is empty or missing:
- Run the equivalent of `/pack`'s Beat 5. Capture the one-line idea or run the idea hunt.

If `project/1-frame/idea.md` exists:
- Surface what's there. Ask: "Refine the existing idea, or revisit the constraints and why-now?"
- Refine → run an Open question per `QUESTIONING.md` to sharpen.
- Constraints/why-now → walk through the 3 checkboxes from `project/map.md` Camp 1 (idea sentence, constraints, why-now articulated). Capture each in `project/1-frame/`, and mirror the constraints into `project/compass.json.business.constraints`. Time, money, skill, scope, in one line. `/camp decide` reads it when cutting scope, and Challenge 3 is much sharper when the constraint is already written down.

When all 3 checkboxes are tickable, write what's been captured, update `project/map.md` checkboxes (do not close the camp, that's `/trail`'s job), and close with:

```
Camp 1 work captured. Type /trail to fire Challenge 1 and break camp.
```

#### Camp 3 — Decide

Camp 3 produces the PRD. Steps:

1. **Read context:** `project/compass.json`, `project/2-learn/` (if anything is there), `project/research/`.
2. **Open conversation:** surface the audience and the validated frustration (from Camp 2). Ask: "Given Emma's [validated frustration], what's the smallest product that addresses it?"
3. **PRD draft:** write to `project/3-decide/prd.md` in sections:
   - Beneficiary (echoed from `project/compass.json.purpose.beneficiary`)
   - Problem statement (from Camp 2)
   - Scope: in / out / later
   - One success metric
   - Risks and assumptions
4. **Iterate:** read each section back, ask if anything's missing, accept refinements.
5. **Mirror the decisions into `project/compass.json`.** The PRD is the prose; `project/compass.json` is what every later skill reads. As each is settled, fill, blanks only, never overwriting:
   - `product.name`, `product.keyCapabilities` (from scope: in), `product.howItWorks` (a plain paragraph: what someone does with it, start to finish), `product.magicMoment`, `product.marketDifferentiation`
   - `purpose.problemYouSolve` (the problem statement, one sentence) and `purpose.desiredTransformation` (what is different for the beneficiary once it works)
   - `audience.currentAlternatives` (what they do today, from Camp 2), `audience.frustrations` (what's wrong with that, in their words from `project/research/`, not your paraphrase) and `audience.secondaryUsers` (anyone else Camp 2 found it touches, if anyone)
   - `business.revenueModel`, `business.initialGoal` (the one success metric), `business.sixMonthVision`, `business.goToMarket`
   - `purpose.whoYouHelp`, `purpose.whyYou`

   `/camp build`, `/summit` and `/handoff` read `purpose.problemYouSolve`, `purpose.desiredTransformation`, `product.howItWorks` and `audience.secondaryUsers` to write their summaries. Left empty, those sections come out empty.

   Don't interrogate the user for a field they haven't reached. Ask only for what the PRD conversation naturally produces, and leave the rest empty, an empty field is honest, an invented one is not.

When `project/3-decide/prd.md` is filled, update `project/map.md` checkboxes and close with:

```
Camp 3 PRD captured at project/3-decide/prd.md.
Type /trail to fire Challenge 3 (cut your scope in half) and break camp.
```

#### Camp 4 — Shape

Before `/sketch` draws anything, offer the piece of design work that fits this user. Read, in this order:

1. [`../../forest/references/OFFERING.md`](../../forest/references/OFFERING.md), the 3 lines every offer carries.
2. [`../../forest/knowledge/design/offering.md`](../../forest/knowledge/design/offering.md), which decides what to offer at this camp and in what order.
3. [`../../forest/knowledge/design/methods.md`](../../forest/knowledge/design/methods.md), only for the method chosen.

The rule from both: `Team:` in `.forest/role.md` decides which methods exist for this user, and a method that does not fit is never named. If that field is blank or missing, ask which it is before offering anything, and write the answer. Offering while it is unknown is how a client team ends up seeing only the solo methods. Someone working alone is not shown a walkthrough. Someone with a client is.

Offer up to 3, each with its 3 lines rewritten for this product. If the user declines, say nothing about it and hand to `/sketch`:

```
Walking Camp 4, Shape. Running /sketch.
```

#### Camp 5 — Build

Camp 5 is where the documents stop being documents. Its first act is to compile them.

#### Compile `project/BRIEF.md` first

Everything upstream, `project/compass.json`, the PRD, `design.md`, the decisions, the weather reading, is spread across 7 files written for different readers at different times. No build tool, human or otherwise, should be asked to reassemble that. `/camp build` writes one file that stands on its own.

Do this before any code, and rewrite it whenever the PRD or the design changes. The user may ask for the brief earlier, wanting to take it to a design tool before Camp 5. Compile it on request and say plainly which parts are still thin.

`project/BRIEF.md` at the project root, in this order:

```markdown
# Brief — [product.name]

[product.oneLiner]
For [purpose.beneficiary]. [product.platform].

## What this is for
[purpose.problemYouSolve] — [purpose.desiredTransformation]
Today they [audience.currentAlternatives], and [audience.frustrations].

## Scope
**In:** [product.keyCapabilities]
**Out:** [from the PRD's out list — verbatim, this is the load-bearing half]
**Later:** [from the PRD's later list]

Success is [business.initialGoal]. One metric, not five.

## Constraints
[business.constraints] · Stack: [techStack, each choice with its rationale]

## How it should feel
[feeling.brandPersonality] · [feeling.visualMood] · [feeling.toneOfVoice]
Never: [feeling.antiPatterns]

Tokens, components and states are in `project/design/design.md`. Use them as
written — they were derived from references the user chose, not invented here.

## Phases
Each phase is a vertical slice that could ship on its own.

1. **[Phase name — a sentence a user would recognise]**
   Serves: [PRD requirement]. Screens: [from design.md]. Done when: [observable].
2. …

## Decisions already made
Do not reopen these without saying so. Each links its full reasoning.
- [date] — [decision]. *[one-line why]* → `project/decisions/[file]`

## What the evidence actually supports
[weather.md's reading and load-bearing claim, verbatim]
[If the reading was reroute or turn back and was overridden, say so here. A build
brief that hides its own gate reading is the exact failure the gate exists for.]

## Deferred
[what the cut removed: one line each on why, and what would bring it back]

## Still open
[every project/compass.json field that matters and is still empty, named plainly]

---
*Made with forest by k-d studio.*
```

There are 2 rules for this file. It quotes, it does not paraphrase. Scope lines and decisions carry over word for word, because a paraphrase is where scope creep enters. And it names what is missing rather than writing around it; a brief that reads complete when the thinking isn't is worse than no brief.

#### The cut, before the list is written

For each phase, ask what would be dropped if it took twice as long. The answer is usually obvious and already known. Drop it now: a thing that wouldn't survive schedule pressure was never phase one.

Then, for every requirement in every phase, one question: what breaks if this is not built?

| Answer | Do |
|---|---|
| Something specific, and soon | Keep it |
| Something specific, but later | Move it to a later phase |
| Nothing you can name | Cut it, and record it under Deferred in the brief, with one line on what would bring it back |

The third answer is more common than makers expect, and cutting there is what keeps a first release small enough to finish. Without the Deferred list, cut ideas come back during the build as though they had always been agreed.

Write the phase list into `project/map.md` under Camp 5's Phases heading as checkboxes, so they tick as they ship. Tick the `project/BRIEF.md` checkbox.

Then say:

```
project/BRIEF.md compiled, [N] phases. It stands alone: hand it to any build tool,
or keep going here with /trail.

BUILDING.md has the prompts: Claude Design, v0, Lovable, Bolt, Figma Make,
or a developer.

Thin: [anything still empty that a builder will trip on]
```

#### Then the build

1. Read `project/compass.json.techStack`. If empty, ask which stack and fill it. (Use [`../../forest/taste/STACK.md`](../../forest/taste/STACK.md) for the defaults and the reasons behind them.)

   There are 5 slots, each with a `choice` and a `rationale`: `frontend`, `backend`, `database`, `auth`, `payments`. Fill only the ones this project actually has, a static site has no `auth` and no `payments`, and empty is the right answer there. Every `choice` you do fill needs a `rationale` in the user's words; `CHALLENGE.md` fires the stack chosen with no rationale signal on "default" or "industry standard".
2. Read the phases under Camp 5 in `project/map.md`. The next phase is the first one not ticked. Do not ask which to start with when the order is already written down; `project/BRIEF.md` put them in build order for a reason.

3. Show the phase list first, whole, as one numbered list. Per `FORMAT.md`, a sequence is never revealed a step at a time: somebody who cannot see the end cannot judge how to work through it. Then ask once, and only once, with the `AskUserQuestion` tool:

   > How do you want to work through these?
   > Why this matters: there are [N] phases left. Some people want to see each one before the next starts. Some would rather come back to a working thing.
   > A. One at a time. Each phase stops for you to look
   > B. Straight through. Each phase is built, reviewed and committed in order, stopping when something needs you

   Take the answer, then run the loop below either way. The only difference is whether it pauses at step 8.

4. Check for a repository before the first commit. If `git rev-parse --show-toplevel` returns nothing, say so and offer to run `git init` (see `/ship`, which does the same). If they decline, run the loop without the commit step and say once that the phases will not be checkpointed.

#### The phase loop

For each phase, in order:

1. **Read what it has to do.** The phase names a requirement in `project/3-decide/prd.md`. Open that section for the detail the one-line phase summary leaves out. Open `project/design/design.md` for anything with a screen.
2. **Build it, in `app/`.** All product code lives there, never at the project root or in `project/`. Create `app/` if it is missing and run every build tool from inside it. Standard Claude Code engineering: small commits, no over-engineering, no libraries without asking. Pitch explanations at the level in `project/compass.json.creator.expertise`.
3. **Review it, with `/review` scoped to the phase's files.** The 5 checks, distill, typeset, arrange, audit, polish, graded by how much each finding matters, against `project/design/design.md`. Report what it finds. Do not silently fix it, say what is wrong and what you would do, then do it on a yes.
4. **Test the flow, with `/test` scoped to the phase.** Write the tests for what this phase makes possible, run them from inside `app/`, and report. A test that fails because the product is wrong is a finding for the user, not something to make pass.
5. **Compare it with the design.** Same tokens, type scale, component states, anti-patterns avoided. List every divergence and ask which way it goes: fix the build, or update `design.md` because the build found something better. Both are fine. Silence is not, because an unreconciled divergence is how a project ends up with a design system nothing uses.
6. **Commit.** One commit per phase, the message naming the phase and the requirement it serves. Never push. Where the code lives is the user's call and `/ship` is where that happens.
7. **Tick the phase** in `project/map.md`, and set Last updated.
8. **Next phase.** On A, stop and say what is done and what is next. On B, carry straight on.

#### When to stop, on either setting

Stop and ask, rather than deciding for them:

- Something is broken rather than unfinished: the build stops, a test errors instead of failing, the server will not start, the page is blank. Hand to `/debug`, which translates the error before anything else happens. Do not carry on into the next phase. A phase built on a broken one is built wrong, and the cost compounds.
- The phase needs a decision `project/BRIEF.md` does not answer. Name the decision, offer the options you can see, and file the answer with `/rationale` if it is worth remembering.
- The review in step 3 finds something that changes a later phase.
- A library, a service or a schema change would be needed that nobody has agreed to.
- The user says stop. Finish the commit in flight, tick nothing you have not finished, and leave the map honest.

Never carry on through a stop because the remaining phases look like less work. The point of phases is that each one can be looked at.

#### Challenge 6, inside the loop

`CHALLENGE.md` places Challenge 6 "mid-Camp 5, once core flows work", and that moment only exists inside this skill. In a run of phases it has a precise home. It fires after the first phase that makes something work end to end, before the next one starts.

That is usually phase 1 or 2, not the last. Firing it at the end would ask what is most likely to break at the point where nothing can be changed. That is the opposite of the question.

Render it exactly as `CHALLENGE.md` specifies, in the `TEXTURE.md` box. Handle the answer with the 3 responses from `CHALLENGE.md` § Engagement. Note in `project/map.md` that it fired, so `/trail` does not raise it again at the transition. It fires once per cycle, even on a run of 8 phases.

On setting B, this is a stop. Pause the run, ask, take the answer, then carry on.

#### Closing the camp

When every phase is ticked and `project/map.md` Camp 5 reads complete, close with:

```
All [N] phases shipped. Challenge 6 filed.
Reviewed against the design: [N] divergences, all resolved.
Type /trail to close the camp.
```

Append one line to `project/memory/session.md` per `STATE.md` before you finish.

### 5. Out-of-order safeguards

The user may jump to Camp 4 before Camp 2 is done, dropping a screenshot and running `/sketch` while the audience is still loose. Let them. `/sketch` will work. But before closing the camp, surface this gently:

```
You're working Camp 4 with Camp 2 still open. That's fine. Keep going.
But /sketch will produce more useful tokens once the audience is known.
Drop a /trail when you want to come back and finish Camp 2.
```

This is not a challenge. It's a note. The user has made a decision; the kit acknowledges it without arguing.

### 6. Before you finish

Whatever camp the work was in, append one line to `project/memory/session.md` per `STATE.md` § Memory. Record the date, the camp, what happened, and anything the user said they would do next.

## Outputs

Depends on the camp. `/camp` itself doesn't write, it routes. The working skills it routes to (or runs in-place) write to `camps/[N]-[name]/` and update `project/map.md` checkboxes.

| File | When |
|---|---|
| `project/BRIEF.md` | `/camp build` on entry to Camp 5, and again whenever the PRD or design changes |
| `project/map.md` | Checkbox ticks, the phase list under Camp 5, and each phase ticked as it ships |
| git | One commit per phase, naming the phase and the requirement it serves. Never pushed |
| `project/compass.json` | Camp 1 constraints, Camp 3 product/business/audience fields, Camp 5 `techStack` |
| `project/memory/session.md` | One appended line when a session's work ends (`STATE.md`) |

## Anti-patterns

- Firing trail-transition challenges from `/camp`. Those belong to `/trail`. `/camp` does the work; `/trail` does the transitions. The one in-camp challenge `/camp` owns is Challenge 6, and only in Camp 5.
- Writing `**Current camp:**`. `/camp` is explicitly not one of the 2 skills allowed to move the trail (`STATE.md`). Out-of-order work leaves the position alone; that separation is what lets `/camp` exist at all.
- Closing a camp from `/camp`. Closing, flipping mermaid classes, ticking all checkboxes, advancing `Current camp`, is `/trail`'s job. `/camp` reports work done; `/trail` punctuates it.
- Refusing out-of-order jumps. The user gets to do this. The kit notes it once, then continues.
- Running the dedicated working skill (`/scout`, `/sketch`, `/ship`) without a clear handoff. "Loading `/scout`…" and then continuing inside `/scout`'s flow is correct. Spawning `/scout` and then trying to manage it from `/camp` is not.

## When `/camp` is not the right skill

- The user wants to walk the trail in order → `/trail`.
- The user wants the next-move recommendation → `/compass`.
- The user wants to see state → `/map`.
