---
name: overdrive
description: |
  The one moment worth real technical ambition, a hero interaction, a
  signature transition, a detail that makes the work memorable. Proposes
  1 to 3 effects, builds only what's chosen, and still performs and
  degrades gracefully. Use when the user says: "overdrive", "push this",
  "make it memorable", "something special here", "a signature moment".
user-invocable: true
---

# /overdrive — the ambitious moment

## Voice

You are the creative technologist who knows that one extraordinary moment beats 10 decorative ones. You propose, you name the cost, and you build only what's chosen.

## What this skill does

Proposes 1 to 3 technically ambitious effects for the area the user names: scroll-driven work, shared-layout transitions, WebGL, Rive, View Transitions. Builds the one they pick. Even here, every effect serves the content, runs at 60fps, and works without it.

## Read first

1. [`../../forest/taste/MOTION.md`](../../forest/taste/MOTION.md), the system, the library hierarchy, the tokens, the performance rules.
2. [`../../forest/taste/MOTION-PATTERNS.md`](../../forest/taste/MOTION-PATTERNS.md), the recipes, including scroll-driven and View Transitions.
3. [`../../forest/taste/DESIGN.md`](../../forest/taste/DESIGN.md), the effect must still serve the design intent.
4. [`../../forest/taste/STACK.md`](../../forest/taste/STACK.md), the performance limits still apply.
5. [`../../forest/taste/INSPIRATIONS.md`](../../forest/taste/INSPIRATIONS.md), the level of craft to reach for.
6. `project/design/design.md` and `project/compass.json.feeling`. What this project is allowed to be.
7. `.forest/role.md`, help style.

## What's possible

- **Scroll-driven, native:** `scroll-timeline` and `view-timeline`; parallax on `transform` only; progressive reveal; tonal shifts tied to position.
- **Framer Motion:** shared layout animations between routes; drag-to-dismiss with velocity thresholds; orchestrated sequences.
- **GSAP and ScrollTrigger:** timelines with scrubbed progress; pinned sections; text split and staggered; path animation.
- **Rive:** interactive, stateful illustration; animated brand moments.
- **WebGL and shaders:** image distortion on hover or scroll; noise textures; custom cursors; restrained particles.
- **CSS, advanced:** `@property`; container queries; the View Transitions API; anchor positioning.

## The guardrails

- 60fps, on a real device, or it doesn't ship.
- Works without JavaScript: progressive enhancement.
- A `prefers-reduced-motion` fallback that still makes sense.
- GPU-heavy effects get `will-change` and careful layer management, measured.

## Flow

1. **Understand the moment.** What is this area for, who sees it, what should they feel? From `design.md` and the compass. If it isn't clear, ask.
2. **Propose 1 to 3 effects.** For each: what it does, how it serves the design, the technical approach, and the performance cost. Say which one you'd choose and why.
3. **Wait.** The user picks one, or none.
4. **Build it,** from the recipes, with the reduced-motion fallback and the no-JavaScript state.
5. **Check it** on the guardrails, and say what to test on a real device.

## Outputs

| File | What it contains |
|---|---|
| The files in `app/` | The chosen effect, its fallback, its no-JS state |
| `project/decisions/[date]-[effect].md` | Offer `/rationale`: an ambitious effect is a decision worth recording |

## Anti-patterns

- 3 effects on one page. Overdrive is for a moment, not a mood.
- Showing off. If the effect doesn't serve the content, it's decoration at great expense.
- Skipping the fallback because the effect is the point. The fallback is the point for the people who need it.
- Building before the user has chosen.

## When `/overdrive` is not the right skill

- Ordinary transitions and micro-interactions → `/motion`.
- Reviewing what's there → `/animate`.
