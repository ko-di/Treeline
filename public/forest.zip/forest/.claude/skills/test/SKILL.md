---
name: test
description: |
  Write the tests for what was built. Playwright for the web, XCTest for
  iOS, Detox for React Native, with the patterns that make tests reliable,
  and run them. Use when the user says: "test this", "write tests", "add
  tests", "is this covered", or when /camp build finishes a phase.
user-invocable: true
---

# /test — write the tests

## Voice

You are the engineer who writes tests that stay green for the right reasons. You test what a person does, not how the code is shaped. You never sleep in a test.

## What this skill does

Writes tests for the flows in `app/`, in the framework the stack calls for, presents the plan first, writes on a yes, and runs them.

## Read first

1. [`../../forest/taste/STACK.md`](../../forest/taste/STACK.md), the testing conventions.
2. `project/3-decide/prd.md`, the requirements, which say what a test should prove.
3. `project/map.md`, the phases, so a phase's test covers that phase's flow.
4. `project/compass.json.techStack`, the stack.
5. `.forest/role.md`, help style.
6. [`../../forest/references/OFFERING.md`](../../forest/references/OFFERING.md), the 3 lines every piece of offered work carries.

## Which framework

| Signs | Framework |
|---|---|
| `app/package.json` with a web framework | Playwright |
| `Package.swift` or an `.xcodeproj` | XCTest |
| `app.json` with Expo, or Detox configured | Detox |
| None of these | Ask |

If Playwright isn't installed, say what to run, `npm init playwright@latest` inside `app/`, and offer to do it. Don't install without a yes.

## The rules that keep tests honest

- **Find things the way a person does**: by role and name (`getByRole`, `getByLabel`), not by CSS selectors or test IDs where a role exists.
- **Never wait a fixed time.** Wait for a condition: an element visible, a request finished.
- **Every test stands alone.** No shared state, no order dependence.
- **The base URL lives in the config,** never in a test.
- **Accessibility is a test**, not a hope: an axe check on every page.

## Flow

1. **Find the targets.** From the PRD and the phases. The critical flows (navigation, forms, the calls to action), every route loading cleanly, interactive components, key breakpoints, and an accessibility check per page. If `/camp build` is calling this at the end of a phase, the target is that phase's flow.
2. **Present the plan:** which tests, what each proves, which requirement it traces to. Wait.
3. **Write them** in `app/tests/`:

   ```
   app/tests/
     navigation.spec.ts    routes and links
     pages.spec.ts         every page loads without error
     accessibility.spec.ts axe on every page
     [flow].spec.ts        one file per flow
   ```

4. **Run them** from inside `app/`: `npx playwright test`, `swift test`, or `detox test`. Report what passed and what didn't.
5. **If a test fails**, say whether the test or the code is wrong before touching either. A test that fails because the product has a bug is a finding for the user, not something to make pass.

## Patterns

Web:

```ts
import { test, expect } from "@playwright/test";

test.describe("Navigation", () => {
  test("every main link leads somewhere real", async ({ page }) => {
    await page.goto("/");
    const nav = page.getByRole("navigation");
    await expect(nav).toBeVisible();
    for (const link of await nav.getByRole("link").all()) {
      const href = await link.getAttribute("href");
      if (href?.startsWith("/")) {
        await link.click();
        await expect(page).not.toHaveURL(/error|404/);
        await page.goto("/");
      }
    }
  });
});
```

Accessibility, on every page:

```ts
import AxeBuilder from "@axe-core/playwright";

test("home has no accessibility violations", async ({ page }) => {
  await page.goto("/");
  const results = await new AxeBuilder({ page }).analyze();
  expect(results.violations).toEqual([]);
});
```

iOS:

```swift
final class ModelTests: XCTestCase {
    func testFetchReturnsItems() async throws {
        let result = try await Model().fetch()
        XCTAssertFalse(result.isEmpty)
    }
}
```

React Native:

```ts
describe("Home", () => {
  beforeEach(async () => { await device.reloadReactNative(); });
  it("shows the home screen", async () => {
    await expect(element(by.id("home-screen"))).toBeVisible();
  });
});
```

## Outputs

| File | What it contains |
|---|---|
| `app/tests/*.spec.ts` (or the platform's equivalent) | The approved tests |

## Anti-patterns

- Testing implementation details. Test what a person sees and does.
- `waitForTimeout`. Ever.
- Making a failing test pass by loosening it.
- Writing tests before the plan is approved.

## When `/test` is not the right skill

- Checking quality without tests → `/review`.
- Accessibility to a standard, with a report → `/a11y-audit`.
- Running the checks before a push → `/ship`, which runs these tests.
