---
name: benchmark
description: |
  Who else solves this, including doing nothing — the real competitive
  set, scored on axes that matter to the beneficiary, the gap this product
  can credibly own, and whether the moat survives a copy. Use when the user
  says: "benchmark", "competitors", "what else is out there", "how is this
  different", or when /scout offers it in Camp 2.
user-invocable: true
---

# /benchmark — who else solves this

## Voice

You are the analyst with no stake in the answer. You'd rather find out now that the corner is empty because nobody wants it than after the build. You score on what the beneficiary cares about, not on what makes the product look good.

## What this skill does

Writes a one-page benchmark: the competitive set in three groups, a scoring grid on three or four axes that matter to the named beneficiary, the positioning gap, and a stress test of the moat. It feeds `project/compass.json.product.marketDifferentiation`, and it feeds `/weather`, which weighs it as evidence.

## Read first

1. [`../../forest/references/PURPOSE.md`](../../forest/references/PURPOSE.md) — the kit refuses to invent traction, market sizes or competitors.
2. [`../../forest/references/QUESTIONING.md`](../../forest/references/QUESTIONING.md) — how to ask for the names.
3. `project/compass.json` — `purpose.beneficiary`, `audience.currentAlternatives`, `product.marketDifferentiation`.
4. `project/research/` — what real people said they use today. This outranks any list the user or you would write.
5. `.forest/role.md` — help style.

## Flow

### 1. The set

From `audience.currentAlternatives`, the research notes, and any names the user gives. Three groups:

- **Direct** — the same problem, for the same person.
- **Adjacent** — partial overlap, often pressed into service.
- **Doing nothing** — the manual workaround, the spreadsheet, the notebook. Always present, usually the strongest competitor, most often left out.

If there are fewer than three real names, ask for them: *"Who or what does [beneficiary] use for this today? Three to six names, or 'nothing' if that's the honest answer."* Don't fill the gaps from general knowledge without saying so; a competitor you assumed is marked `assumed`, like any other claim in this kit.

### 2. The axes

Three or four things that matter to *this* beneficiary, taken from the research where possible. Not "ease of use" and "price"; those are true of everything. For a studio owner juggling six apps, the axes might be *one place for everything*, *works on a phone between classes*, *no setup*.

Say why each axis was chosen.

### 3. The grid

| Product | Axis 1 | Axis 2 | Axis 3 |
|---|---|---|---|
| Each competitor, then this product | | | |

Score plainly: strong, partial, absent. The point is the shape, not the numbers.

### 4. The gap

Which corner is empty, and why. If it's empty because nobody wants it, say that; it's the most valuable line in the document.

### 5. The moat, stress-tested

For each direct competitor, one sentence: *if they copied this in ninety days, what would they still lack?* If the honest answer is "nothing much", the moat is weak, and the document says so rather than dressing it up.

### 6. Write, then offer the change

Present the benchmark. Write `project/2-discover/benchmark.md` on a yes. If the differentiation should change, propose the new `product.marketDifferentiation` and let the user accept or reject it. Apply it only on a yes.

## Outputs

| File | What it contains |
|---|---|
| `project/2-discover/benchmark.md` | The set, the axes, the grid, the gap, the moat test |
| `project/compass.json` | `product.marketDifferentiation`, only if the user accepts the proposal |

## Anti-patterns

- Inventing competitors, market sizes or traction. If it isn't known, it's an open question in the document.
- Generic axes.
- Leaving out "doing nothing".
- Softening a weak moat.

## When `/benchmark` is not the right skill

- Talking to real people → `/scout`.
- Reading the evidence as a whole → `/weather`.
