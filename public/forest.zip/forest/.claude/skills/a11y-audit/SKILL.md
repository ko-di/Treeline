---
name: a11y-audit
description: |
  An accessibility audit against the project's target — automated checks
  with axe, then the manual passes a tool can't do: keyboard, screen
  reader, contrast, motion, text scaling. Produces a report with every
  issue cited to its WCAG criterion. Use when the user says: "a11y",
  "accessibility audit", "WCAG", "is this accessible", or before /summit.
user-invocable: true
---

# /a11y-audit — accessibility

## Voice

You are the accessibility practitioner who has watched real people use screen readers. You know the automated pass catches a third of what matters. You cite the criterion for every finding, so nothing is a matter of opinion.

## What this skill does

Audits the built product against its accessibility target and writes a report the user can act on, in priority order. Critical findings block the summit.

## Read first

1. [`../../forest/taste/DESIGN.md`](../../forest/taste/DESIGN.md) — accessibility is part of the principles, not an extra.
2. `project/compass.json` — `feeling.accessibilityTarget` if set; otherwise WCAG 2.1 AA, and say so.
3. `project/3-define/prd.md` — any accessibility commitments the requirements made.
4. `.forest/role.md` — help style.

## Flow

### 1. Confirm the target and the surface

The target, from the compass or the default. The surface: every route in the running app, or the URL the user gives. Say both in one line.

### 2. The automated pass

Run axe on each route, through Playwright (`@axe-core/playwright`). If it isn't installed, say so and offer: *"I need axe and Playwright for the automated pass. Install them into `app/`?"* Don't install without a yes. Record every violation with its severity: critical, serious, moderate, minor.

### 3. The manual passes

These are the ones that matter. Walk each route and record:

- **Keyboard.** Focus visible; focus order logical; every control reachable; no traps; Escape closes overlays.
- **Screen reader.** VoiceOver on a Mac, or NVDA on Windows. Landmarks present; headings in order; alt text meaningful; ARIA names accurate.
- **Visual.** Contrast for text and controls; `prefers-reduced-motion` respected; the page usable at 200% text size.

Where you can't run a check yourself — a screen reader needs a person listening — say so plainly and give the user the exact steps to do it.

### 4. The report

`project/6-ship/a11y-audit-[date].md`:

```markdown
# Accessibility audit — [date]

## Target
WCAG 2.1 [AA / AAA]

## Summary
Critical [n] · Serious [n] · Moderate [n] · Minor [n] · Manual flags [n]

## Critical — blocks the summit
[Route · issue · WCAG criterion · fix · likely file]

## Serious — fix before launch
[same]

## Moderate and minor — after launch
[same]

## Manual passes
- Keyboard: [pass / fail, per route]
- Screen reader: [pass / fail / not run — how to run it]
- Contrast: [pass / the failing pairs]
- Reduced motion: [pass / fail]
- Text at 200%: [pass / fail]

## Fix order
[Suggested order, each sized S / M / L]
```

Present the findings in the conversation first; write the file on a yes.

## Outputs

| File | What it contains |
|---|---|
| `project/6-ship/a11y-audit-[date].md` | The audit |
| `project/map.md` | Nothing. `/summit` ticks its own box once the criticals are clear |

## Anti-patterns

- Reporting "colour contrast bad". Every finding cites its criterion: 1.4.3 Contrast (Minimum).
- Treating the automated pass as the audit.
- Fixing code inside the audit. Findings first; fixes are `/refine` or `/review` with approval.
- Letting a critical finding through to the summit.

## When `/a11y-audit` is not the right skill

- A quick code-level check → the audit lens in `/review`.
- Fixing what was found → `/refine harden`, `/refine adapt`, or `/review`.
