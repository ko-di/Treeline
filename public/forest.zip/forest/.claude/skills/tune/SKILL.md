---
name: tune
description: |
  Push an existing design in one direction — bolder, quieter, colourise,
  normalise — without a full review. Findings first, changes on a yes.
  Use when the user says: "tune", "bolder", "it's too safe", "quieter",
  "too loud", "it needs colour", "it's flat", "normalise", "hardcoded
  values", "bring it back to the system".
user-invocable: true
---

# /tune — change the energy

## Voice

You are the design director stepping in for one note. You know what the work needs, you say it in specifics, and you don't touch it until the maker agrees.

## What this skill does

One skill, four directions. Each reads `app/` (or the named file) against the project's design and proposes concrete changes in one direction.

| Direction | When | Reference |
|---|---|---|
| `bolder` | It's too safe. Amplify the hierarchy, make decisive moves | [`references/bolder.md`](references/bolder.md) |
| `quieter` | It's too loud. Reduce the noise, restore restraint | [`references/quieter.md`](references/quieter.md) |
| `colourise` | It's flat. Add colour that communicates | [`references/colourise.md`](references/colourise.md) |
| `normalise` | It has drifted. Bring every value back to the tokens | [`references/normalise.md`](references/normalise.md) |

## Read first

1. [`../../forest/taste/DESIGN.md`](../../forest/taste/DESIGN.md).
2. [`../../forest/taste/BRAND.md`](../../forest/taste/BRAND.md) — for what colour and voice are for.
3. [`../../forest/taste/INSPIRATIONS.md`](../../forest/taste/INSPIRATIONS.md) — the level of confidence and restraint to aim at.
4. `project/design/design.md` — the tokens and the direction. Tuning happens *within* the direction, never against it. If it doesn't exist, say so: `/sketch` writes it.
5. `project/compass.json.feeling` — the intended character.
6. `.forest/role.md` — help style.

## Flow

1. **Pick the direction.** From what the user typed. If unclear, ask once, with one line on each. Say why: each is a different reading, and they pull in different directions.
2. **Scope.** The named file, or all of `app/`. One line.
3. **Read the reference** and apply it.
4. **Report** as the reference shapes it, with the exact change for each item: the token, the value, the class. Not "make it bolder".
5. **Wait**, then apply approved items one at a time.

Two directions in sequence ("quieter, then normalise") each get their own report and approval.

## Outputs

| File | What it contains |
|---|---|
| The tuned files in `app/` | Only the approved changes |
| `project/design/design.md` | Only if a tuning changes a token — then the change is recorded there too, so the system stays the source of truth |

## Anti-patterns

- Tuning against the direction in `design.md`. If the direction is wrong, that's `/sketch` again, not a tune.
- Vague proposals. Every item names its value.
- Adding a second accent to "add colour". One accent, used with discipline.
- Editing before approval.

## When `/tune` is not the right skill

- A full check → `/review`.
- A new direction → `/sketch`.
- Strength rather than energy (errors, speed, mobile, copy, first run) → `/refine`.
