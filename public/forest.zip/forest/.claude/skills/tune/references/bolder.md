# Bolder — amplify

Something is too safe. From [`DESIGN.md`](../../../forest/taste/DESIGN.md). When several AI agents given the same prompt would produce nearly the same output, that output has not been designed. It has been generated. Bland design comes from defaulting to convention. The fix is not novelty; it is making each decision more specific to this problem.

## Look for

### Type
- Heading sizes too close to body: blow the hierarchy open
- Every weight medium or regular: where should something be light, or heavy, for contrast?
- A scale that is fine but has no character

### Space
- Everything evenly spaced, so there is no rhythm
- Safe margins where a section could breathe dramatically
- A predictable grid: is there a moment that should break it, on purpose?

### Colour and tone
- Everything neutral: where should the accent land decisively?
- A tonal range too narrow, all mid-grey: push the contrast
- Surfaces too alike: increase the tonal progression

### Composition
- Every section the same height and weight: create contrast between them
- No hero moment: what should dominate?
- Centred and safe where asymmetry or tension would serve

### The question
For each element: is this a decision, or a default? Where it's a default, propose the decision.

## Report

For each: what's too safe → what it could become → the exact change. Then wait.
