# Normalise — back to the system

Pull everything back to the tokens. From [`DESIGN.md`](../../../forest/taste/DESIGN.md): a component that appears in two places with two treatments is not a variant, it is a contradiction; every colour, measure and interval must derive from the token system, and a hardcoded value is one that has escaped the order. Read the project's own tokens: `project/design/design.md`, and the CSS custom properties, theme or config that implement them.

## Look for

### Escaped values
- Hex or rgb colours instead of tokens
- Pixel spacing instead of the scale
- Font sizes outside the type scale
- Magic numbers in margins, paddings, gaps

### Inconsistent components
- The same component with different padding, colour or borders in different places
- Similar elements — cards, buttons, links — styled inconsistently
- Variants that drifted apart for no reason

### Gaps in the system
- Values used repeatedly that should be tokens and aren't
- Colours in use that the palette doesn't contain
- Spacing outside the scale

### Depth
- Borders and shadows mixed: one method, everywhere
- Border widths or shadow values varying on similar elements

### For each
Name the escaped value, the token it should use, and, where no token exists, the gap that needs one defined in `design.md`.

## Report

A table: `| Where | Now | Should be | Category |`, grouped by colour, spacing, type, depth. Then wait.
