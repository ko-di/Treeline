# Quieter — restrain

Something is too loud. From [`INSPIRATIONS.md`](../../../forest/taste/INSPIRATIONS.md): the shared quality of the work worth reaching for is editorial restraint — content leads, chrome disappears — and a confident quietness. Loud design comes from too many elements competing. The fix is choosing what matters and subordinating everything else. See *Reduce Until It Breaks* and *Errors of Practice* in [`DESIGN.md`](../../../forest/taste/DESIGN.md).

## Look for

### Competition
- More than one accent colour
- Too many visual events on one screen
- Borders louder than the content they divide
- Decorative gradients: colour must communicate, not decorate

### Weight
- Bold where semibold would do
- Sizes too large for their level
- Shadows too heavy, or layered
- Radius so generous it reads as playful

### Motion
- Springs or bounce in transitions: controlled easing, per [`MOTION.md`](../../../forest/taste/MOTION.md)
- Too much animating at once
- Motion drawing the eye to chrome instead of content
- Entrances that delay the content

### Surfaces
- Too many surface levels or card layers
- Background colour varying for no reason
- Patterns or textures carrying no information

### The question
For each loud element: is it serving the content, or competing with it?

## Report

For each: what's too loud → why it competes → how to quiet it, exactly. Then wait.
