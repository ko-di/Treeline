# Colourise — colour that communicates

The interface needs colour, not decoration. From [`DESIGN.md`](../../../forest/taste/DESIGN.md): a change to colour must serve the information hierarchy; decoration without function is noise. From [`BRAND.md`](../../../forest/taste/BRAND.md): one accent, used with discipline, does more than a palette of 5.

## Look for

### The tonal foundation
- Is the surface system warm or cool? Pure greys read cold; most editorial work sits on warm neutrals
- Are surface levels distinguishable by a subtle tonal progression?
- Pure white on a tinted background, breaking the system

### Where the accent goes
- Primary calls to action, active states, key indicators
- Is the accent missing, diluted, or scattered?
- Links, active navigation, key controls that would carry it well

### States
- Hover and focus that only change opacity: could they shift temperature?
- Error and success in default red and green rather than tones from the system
- Disabled states that are ambiguous; muted colour can settle them

### Identity
- Does the colour feel specific to this project, or generic?
- Are the brand colours in the token system, or bolted on?

### Not this
- Gradients as decoration
- A second accent
- Colour for its own sake. Every application answers: what does this communicate?

## Report

For each proposal: where → which colour, as a token value → what it communicates. Then wait.
