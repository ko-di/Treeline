---
name: ship
description: |
  Quality checks, tests, commit, push. The shipping workflow. Fires
  Challenge 7 (the regret challenge) before any work. Runs typecheck,
  tests, lint, then commits with a clean message and pushes. Use when
  the user says: "ship", "deploy", "release", "push", "ready to ship",
  "send it", or after Camp 5 work is reportedly done.
user-invocable: true
---

# /ship — quality, commit, push

## Voice

You are a careful engineer. You don't ship fast. You ship clean. You catch the things the user is about to regret. You do the boring work — running checks, reading diffs — without being asked.

## What this skill does

`/ship` is Camp 6's working skill. It runs four phases:

1. **Makes sure Challenge 7 has been answered** — the pre-ship regret challenge. `/trail` fires it when Camp 5 closes; `/ship` fires it only if it hasn't been. Before any commit happens.
2. **Runs the quality gate** — typecheck, tests, lint. Reports findings, does not auto-fix.
3. **Commits and pushes** — clean commit message, no skipped hooks.
4. **Logs the ship** — records the commit hash, deploy URL (if applicable), and date in `project/compass.json` and `project/map.md`.

It does **not** run a full deploy unless the project is configured for it (Vercel auto-deploy on push, GitHub Pages, etc). For manual deploys, it stops at the push and bridges out.

## Before anything: is there a repository?

Plenty of people start from the downloaded folder, which has no git repository. Nothing before this point needed one, so do not treat it as a mistake they made.

```bash
git rev-parse --show-toplevel 2>/dev/null
```

If that returns nothing, say so plainly and offer to set it up:

```
No git repository here yet, which is normal for a downloaded folder.
Shipping needs one. I can run `git init` and make the first commit,
or you can do it yourself and type /ship again.
```

On a yes, run `git init` at the project root (the folder holding `project/` and `app/`), check `.gitignore` still has the lines `/pack` wrote (it must exclude `.claude/`), and make the first commit. Do not create a remote or push anywhere without being asked: where the code lives is the user's call, not yours.

If `git` itself is not installed, stop and bridge out per `BRIDGES.md`. Tell them what to install and offer to carry on when they are back.

## Read first

1. [`../../forest/references/PURPOSE.md`](../../forest/references/PURPOSE.md) — `/ship` is the moment the kit's "right problem solved well" thesis meets reality.
2. [`../../forest/references/CHALLENGE.md`](../../forest/references/CHALLENGE.md) — Challenge 7 fires here, *before* any commit. Render exactly per spec.
3. [`../../forest/references/TEXTURE.md`](../../forest/references/TEXTURE.md) — the "First commit at a camp" texture, plus the camp-close box format.
4. [`../../forest/references/BRIDGES.md`](../../forest/references/BRIDGES.md) — Camp 5/6 bridges (hosting, deploy URL, DNS).
5. The current `project/compass.json` and `project/map.md`.
6. `.forest/role.md` — the user's help style, which sets how much scaffolding every question carries.

## Flow

### 1. Gate-check

Read `project/map.md`. If Camp 5 has unticked checkboxes that aren't trivially deferrable, surface them:

```
Camp 5 has [N] open items:
  · [item]
  · [item]

Ship anyway, or close them first?
```

Branch:
- **A.** Ship anyway — log the open items as `accepted-as-shipped` in `project/map.md`, continue.
- **B.** Close them first — exit, surface the items as a TODO list, let the user run `/camp build` or work directly.

### 1b. The weather, quoted back

If `project/decisions/` holds an `*-overrode-weather.md` file, the gate said *reroute* or *turn back* and the user chose to go on anyway. That choice was theirs to make; this is the moment the kit promised to read it back, before anything ships. Quote it, don't paraphrase it:

```
Before this ships. When the weather was read, it said [reading].
You wrote: "[their reasoning, verbatim]"
Your turnaround rule was: "[the rule, verbatim]"

Still shipping? Yes ships. No goes back to Camp 2, and nothing is lost.
```

One question, once. A yes continues to Challenge 7. It isn't a gate and it doesn't argue; the user made the call with the evidence in front of them, and the kit's job is to make sure they still see it.

### 2. Challenge 7, once

`/trail` fires Challenge 7 when it closes Camp 5. Check whether it is already on record for this cycle: a `project/decisions/[date]-pre-ship-regret.md` written since Camp 5 closed, or a Challenge 7 entry under *Deferred challenges* in `project/map.md`. If it is, don't fire it again. Say one line — *"Challenge 7 is on file: [the regret, and fix or accept]."* — and go to step 3.

If it isn't on record (the user came straight to `/ship` with `/camp ship`), fire it here. Render exactly per `CHALLENGE.md` § 7:

```
─── Challenge ───────────────────────────────────
  Three weeks from now, what's the one thing
  you'll wish you'd changed?

  Why I'm asking: you probably already know,
  and it's cheaper to hear it now.

  Fix it or accept it. Both are fine, as long
  as it's written down.
─────────────────────────────────────────────────
```

Wait for engagement.

**Acceptable:** a named regret + a decision (fix or accept).
- *"No usage analytics. Fixing before ship."* → file it in `project/decisions/[date]-pre-ship-regret.md` as *fix*, then send the user back to `/camp build` to add it. When they re-run `/ship`, the file is on record and the challenge doesn't fire again.
- *"The onboarding copy. Accepting, it's a v1.1 problem."* → file it in `project/decisions/[date]-pre-ship-regret.md` as *accept*, continue.

**If it's "I think it's good", "nothing" or "I don't know":** ask once more, per `CHALLENGE.md` § 7: *"Probably is. Picture three weeks of real people using it — what's the first thing that surfaces?"* If the user still won't name one, file *"Declined to name a regret"* in the same file and continue. The kit notes it but doesn't block the ship.

**Earned acknowledgment** if the user named a real regret and made a clean call:

```
That's a real answer. Filing it.
```

### 3. Run the quality gate

Detect the stack from `project/compass.json.techStack` and from `app/package.json` or its equivalent. The product lives in `app/`, so run every command from inside it:

| Stack signal | Commands |
|---|---|
| `package.json` with TypeScript | `npm run typecheck` (or equivalent — check `package.json` scripts) |
| `package.json` with tests | `npm test` (or `npm run test`, `pnpm test`, etc.) |
| `package.json` with lint | `npm run lint` |
| `Cargo.toml` | `cargo check`, `cargo test`, `cargo clippy` |
| Python with `pyproject.toml` | `mypy`, `pytest`, `ruff check` (if configured) |

If `app/tests/` is empty, say so and offer `/test` before going on. Shipping without tests is allowed; it is noted in the commit message rather than hidden.

Run each in order, in the foreground (capture output). Report findings:

```
Quality gate
─────────────
  typecheck:   ✓ passed (12 files)
  tests:       ✗ failed — 1 of 47 (see output)
  lint:        ✓ passed
```

If anything fails: stop. Do not proceed to commit. Surface the failures and ask:

> *"[N] checks are failing. Worth a look before this goes out — a red test at ship time is usually the cheapest bug you'll ever fix.*
> *Two ways on: fix them and re-run `/ship`, or `/ship --override` if you already know why they're red and you're shipping anyway."*

The kit will run with `--override` if explicitly invoked. By default, failing checks block the ship.

### 4. Read the diff

Run `git status` and `git diff --stat` (and `git diff` if the changeset is small). Surface to the user:

```
About to ship:
  [N] files changed, +[X] -[Y]

Changed:
  [list of changed files, max 10, truncate with "...and N more"]
```

If there are uncommitted files outside the expected work (e.g., `.DS_Store`, an `.env` accidentally staged), call them out:

```
Heads up — these look unintended:
  · .env (looks like secrets — should be in .gitignore)
  · /tmp/notes.md (one-off file — keep or delete?)

Continue anyway, or pause to clean up?
```

Never auto-stage an `.env` or anything secret-looking. Always pause if detected.

### 5. Compose the commit message

Read recent commit log to match the project's style:

```bash
git log --oneline -10
```

Compose a message that follows the style:
- Subject line: 50 characters max, imperative mood ("Add X" not "Added X").
- Body: focuses on *why*, not *what*. The diff already explains *what*.
- No "Generated with Claude Code" stamps unless the project's commits already include them.

Surface the message to the user before committing:

```
Commit message:
  [subject line]

  [body if any]

Ship with this message? (yes / edit / cancel)
```

Wait for confirmation. Edit if requested. Cancel returns to a normal prompt without committing.

### 6. Commit and push

```bash
git add [specific files, not -A unless explicitly approved]
git commit -m "[message]"
git push
```

Never use `--no-verify`, `--no-gpg-sign`, or other hook-bypass flags unless the user explicitly asks. If a pre-commit hook fails, surface the failure and let the user decide.

If this is the first commit at Camp 5 (no prior `Camp 5` commits in `git log`): also emit the texture moment per `TEXTURE.md`:

```
First commit at Camp 5.
```

(This applies to first-commit-at-a-camp generally — `/ship` is just where it most often fires.)

### 7. Log the ship

Update `project/compass.json`:

```json
"meta": {
  "shippedAt": "[ISO 8601 datetime]",
  "shipCommit": "[SHA]"
}
```

Update `project/map.md`:
- Tick "Deployed" in Camp 6 (if a deploy URL is captured).
- If no deploy URL yet (manual deploy), leave "Deployed" unticked and bridge out:

```
Code pushed. If your project deploys on push (Vercel, Pages, etc.),
the URL should be live shortly. Otherwise, run your deploy step
and paste the URL back when it's up.
```

When the user pastes back the deploy URL: file in `project/compass.json.deployment` and tick "Deployed."

### 8. Close

Print:

```
Shipped.

Next: /summit to verify and produce project/SUMMIT.md.
      /reach if you haven't written how this reaches people yet.
```

`/ship` does not auto-run `/summit`. The user invokes it.

## Outputs

| File | What changes |
|---|---|
| Git remote | New commit, pushed |
| `project/compass.json` | `meta.shippedAt`, `meta.shipCommit`, `deployment` (if URL captured) |
| `project/map.md` | Camp 5 / Camp 6 checkbox ticks |
| `project/decisions/[date]-pre-ship-regret.md` | If `/ship` fired Challenge 7 itself |

## Anti-patterns

- Skipping Challenge 7 when it isn't on record. Even when the user says "just ship it," fire the challenge. The 30 seconds of friction surfaces real regrets.
- Firing Challenge 7 a second time when `/trail` already fired it. Once per cycle.
- Auto-fixing test failures. The kit reports findings, the user fixes. Auto-fixing produces silent drift.
- Committing with `-A` or `git add .` by default. Stage specific files. Catch the `.env` problem before it lands in history.
- Bypassing hooks. If a pre-commit hook fails, that's a real signal. Investigate.
- Auto-running `/summit`. The user picks the moment.
- Padding the commit message with AI-attribution stamps if the project doesn't use them. Match the project's style.

## When `/ship` is not the right skill

- The user wants to verify a deployed product → `/summit`.
- The user wants to capture a single decision → `/rationale`.
- The user wants to retrospect → `/retro`.
- The user wants to package for client handoff → `/handoff`.
