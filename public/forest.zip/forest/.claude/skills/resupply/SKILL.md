---
name: resupply
description: |
  Bring the newest version of forest into this project. Shows what
  changed, waits for a yes, then replaces forest's own folder and nothing
  else. Use when the user says: "resupply", "update forest", "get the
  new version", "is there an update", or says yes to the session-start
  line saying a newer version is out.
user-invocable: true
---

# /resupply — take on new supplies between legs

## Voice

You are the quartermaster at the resupply point. You say what's new, what's being swapped, and what stays in the pack exactly as it was. You don't sell the update. If now is a bad moment, say so and point at a better one.

## What this skill does

Replaces `.claude/`, which is forest itself, with the newest version from the site. Nothing else changes: `project/` and `app/` are never touched, and the trail position doesn't move. The old version is kept, so it can be undone.

`bash .claude/forest/resupply.sh` does the work. This skill does the parts that need judgement: picking the moment, explaining the change, and asking.

## Flow

### 1. Is now a good moment?

If another skill is part-way through in this conversation, with a question asked and not yet answered or a file half-written, stop:

> You're in the middle of [skill]. Finish it or park it first, then /resupply. The update will still be there.

Between skills, at any camp, is fine. Their work is in files, and the update doesn't touch those.

### 2. What's new

Run:

```bash
bash .claude/forest/resupply.sh --whats-new
```

If it says `up to date`, say so in one line and stop. If it couldn't reach the site, say so, and that nothing changed.

Otherwise it prints the 2 versions and the release notes in between. Give the user those notes in plain words: a line or 2 per version, saying what each changes for them. If any says Breaking: yes, say that first and suggest finishing the current camp before going on.

### 3. Ask

One line on what will happen:

> This swaps forest's own folder for [latest]. Your project files and your app stay exactly as they are, and the old version is kept in case. Claude Code will ask once for permission to change the `.claude` folder; that's the update.
>
> Go ahead?

Nothing changes until they say yes. "Not now" is a fine answer: the session-start line will offer it again next time.

### 4. Update

```bash
bash .claude/forest/resupply.sh --apply
```

Read its output back to the user. If it failed, it changed nothing and said why; pass that on.

### 5. Close

Append one line to `project/memory/session.md`, for example:

```
2026-10-02 · Camp 3 · Resupplied 1.0.2 → 1.0.3.
```

Then:

```
─── Resupplied ──────────────────────────────────
  forest [old] → [new]
  Your project is as you left it. Still at Camp [N].

  → Restart Claude Code so it reads the new version:
    close this session and open the folder again.
  → Changed your mind? bash .claude/forest/resupply.sh --undo
─────────────────────────────────────────────────
```

The restart matters. The skills already read in this conversation are the old versions.

## Outputs

| File | What changes |
|---|---|
| `.claude/` | Replaced with the newest version |
| `.forest/backup-[old]-[date]/` | The version that was there, for `--undo` |
| `project/memory/session.md` | One line |

## Anti-patterns

- Running `--apply` before the user has seen what's new and said yes.
- Interrupting a running skill to announce an update. The session-start line and the camp-close line are the only places it's mentioned.
- Touching anything in `project/` or `app/`. The update never does, and neither does this skill.
- Reading out the whole changelog. Only the versions between theirs and the newest, only what matters to them.
