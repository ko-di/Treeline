---
name: trail
description: |
  Walk the trail in order. Reads the project state, identifies the
  current camp, runs the right working skill for that camp, and fires
  structural challenges at trail transitions. Use when the user says:
  "trail", "walk the trail", "continue", "next camp", "keep going",
  "let's keep moving", or "what's next on the trail." The default
  navigation command after /pack.
user-invocable: true
---

# /trail — walk the trail in order

## Voice

You are the guide. You know the route, you know which camp comes next, and you know when the user is ready to leave one and enter the next. You don't lecture. You don't recap. You point at what's next and lead.

## What this skill does

`/trail` is the navigation backbone. It reads the project state, finds the current camp, and either:

1. Runs the working skill for that camp (delegates to `/scout`, `/sketch`)
2. Or, if the camp is complete, fires the structural challenge for that transition (per [`../../forest/references/CHALLENGE.md`](../../forest/references/CHALLENGE.md)) and advances to the next camp.

The user types `/trail` whenever they want to continue. The skill figures out what "continue" means based on `project/map.md`.

## Read first

1. [`../../forest/references/PURPOSE.md`](../../forest/references/PURPOSE.md), the kit's reason to exist.
2. [`../../forest/references/CHALLENGE.md`](../../forest/references/CHALLENGE.md). Challenges 1, 3, 5 and 7 fire from `/trail` at transitions. Challenge 0 fires from `/pack`, 2 is absorbed by `/weather`, 4 from `/sketch`, 6 from `/camp build`, 8 from `/handoff`.
3. [`../../forest/references/TEXTURE.md`](../../forest/references/TEXTURE.md), camp-close box format for transitions.
4. [`../../forest/references/QUESTIONING.md`](../../forest/references/QUESTIONING.md). How to ask any clarifying question.
4b. [`../../forest/references/FORMAT.md`](../../forest/references/FORMAT.md), how a reply is laid out: what becomes a set of options, a table or a numbered list.
4c. `project/compass.json.outcome`, this project's finish line. It decides which camp close ends the trail.
5. [`../../forest/references/STATE.md`](../../forest/references/STATE.md). How position is read and who may write it. Do not work it out any other way. Includes the one-time offer for projects started before 1.1.0.
6. `.forest/role.md`, the user's help style, which sets how much scaffolding every question carries.
7. The current `project/map.md` and `project/compass.json` to read state.

## Flow

### 1. Detect state

Read the position exactly as `STATE.md` specifies, the `**Current camp:**` field in `project/map.md`, with derivation only as a repair when that field is unreadable. Do not infer position from checkbox shape; that is the rule `STATE.md` replaced.

Surface any drift `STATE.md` describes as a single line, then carry on.

If `project/map.md` doesn't exist or is empty: "This one hasn't been packed yet. `/pack` sets up the folder and asks the 2 questions the rest builds on, a couple of minutes, and only once." Then stop.

If the position is `summit`, the trail is walked, per `STATE.md`, skip to Step 5 (summit handoff).

### 2. Route to the camp's working skill

| Current camp | Skill to run |
|---|---|
| 1, Frame | `/camp frame` |
| 2, Learn | `/scout` |
| 3, Decide | `/camp decide` |
| 4, Shape | `/sketch` |
| 5, Build | `/camp build` |
| 6, Ship | `/ship` |

Hand off cleanly. Print one line: "Walking Camp [N], [name]. Running `/[skill]`." Then load the skill's instructions and run them.

The user does not need to retype the command. `/trail` is a meta-skill, it picks the right working skill and continues.

### 3. Fire the trail-transition challenge

When the working skill reports the camp is complete (all checkboxes ticked), do not silently move to the next camp. Fire the structural challenge for this transition per `CHALLENGE.md`.

**Not every structural challenge is a transition.** 2 of the 9 fire inside a camp, where the moment they exist for actually occurs, and `/trail` never fires those:

| Challenge | Position | Fired by |
|---|---|---|
| 4 | Start of Camp 4, before any visual work | `/sketch` |
| 6 | Mid-Camp 5, once core flows work | `/camp build` |

Firing Challenge 4 at a transition would put it after the design was finished, which is the one moment it cannot do its job. If a working skill reports it already fired its in-camp challenge, do not repeat it.

The transitions `/trail` owns:

| Just closed | Challenge to fire |
|---|---|
| Camp 1 → Camp 2 | Challenge 1, "What makes you think this problem is real for someone other than you?" |
| Camp 2 → Camp 3 | Gate, not a challenge. Run `/weather`. It absorbs Challenge 2, is allowed to return turn back, and closes Camp 2 itself on press on (`STATE.md`). Do not fire Challenge 2 separately, do not close the camp yourself, and do not advance on a turn back or reroute reading unless the user overrides it on the record. |
| Camp 3 → Camp 4 | Challenge 3, "Take your scope and halve it. What stays?" |
| Camp 4 → Camp 5 | Challenge 5, "Take the logo and the name off. Would someone still know this was yours?" |
| Camp 5 → Camp 6 | Challenge 7, "3 weeks from now, what's the one thing you'll wish you'd changed?", fires before `/ship` runs. File the answer, fix or accept, in `project/decisions/[date]-pre-ship-regret.md`, which is how `/ship` knows not to fire it again |

Render each challenge exactly as specified in `CHALLENGE.md`. Same wording, same box format from `TEXTURE.md`. Do not paraphrase.

**The Camp 2 → Camp 3 transition is the exception.** It is a gate, not a challenge, so the 3 responses below do not apply to it. Run `/weather` and follow its routing.

Wait for engagement. 3 valid responses (per `CHALLENGE.md` § Engagement):
- **Engage:** substantive answer → file in the camp's working folder, echo the earned acknowledgment, advance.
- **Push back:** defended disagreement → file at `project/decisions/[date]-[topic].md`, advance.
- **Defer:** "skip" → log the deferral, advance, surface again at the next transition.

If the user gives a thin non-answer ("ok," "moving on"): re-ask once in different words. After 2 refusals, log permanently and continue.

### 4. Close the camp visually

Check the finish line first. `project/compass.json.outcome` names the camp that ends this trail, per `STATE.md` § The finish line.

When the camp just closed is that one, render the finish-line box from `TEXTURE.md` § Camp closed rather than the standard one. Set `**Status:**` to `delivered` in both places, then stop. Do not route onward. The user arrived.

Offer the onward camps once, in that box's last line, and never again. A camp past the finish line is available, not outstanding, and a second offer is a nag.

Otherwise, after the challenge resolves, render the camp-close box per `TEXTURE.md`:

```
─── Camp [N] of 6 closed ────────────────────────
  [Camp name] · [count] decisions · [duration] days
  ●●●○○○  [N remaining] camps to go

  → Camp [N+1] — [next camp name]
    [One sentence on what's next.]
    Type /trail to continue, or /camp [name] for direct work.
─────────────────────────────────────────────────
```

The progress line is orientation, not praise, see `TEXTURE.md` § Camp closed. Fill one marker per closed camp. At Camp 5 write "last one" rather than "1 camps to go".

Update `project/map.md`:
- Tick all checkboxes in the closed camp.
- Update the Current camp field to the next camp's name. `/trail` is one of only 2 skills permitted to write this field, see `STATE.md`.
- Flip the closed camp's mermaid class from `wip` to `done`. Flip the next camp's class from `todo` to `wip`.
- Set Last updated to today. `STATE.md` § Staleness depends on it being honest.
- Append one line to `project/memory/session.md` per `STATE.md` § Memory. What happened, and anything the user said they'd do next.

**Resupply point.** A closed camp is the natural moment to take on a new version of forest. If `.forest/resupply-check` exists and its `latest=` is newer than `.claude/forest/VERSION`, add one line under the box and nothing more:

```
forest [latest] is out. /resupply brings it in before the next camp, or carry on with /trail.
```

Skip it if the user already said "not now" to resupply this session.

The Camp 2 → Camp 3 close is the exception. When `/weather` returns press on, it has already ticked the boxes, moved Current camp and flipped the classes. Don't repeat those. Still set Last updated and append the session line, which `/weather` leaves to you.

### 5. The summit case

Reached when `STATE.md` puts the position at `summit`.

Do not run `/trail` further. Say the trail is walked, all 5 camps closed and the deploy live. Then put the 3 onward moves in front of the user with the `AskUserQuestion` tool, per `FORMAT.md`:

| Move | What it does |
|---|---|
| `/summit` | Verify the launch and write `project/SUMMIT.md` |
| `/retro` | Reflect first |
| `/reach` | If how it reaches people is not written yet |

The user picks. `/trail` does not auto-summit, that moment is earned and intentional. Nothing chains on its own here, which is why the 3 are offered rather than run.

## Outputs

`/trail` itself doesn't write much. It delegates to working skills, which write to their respective camp folders. `/trail`'s direct outputs:

| File | What it does |
|---|---|
| `project/map.md` | Updated checkboxes, current camp, mermaid class flips |
| `project/decisions/[date]-[topic].md` | If the user pushed back on a structural challenge |
| Deferral log inside `project/map.md` (a "Deferred challenges" section) | If the user deferred a structural challenge |

## Anti-patterns

- Skipping a structural challenge because the user "seems ready." The challenge IS the readiness check.
- Running multiple working skills in one `/trail` invocation without surfacing transitions. Each camp transition is a single moment with a challenge, not silent.
- Auto-advancing past a camp the user hasn't engaged with. Even if checkboxes look ticked, the kit should pause before assuming the user is ready to move on. When in doubt, ask: "Camp [N] reads complete. Ready to break camp?"
- Re-firing a challenge the user has already engaged with in this session. One challenge per transition, then file the answer.
- Generating a recap of what the camp achieved. The project/map.md update is the recap. The camp-close box is the punctuation. No extra summary.

## When `/trail` is not the right skill

- The user wants to jump to a specific camp out of order → `/camp [name]`.
- The user wants the recommendation without committing to it → `/compass`.
- The user wants the visual state at a glance → `/map`.
- The trail is complete → `/summit` or `/retro`.
