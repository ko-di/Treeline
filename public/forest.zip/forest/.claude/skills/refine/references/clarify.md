# Clarify — the words in the interface

From [`DESIGN.md`](../../../forest/taste/DESIGN.md): would the viewer find every important action without instruction? If an element needs explaining, it needs redesigning. The tone comes from `project/compass.json.feeling` and `project/design/design.md`'s voice section, not from a house default.

## Look for

### Labels and navigation
- Vague labels — "Settings", "Manage", "View" — that could name the action
- Developer terms visible to users
- The same thing called different names in different places
- Navigation labels that don't say what's behind them

### Calls to action
- Buttons that don't state the outcome ("Submit" → "Send message")
- Several competing calls with no clear first
- Nowhere for the user to go next

### Helper text
- Fields with no context where the expected input isn't obvious
- Paragraphs where a line would do
- No example where one would help

### Errors
- Errors that blame the user ("Invalid input" → "Enter an email address, like name@example.com")
- Technical errors shown raw
- No way forward named
- Silent failures

### Empty states
- Screens that look broken
- No first action offered
- Generic placeholders ("No items found")

### Tone
- Inconsistent voice across the interface
- Copy that contradicts the intended feeling
- Words not earning their place

## Report

For each: current copy → the problem → suggested copy. Group by page or component. Then wait.
