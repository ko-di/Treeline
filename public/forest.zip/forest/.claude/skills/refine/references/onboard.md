# Onboard — first run and empty states

From [`DESIGN.md`](../../../forest/taste/DESIGN.md): an empty state must lead to a first meaningful action. An empty screen that looks broken is a failure of design, not of data.

## Look for

### Empty states
- Nothing shown when data is absent — does it look broken?
- "No items" with no guidance
- No visual treatment: empty states are designed, not just written
- No clear path to the first action

### First run
- What does a new person see first, and is it the right thing?
- Is the purpose clear without explanation?
- Where is the moment of confusion before they know what to do?
- Is complexity revealed gradually?

### Loading
- Loading states that don't match the resolved layout
- Skeletons shaped differently from the content
- Async operations with no indication
- Loading that reads as broken rather than in progress

### Transitions
- Empty to populated: smooth or jarring?
- Loading to loaded: does the layout shift?
- Error to retry: is the way back clear?

### Content
- Helpful placeholders or examples
- Instructions short and action-led
- Tone consistent with the rest

## Report

Group by: Empty states, First run, Loading, Transitions. For each: what is there now, the problem, the proposal. Then wait.
