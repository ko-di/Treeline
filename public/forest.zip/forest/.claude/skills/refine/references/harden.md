# Harden — resilience

Grounded in Every state is a design problem in [`DESIGN.md`](../../../forest/taste/DESIGN.md).

## Look for

### Errors
- Requests with no error handling and no error state
- Client components with no error boundary
- Errors that take the page down instead of showing a way back
- Error states unstyled or browser-default

### Edges
- No data: null, undefined, empty lists
- Too much data: very long text, many items, large images
- Unexpected data: missing fields, wrong types
- Offline, or a slow connection

### Boundaries
- User content neither sanitised nor bounded
- Long strings with no truncation or wrapping strategy
- No fallback image or placeholder
- Numbers shown unformatted

### Forms
- Submission without validation
- No loading state while submitting
- Nothing preventing a double submit
- Everything typed lost on error

### Other languages
- Strings hardcoded where they may need extracting
- Dates and numbers formatted for one locale
- Layouts that break with longer text
- Right-to-left, where it applies

### Defence
- Optional chaining where data may be missing
- Fallbacks for content that may not exist yet
- Images without a sizing strategy
- Dynamic routes with no not-found handling

## Report

Grade by risk: High (breaks the experience), Medium (degrades it), Low (an edge case). For each: the scenario, where (file:line), the fix. Then wait.
