# Optimise — performance

The rules in [`STACK.md`](../../../forest/taste/STACK.md) are not negotiable. Native scroll. Images through a CDN. No `backdrop-blur` on anything that moves with scroll. Animation on `transform` and `opacity` only. `will-change` only when measured.

## Look for

### Rendering
- Client components that could be server components
- Re-renders wider than the change
- Expensive computation rerun where memoisation belongs
- Context providers wrapping more than they need to

### Images
- Not using the framework's image component
- No `width`, `height` or `sizes`, so layout shifts
- Not served through a CDN with transforms
- Above-the-fold images not prioritised; below-the-fold not lazy

### Animation
- On `width`, `height`, `top`, `left`, `margin`, `padding`
- `backdrop-blur` on moving elements
- Scroll hijacking
- Heavy animation without `will-change`; or `will-change` without measurement
- Too many animations competing at once

### Bundle
- Whole libraries imported for one function
- Components that should load on demand
- Fonts not subset
- Unused CSS or JS reaching the client

### Loading
- No Suspense boundaries around async components
- No streaming where it would help
- Sequential fetches that could run in parallel
- No caching or revalidation strategy

### Stability
- Layout shift from images without dimensions
- Fonts shifting layout on load
- Content pushing the page around after it appears

## Report

Grade by impact: High (visible jank or delay), Medium (measurable, subtle), Low (good practice). For each: what is slow, why, where (file:line), the fix. Then wait.
