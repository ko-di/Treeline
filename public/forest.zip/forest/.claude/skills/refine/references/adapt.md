# Adapt — every screen size

The grid, spacing and hierarchy in [`DESIGN.md`](../../../forest/taste/DESIGN.md) have to hold at every size, not only the one it was designed at.

## Look for

### Breakpoints
- Fixed widths that don't respond
- Layouts that reflow chaotically instead of keeping their rhythm
- Content overflowing its container on small screens
- Horizontal scroll on a phone, which is almost always a bug

### Type
- Desktop sizes unchanged on a phone
- Measure too wide on large screens, too narrow on small
- Headings overwhelming small viewports
- No responsive type scale

### Touch
- Targets under 44×44px
- Hover-only interactions with no touch equivalent
- Targets too close together
- No active state for touch feedback

### Layout
- Grids that don't reduce sensibly
- Images that don't scale or crop well
- Desktop navigation on mobile
- Spacing too generous on a phone or too tight on a desktop

### Priority
- Does the mobile layout put the right thing first?
- Is secondary content sensibly deferred?
- Are calls to action still reachable?

### Devices
- Safe areas on notched phones
- Landscape
- Tablets, not only phone and desktop
- Print, where it matters

## Report

Group by range: Mobile, Tablet, Desktop, Cross-cutting. For each: what breaks, where (file:line), the responsive fix. Then wait.
