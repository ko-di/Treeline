#!/usr/bin/env bash
# forest resupply — bring the newest version of forest into this project.
#
#   bash .claude/forest/resupply.sh --check       one quiet line if a newer version is out
#   bash .claude/forest/resupply.sh --whats-new   what changed between this version and the newest
#   bash .claude/forest/resupply.sh --apply       replace .claude/ with the newest version
#   bash .claude/forest/resupply.sh --undo        put the previous version back
#
# forest lives in .claude/. An update replaces that folder and nothing else:
# project/ and app/ are never read, moved or rewritten. The old .claude/ is
# kept in .forest/ so the update can be undone.
#
# The whole script sits inside main(), which runs on the last line. Bash reads
# a script as it goes, and --apply replaces this very file. Wrapping it means
# bash has read all of it before anything is replaced.

main() {
set -euo pipefail

# Where the newest version lives. FOREST_SITE overrides it for testing.
SITE="${FOREST_SITE:-https://treeline-sand.vercel.app}"

# The project is the folder holding .claude/. The hook says where; run by hand
# from the project folder, it's here.
if [[ -n "${CLAUDE_PROJECT_DIR:-}" && -d "${CLAUDE_PROJECT_DIR}/.claude" ]]; then
  ROOT="$CLAUDE_PROJECT_DIR"
elif [[ -d "$(pwd)/.claude/forest" ]]; then
  ROOT="$(pwd)"
else
  ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
fi
cd "$ROOT"

MODE="${1:-}"
case "$MODE" in
  --check)     check_mode ;;
  --whats-new) whats_new_mode ;;
  --apply)     apply_mode ;;
  --undo)      undo_mode ;;
  *) printf "  usage: bash .claude/forest/resupply.sh --check | --whats-new | --apply | --undo\n" >&2; exit 1 ;;
esac
}

say()  { printf "  %s\n" "$1"; }
ok()   { printf "  ✓ %s\n" "$1"; }
warn() { printf "  ! %s\n" "$1" >&2; }

# ── Versions ────────────────────────────────────────────────────────
is_version() { [[ "$1" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]]; }

# 1.12.3 → 1012003, so versions compare as plain numbers.
ver_num() {
  local a b c
  IFS=. read -r a b c <<< "$1"
  echo $(( 10#$a * 1000000 + 10#$b * 1000 + 10#$c ))
}

current_version() {
  local v
  v="$(tr -d '[:space:]' < .claude/forest/VERSION 2>/dev/null || true)"
  is_version "$v" && echo "$v" || echo ""
}

latest_version() {
  local timeout="$1" v
  v="$(curl -fsSL --max-time "$timeout" "$SITE/forest-version.txt" 2>/dev/null | tr -d '[:space:]' || true)"
  is_version "$v" && echo "$v" || echo ""
}

# ── --check ─────────────────────────────────────────────────────────
# Run at the start of every session. Whatever it prints, Claude reads. It
# looks at the site at most once a day, prints nothing unless there is
# something worth one line, and never fails: a broken check must not get in
# the way of a working session.
check_mode() {
  set +e
  local current latest="" checked=0 now cache=".forest/resupply-check"
  current="$(current_version)"
  [[ -n "$current" ]] || exit 0

  now="$(date +%s)"
  if [[ -f "$cache" ]]; then
    checked="$(sed -n 's/^checked=//p' "$cache")"
    latest="$(sed -n 's/^latest=//p' "$cache")"
    [[ "$checked" =~ ^[0-9]+$ ]] || checked=0
  fi

  # Offline counts as checked, so a laptop on a train doesn't wait three
  # seconds at the start of every session.
  if (( now - checked > 86400 )); then
    latest="$(latest_version 3)"
    mkdir -p .forest 2>/dev/null
    printf "checked=%s\nlatest=%s\n" "$now" "$latest" > "$cache" 2>/dev/null
  fi

  if is_version "$latest" && [[ $(ver_num "$latest") -gt $(ver_num "$current") ]]; then
    echo "forest $latest is out; this project has $current. After the greeting, say so in one line and name /resupply, which brings it in and is best done between camps. Once per session, never in the middle of a skill, and never as a reason to stop what the user asked for."
  fi
  exit 0
}

# ── --whats-new ─────────────────────────────────────────────────────
whats_new_mode() {
  local current latest notes line on=0 re='^## ([0-9]+\.[0-9]+\.[0-9]+)'
  current="$(current_version)"
  [[ -n "$current" ]] || { warn "This folder has no forest version in it."; exit 1; }
  latest="$(latest_version 10)"
  [[ -n "$latest" ]] || { warn "Could not reach the site to check for a newer version. Check you're online and try again."; exit 1; }

  if [[ $(ver_num "$latest") -le $(ver_num "$current") ]]; then
    echo "up to date: $current"
    exit 0
  fi
  echo "current: $current"
  echo "latest: $latest"
  echo ""
  notes="$(curl -fsSL --max-time 10 "$SITE/forest-whats-new.md" 2>/dev/null || true)"
  if [[ -z "$notes" ]]; then
    say "(no notes available for this version)"
    exit 0
  fi
  while IFS= read -r line || [[ -n "$line" ]]; do
    if [[ "$line" =~ $re ]]; then
      on=0
      [[ $(ver_num "${BASH_REMATCH[1]}") -gt $(ver_num "$current") ]] && on=1
    fi
    [[ $on -eq 1 ]] && printf "%s\n" "$line"
  done <<< "$notes"
  exit 0
}

# ── --apply ─────────────────────────────────────────────────────────
TMP=""
on_exit() { [[ -n "$TMP" ]] && rm -rf "$TMP"; }

apply_mode() {
  for tool in curl tar; do
    command -v "$tool" >/dev/null 2>&1 || { warn "$tool is not installed, and the update needs it."; exit 1; }
  done
  local current latest stamp backup
  current="$(current_version)"
  [[ -n "$current" ]] || { warn "This folder has no forest version in it, so there is nothing to update from."; exit 1; }
  latest="$(latest_version 10)"
  [[ -n "$latest" ]] || { warn "Could not reach the site. Nothing was changed."; exit 1; }
  if [[ $(ver_num "$latest") -le $(ver_num "$current") ]]; then
    ok "Already on the newest version, $current. Nothing to do."
    exit 0
  fi

  TMP="$(mktemp -d "${TMPDIR:-/tmp}/forest-resupply.XXXXXX")"
  trap on_exit EXIT

  # Download and unpack into the temporary folder, and make sure it is what
  # it claims to be, before anything in the project is touched.
  if ! curl -fsSL --max-time 120 -o "$TMP/forest.zip" "$SITE/forest.zip"; then
    warn "The download failed. Nothing was changed."
    exit 1
  fi
  if ! tar -xf "$TMP/forest.zip" -C "$TMP" 2>/dev/null; then
    warn "The download could not be unpacked. Nothing was changed."
    exit 1
  fi
  local got
  got="$(tr -d '[:space:]' < "$TMP/forest/.claude/forest/VERSION" 2>/dev/null || true)"
  if [[ "$got" != "$latest" || ! -d "$TMP/forest/.claude/skills" ]]; then
    warn "The download didn't look like forest $latest. Nothing was changed."
    exit 1
  fi

  # The swap. The old folder is moved aside first, which is instant, and only
  # then is the new one moved in. If that second move fails, the old one goes
  # straight back.
  stamp="$(date +%Y%m%d-%H%M%S)"
  backup=".forest/backup-$current-$stamp"
  mkdir -p .forest
  mv .claude "$backup"
  if ! mv "$TMP/forest/.claude" .claude; then
    mv "$backup" .claude
    warn "Could not put the new version in place. The old one is back. Nothing was lost."
    exit 1
  fi
  echo "$backup" > .forest/resupply-last
  rm -f .forest/resupply-check   # so the next session doesn't announce the update just taken

  ok "forest $current → $latest"
  say "  Your project is untouched: project/ and app/ are exactly as they were."
  say "  The old version is kept in $backup, so this can be undone."
  echo ""
  say "Restart Claude Code so it reads the new version."
  echo ""
}

# ── --undo ──────────────────────────────────────────────────────────
undo_mode() {
  local backup now
  backup="$(cat .forest/resupply-last 2>/dev/null || true)"
  if [[ -z "$backup" || ! -d "$backup" ]]; then
    warn "There is no update to undo in this project."
    exit 1
  fi
  now="$(current_version)"
  mkdir -p .forest
  mv .claude ".forest/undone-$now-$(date +%Y%m%d-%H%M%S)"
  mv "$backup" .claude
  rm -f .forest/resupply-last .forest/resupply-check
  ok "Back on $(current_version). Your project is untouched."
  say "  Restart Claude Code so it reads this version again."
}

main "$@"
