# Naming — forest

Single source of truth for the vocabulary. If a name is unclear, this file is wrong, not the code.

## The metaphor

An outdoor adventure. You **pack** for a trip, hit the **trail**, set up **camp** at each stage, and **summit** when you ship. The metaphor is a teaching aid — it explains the model in 30 seconds. When forcing it costs clarity, plain language wins.

## The model in one sentence

You're on a **trail** from idea to shipped product. The trail has six **camps** — Intake, Discover, Define, Design, Build, Ship. Your **compass** tells you what's next. Your **map** is the project's state of the world.

## Commands (slash commands)

Twenty-five commands exist. **You have to remember two.**

Twenty-five is the count, not the reading list. Most of them are run for you at the point they apply, in the same way `/weather` is (see *Gates*). Counting the ones you type as though they were all homework is the fastest way to make a workflow look heavier than it is.

### The ones you type

| Command | What it does |
|---|---|
| `/pack` | Start a new project — scaffold the kit, set the role, draft the map. If you don't have an idea yet, runs a short hunt (see *Idea hunt* below). **The only way in.** |
| `/trail` | Start or continue the guided journey. Walks the camps in order and runs the right command at each. **The only one you need after `/pack`.** |
| `/compass` | "What should I do next?" — recommends the next action based on current state. Optional; `/trail` already knows. |
| `/map` | Show the project's state at a glance — which camps are filled, which are empty. |
| `/camp` | Jump to a specific camp (e.g. `/camp discover`) and work there directly. The escape hatch from trail order. |
| `/rationale` | Capture the WHY behind a single decision. Writes to `project/decisions/`. Never fires on its own — you invoke it the moment a call is worth remembering. |

### The ones the trail runs for you

You can type these. You do not need to know they exist.

| Command | Runs when |
|---|---|
| `/scout` | `/trail` or `/camp` reaches Camp 2 — interviews, audience, problem validation |
| `/gather` | `/scout` offers it once three notes are filed — synthesises them into themes |
| `/sketch` | `/trail` or `/camp` reaches Camp 4 — brand and visual direction. **Non-gated**: drop a screenshot or Figma URL at any point and it will turn it into tokens + rationale |
| `/weather` | Camp 2 closes. A gate, not a command — see *Gates* |
| `/review` | `/camp build` finishes a phase — the five-check quality pass on that phase's files, graded, findings first |
| `/test` | `/camp build` finishes a phase — writes and runs the tests for that phase's flow |
| `/benchmark` | `/scout` offers it once in Camp 2 — who else solves this, doing nothing included |
| `/ship` | `/trail` or `/camp` reaches Camp 6 — quality checks, tests, commit, push |
| `/a11y-audit` | `/summit` runs it — the accessibility audit, with a report. Critical findings block the summit |

### The ones offered at the summit

Camp 6 is called Ship, and `/ship` is the first of four commands inside it, not the end of the trail. When the deploy is live, the kit names these and you pick the moment. None of them chains automatically — each is its own act, and the pause is deliberate.

| Command | What it does |
|---|---|
| `/summit` | Post-deploy verification — analytics, SEO, performance, accessibility. Writes `project/SUMMIT.md` |
| `/retro` | Retrospective — what worked, what didn't, what to keep |
| `/handoff` | Package deliverables for client or agency handoff. Client mode only |
| `/reach` | How it reaches people — position, wedge, who first, what it replaces, money, the first thirty days. Offered by `/ship` |

### The ones you reach for when you need them

None of these is on the trail. Each does one job on what's been built, presents its findings, and changes nothing until you say yes.

| Command | What it does |
|---|---|
| `/refine` | Strengthen one aspect: `harden`, `optimise`, `adapt`, `clarify` or `onboard` |
| `/tune` | Push the design one way: `bolder`, `quieter`, `colourise` or `normalise` |
| `/motion` | Add motion that has a job, from the motion system's recipes, with a reduced-motion fallback |
| `/animate` | Review the motion that's there, and the motion that's missing |
| `/overdrive` | One technically ambitious moment, proposed first, built on a yes |
| `/system` | Document the design system as built, and where it drifted from the design |
| `/resupply` | Bring in the newest version of forest. Shows what changed, waits for a yes, swaps forest's own folder and nothing else. Claude names it when a newer version is out |

### What happens after the summit

Nothing the kit runs. `project/SUMMIT.md` closes with three questions dated ninety days out, and answering them is a manual act on purpose — the value is in reading your own claims cold, months later, with no process around it to soften them. There is no fourteenth command for it and there should not be: a command you type once a quarter is a command you will not remember, and the kit would be pretending to own a moment it cannot be present for.

`/summit` will offer to set a reminder if your environment has a scheduling skill, and will tell you to put one in your own calendar if it doesn't.

### Why the tiers, rather than fewer commands

The obvious response to twenty-five commands is to merge some. It is the wrong move here, twice over.

Merging the post-ship three would contradict a decision made four times in the skills themselves: `/ship` does not auto-run `/summit`, `/summit` does not chain into `/retro` or `/handoff`, `/retro` does not auto-run `/handoff`. Each refusal exists because the pause is where the thinking happens. Collapsing them into one command would buy a shorter list and lose the reason the list is any good.

Merging `/gather` into `/scout` would hide the three-note threshold, which is one of the few places the kit visibly refuses. A separate command makes the gate legible; a merged one makes it a footnote.

So the count stays and the presentation changes. Twenty-five commands, two to remember.

### Why `/rationale` and `/retro` are not metaphor-flavored

`/blaze` (mark a trail) and `/breakdown` (break camp) were considered. Both lose to clarity. Universal terms beat cute metaphor when the metaphor strains.

### Why no `/forge`, `/build`

Build phase is walked by `/trail` and worked in `/camp build`. It doesn't need its own command. Adding more commands creates more to remember without buying clarity.

## Idea hunt — when there's no destination yet

`/pack` opens with one question: *Do you know what you're building?* If no, it runs a short hunt before scaffolding the rest. Output: `project/1-intake/idea.md`. The hunt has five beats:

1. **Source.** Where the idea comes from — pick one:
   - **Business** — something you already do.
   - **Craft** — something you know deeply.
   - **Itch** — something that bugs you and won't let go.
2. **Terrain.** Five short questions matched to the source. Each pulls one specific input — a workflow, a frustration, a thing you'd pay to delete, an unfair-access asset, a thing only you do this way.
3. **Candidates.** Three product directions synthesised from the answers. Not generic — drawn from what was actually said. Named, one-lined, and aimed at a specific user.
4. **Score.** Each candidate rated on five axes, low/mid/high:
   - **Edge** — do you have an unfair advantage here?
   - **Heat** — does this actually hurt the user enough to switch?
   - **Reach** — can you find these people without spending money you don't have?
   - **Cut** — small enough to ship a first version solo?
   - **Voice** — does this come out sounding like only you could have made it?
5. **Sharpen.** Pick one. Write five lines on the back of a napkin: *target, sting, smallest cut, why-you, biggest assumption*.

The hunt is optional — if `/pack` asks "do you have an idea?" and you do, it skips straight to scaffolding.

## Artifacts

The files the workflow produces.

| File | What it is |
|---|---|
| `project/compass.json` | The project's vision and direction. Schema versioned in `meta.schemaVersion`. Single source of truth. |
| `project/EVIDENCE.md` | What you know and how you know it, written for someone who wasn't there. Rewritten by `/weather` on every reading. The one artifact the kit produces that nothing else does. |
| `project/BRIEF.md` | The compiled brief. Everything upstream in one file a build tool can read alone. Written by `/camp build`, rewritten whenever the PRD or design changes. See [`BUILDING.md`](../../BUILDING.md). |
| `project/map.md` | The state of the world. Six camps as headers, decisions and progress under each. Updated as you go. |
| `project/1-intake/idea.md` | Optional. The output of `/pack`'s idea hunt — source, terrain, candidates, score, sharpen. Only present if the user started without an idea. |
| `project/<n>-<name>/` | The six camp folders. Raw notes, drafts, working files for each stage live here. |
| `project/design/` | The design system: `design.md`, and the mark if the user brings one. |
| `app/` | The product itself, built in Camp 5. The only folder that isn't documents. |
| `project/decisions/<date>-<topic>.md` | One file per significant decision, captured by `/rationale`. |
| `project/research/*.md` | Raw research notes (interview transcripts, observations) before synthesis. `/gather` reads from here. |
| `project/memory/session.md` | One line per working session — date, camp, what happened, what the user said they'd do next. Appended by `/pack`, `/trail` and `/camp`; read by `/compass` and `/map`. Not a transcript: it holds the thread the files can't. |
| `.forest/role.md` | Who is using the kit (designer, founder, dev) and their help style. Set on `/pack`. Gitignored — per-machine, so project identity like `mode` lives in `project/compass.json` instead. |
| `project/retro.md` | What worked, what didn't. Runs on parked and turned-back projects too, not only shipped ones. |

## Stage

Where the venture is, held at `project/compass.json.business.stage`. Asked once by `/pack`.

| Stage | Means |
|---|---|
| `idea` | Nothing built. Evidence comes from conversations |
| `building` | Being made, not yet in anyone's hands |
| `launched` | People are using it. Behaviour is now readable, and behaviour is `observed` |
| `raising` | Talking to investors |
| `revenue` | People are paying |

Stage changes **what the gate weighs**, never what the kit recommends. A launched product has `observed` evidence sitting in its analytics and usually hasn't re-read the claim it rests on. `raising` is not a mode the kit sells into: it triggers no advice about decks, valuations or introductions, and only makes `/weather` blunter about thin evidence, on the grounds that the week you are asking people for money is the week you most want to know.

## Status and cycles

A project is in one of four states, held in `project/map.md` and mirrored at `project/compass.json.meta.status`:

| Status | Means |
|---|---|
| `active` | Being worked |
| `parked` | Deliberately stopped, reason in `project/retro.md` |
| `shipped` | `/summit` has run |
| `turned-back` | The gate said so and the user took it |

**Parked and turned-back are outcomes, not failures.** Most projects stop, and the kit would be lying if it modelled only the ones that don't. A park with a written reason is a project you can restart; a folder that went quiet is one you can't remember.

A **cycle** is one pass round the trail. A v2, a pivot after a park, or a rebuild is cycle 2 of the same project — not a new one. `/pack` opens it on request only, archives the previous map and retro, carries the research, decisions and design across, and reads the last retro's first lesson back to you. The full rules are in [`references/STATE.md`](./references/STATE.md).

## Stage names

The six camps. Industry-recognisable design-process taxonomy (close to Double Diamond + Build/Ship). Don't rename these — they earn their familiarity.

1. **Intake** — capture the idea, the constraint, the why.
2. **Discover** — research the audience, the problem, the alternatives.
3. **Define** — narrow to a specific product, write the PRD.
4. **Design** — brand, visual direction, key flows.
5. **Build** — implement.
6. **Ship** — release, verify, hand off.

## Personas

Each command wears a different hat. The voice shifts because the work shifts. The kit aims to feel like a small studio of sharp workmates rather than one assistant. The personas are constraints on voice and posture, enforced inside each skill prompt — not separate models.

| Command | Persona |
|---|---|
| `/pack` | The sharp creative partner who sets the trail |
| `/trail` | The guide who knows the route |
| `/compass` | The route-reader who points at one move |
| `/map` | The clean reporter who shows what is |
| `/camp` | The guide who respects out-of-order judgement |
| `/scout` | The researcher with taste — warm, allergic to leading questions |
| `/sketch` | The senior design director — observant, decisive, systematic |
| `/gather` | The synthesis researcher — biased against confirmation |
| `/rationale` | The careful witness who records, doesn't gloss |
| `/ship` | The careful engineer who ships clean, not fast |
| `/summit` | The exacting verifier who hands you the artifact |
| `/retro` | The careful witness, again — but with more distance |
| `/handoff` | The careful packager who assumes the receiver never speaks to you again |
| `/weather` | The guide who has turned people around before — reads what is there, no stake in the summit |
| `/review` | The studio's second pair of eyes — precise, in order, no praise |
| `/test` | The engineer whose tests stay green for the right reasons |
| `/refine` | The engineer brought in for one job |
| `/tune` | The design director stepping in for one note |
| `/motion` | The motion designer who thinks most interfaces move too much |
| `/animate` | The same designer, reading someone else's work |
| `/overdrive` | The creative technologist who knows one extraordinary moment beats ten decorative ones |
| `/system` | The systems designer who makes the implicit explicit |
| `/a11y-audit` | The practitioner who has watched real people use screen readers |
| `/benchmark` | The analyst with no stake in the answer |
| `/reach` | The strategist who remembers the two launch plans that worked |
| `/resupply` | The quartermaster who says what's swapped and what stays in the pack |

The personas are documented here once. They live inside each skill's prompt as the opening "Voice" line. Users don't need to memorise the table — they'll feel the shift across camps and can return to this list when curious.

## Gates

A **gate** is not a command. Commands are what you type to do work; the count of twenty-five never has to be remembered, and two do and still holds. A gate is something the trail does to you at a fixed point, in the same category as a challenge — you don't have to remember it for it to fire.

There is exactly one.

| Gate | Fires | Can return |
|---|---|---|
| `/weather` | When Camp 2 closes, from `/trail` | Press on · Reroute · Turn back |

Every challenge in the kit advances. Engage, push back, or defer — the trail moves on. That is right for challenges; they exist to make you think, not to stop you. But a workflow where nothing can ever return "no" has opinions, not conditions. `/weather` is the one point that can say the evidence does not support building this, and it fires where the evidence exists: after `/gather`, not before `/scout`.

It can also be typed, for the moment when you want the reading early. It sits with the ones the trail runs for you, because you should not have to remember it.

### Why `weather`, not `validate`

You read the weather before you climb, and you turn back because of it. The word already carries the idea that conditions are external, that they are not a judgement of you, and that turning back is a normal outcome rather than a failure. `/validate` implies the answer is yes and the exercise is confirmation, which is the failure mode this gate exists to catch.

---

## Anti-patterns

- Don't add new commands without retiring an old one, or without a job no existing command does. Two to remember is the promise; the count is what it takes to keep it.
- Don't rename camps to be cuter (`Basecamp`, `Trailhead`, etc) — they're recognisable as-is.
- Don't force the metaphor into every command. `/rationale` is clearer than `/blaze`.
- Don't introduce two words for the same thing (`dossier` and `camps` — pick one; we picked `camps`).
- Don't oversell the personas. The kit runs on one model wearing different hats — surfacing them as "AI agents" or "team members" breaks trust on what is actually one tool.
