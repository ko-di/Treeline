# Map

The state of this project. One file. Updated as you walk the trail.

**Project:** <!-- name -->
**Started:** <!-- YYYY-MM-DD -->
**Last updated:** <!-- YYYY-MM-DD -->
**Current camp:** <!-- intake · discover · define · design · build · ship -->
**Status:** active <!-- active · parked · shipped · turned-back -->
**Cycle:** 1 <!-- a v2 is cycle 2 of the same project, not a new one -->

## Trail

```mermaid
flowchart LR
    Start([ idea ]) --> C1[Camp 1<br/>Intake]
    C1 --> C2[Camp 2<br/>Discover]
    C2 --> C3[Camp 3<br/>Define]
    C3 --> C4[Camp 4<br/>Design]
    C4 --> C5[Camp 5<br/>Build]
    C5 --> C6[Camp 6<br/>Ship]
    C6 --> End([ summit ])

    classDef done fill:#111,stroke:#111,color:#fff
    classDef wip  fill:#fff,stroke:#111,stroke-width:3px,color:#111
    classDef todo fill:#fff,stroke:#999,stroke-dasharray:4 3,color:#999
    classDef edge fill:#fff,stroke:#111,color:#111

    class C1,C2,C3,C4,C5,C6 todo
    class Start,End edge
```

**Legend.** Filled = complete. Bold outline = in progress. Dashed = not started.
Edit the `class` lines above as camps progress: `done`, `wip`, `todo`.

---

## Camp 1 — Intake

Capture the idea, the constraint, the why-now.

- [ ] Idea in one sentence
- [ ] Constraints (time, money, skill, scope)
- [ ] Why-now articulated

## Camp 2 — Discover

Research the audience and the problem. No solution-shaped answers yet.

- [ ] Primary audience defined (specific, not "small businesses")
- [ ] At least 3 raw notes in `project/research/`
- [ ] Insights synthesised via `/gather`

## Camp 3 — Define

Narrow to a specific product. Cut what's not in v1.

- [ ] PRD in `project/3-define/prd.md`
- [ ] Scope: in / out / later — explicit
- [ ] One success metric (not five)

## Camp 4 — Design

Brand, voice, visual direction, key flows.

- [ ] Voice and tone recorded in `project/compass.json` under `feeling`
- [ ] Colour, typography, imagery direction
- [ ] Key flow sketches or wireframes

## Camp 5 — Build

Stack chosen. Repo set up. Core flows working end-to-end.

- [ ] `project/BRIEF.md` compiled — the one file you hand to a build tool
- [ ] Stack recorded in `project/compass.json` under `techStack`
- [ ] Core flows working end-to-end
- [ ] Built result checked against `project/design/design.md`

### Phases

Filled by `/camp build` when it compiles `project/BRIEF.md`. Each phase is a vertical
slice you could ship on its own, naming the requirement it serves. Order is the
build order.

Phases are checkboxes in the same form as the camps above, so they tick as they
ship. None are listed until `project/BRIEF.md` exists. A filled one reads like:

> **Phase 1 — A visitor can see the classes.** PRD §2. Read-only, no auth.
> **Phase 2 — An instructor can add one.** PRD §3. Auth, one form.

Keep the phase list below this line so the camp's own checkboxes stay countable.

## Camp 6 — Ship

Deployed. Verified. Handed off if client.

- [ ] Deployed
- [ ] `/summit` checks passed (analytics, SEO, performance, a11y)
- [ ] `/retro` written
- [ ] `/handoff` package built (client only)

---

## Decisions

```mermaid
timeline
    title Decisions log
    YYYY-MM-DD : First decision goes here
```

Significant decisions get a file in `project/decisions/`. Index them here with a short why.

<!-- e.g. - **2026-04-30 — chose Next.js over SvelteKit.** *Reason: built-in routing + the team already knows it.* See `project/decisions/2026-04-30-stack.md`. -->
