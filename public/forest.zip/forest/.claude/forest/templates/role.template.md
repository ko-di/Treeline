# Role

Filled by `/pack` on first run.

**Role:** <!-- solo founder · designer · dev · PM · agency lead -->
**Mode:** <!-- product (own idea) · client (working for someone) -->
**Stack experience:** <!-- one line. e.g. "comfortable with React, new to backend" -->
**Help style:** <!-- structured · balanced · terse -->
**Set:** <!-- YYYY-MM-DD -->

## What I'm building

One sentence. Specific enough that a stranger gets it.

> <!-- e.g. "A scheduling tool for fitness instructors who hate calendar apps." -->

## Who's at the campfire

Voices that will appear in the project's documents. List by role, not name.

- <!-- e.g. me (designer) -->
- <!-- e.g. founder -->
- <!-- e.g. one early user -->
