# Role

Filled by `/pack` on first run.

**Role:** <!-- solo founder · designer · dev · PM · agency lead -->
**Mode:** <!-- product (own idea) · client (working for someone) -->
**Stack experience:** <!-- one line. for example, "comfortable with React, new to backend" -->
**Help style:** <!-- structured · balanced · terse -->
**Team:** <!-- solo · small (2 to 5) · larger (more than 5, or people outside the group who have a say) -->
**Set:** <!-- YYYY-MM-DD -->

## What you are building

One sentence. Specific enough that a stranger gets it.

> <!-- for example, "A scheduling tool for fitness instructors who hate calendar apps." -->

## Who's at the campfire

Voices that will appear in the project's documents. List by role, not name.

- <!-- for example, me (designer) -->
- <!-- for example, founder -->
- <!-- for example, one early user -->
