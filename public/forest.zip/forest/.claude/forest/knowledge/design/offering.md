<!-- Proprietary. k-d studio. Not for redistribution. -->

# Offering design work at Camp 4

How `/camp shape` decides what to put in front of the user before handing to `/sketch`. Read this first, then `methods.md` for the one that was chosen.

## The 2 settings, read before anything is named

| Setting | Where | Decides |
|---|---|---|
| `Team:` | `.forest/role.md` | Which methods exist for this user |
| `research.time` | `project/compass.json` | How big the version offered is |

A method that does not fit the team is never named. A method that fits is offered at the size the time allows. Both rules come from `references/OFFERING.md`, and both exist so the user never sees a list they cannot use.

## The order

0. **Check `Team:` is set.** A blank or missing field means the project was packed before it existed. Ask before offering anything, in one line: who is working on this with you? On your own, 2 to 5, or more than that, counting anyone outside the group who has a say. Write the answer to `.forest/role.md`. Do not offer while it is unknown. Do not assume `solo`: a client team that never sees a walkthrough is the failure this setting prevents.
1. **Check for a design objective.** If `compass.json.business.initialGoal` is filled and no objective exists in `project/4-shape/`, offer that first. It is the smallest piece of work in this camp and everything after it is checked against it.
2. **Check what exists.** Wireframes, a prototype, a build, or nothing yet. This decides which methods are even possible. A walkthrough needs something to walk through.
3. **Read the team.** Offer only the rows in `methods.md` whose Fits value is at or below the team. The column is the single source of which method fits whom; do not keep a second list here.
4. **Offer up to 3**, each with its 3 lines from `methods.md`, put in this product's words. Per `QUESTIONING.md` guided mode: if only one fits, it is a recommendation in a sentence, not a list of one.
5. **Hand to `/sketch`** for tokens, either after the method runs or straight away if the user declines. Declining is a fine answer and draws no comment.

## The 3 lines, for this product

`methods.md` holds the generic lines. The user hears them rewritten. For a booking sheet built for Sam:

Generic:

> When to use it: once Camp 3 has a success metric and before any visual work.

Heard:

> When to use it: now. Your metric is "half of first visits end with a booking", and nothing has been drawn yet.

The rewrite is the whole job. A generic line read out is a template, and templates are what the writing guide exists to stop.

## What this camp does not offer

- Research methods. Those belong to Camp 2 and `knowledge/research/`. If a design question turns out to be a research question, say so and name `/scout`.
- Measuring the live product. That is `/summit`, at Camp 6.
- Anything that needs people the user does not have.

## Anti-patterns

- Reading the generic 3 lines out.
- Offering before reading the team setting.
- Offering a walkthrough with nothing to walk through.
- Treating a declined offer as something to argue with.
- Skipping the design objective because it is small. It is small and it is first.
