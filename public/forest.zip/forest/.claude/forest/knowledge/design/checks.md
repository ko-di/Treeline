<!-- Proprietary. k-d studio. Not for redistribution. -->

# Design checks

There are 3 layers of question to put to a design before it is called finished. Read by `/review` and by `/camp shape`. The 5 visual checks in `/review` cover the third layer well. The first 2 are what they miss.

When to use it: before a phase is called done. Also whenever a design has been argued about for 10 minutes and nobody has said what is wrong.

The benefit: the argument ends. Each question has a yes or no answer, and a no points at the exact thing to change.

You've got it right when: every yes points at something on the screen or in a file. A yes that points at nothing is a no.

## The rule that makes this a review

Every question below is yes or no. On its own a yes is worth nothing, because anyone can say yes. So each yes carries a second part. What shows it?

"Does it solve the problem in the brief? Yes." That is an opinion.

"Does it solve the problem in the brief? Yes, the first screen is the booking form and the brief says Sam's problem is booking." That is a finding.

A yes with nothing after it is filed as `assumed`, the same as any other unsourced claim in the kit.

## Layer 1: product thinking

Whether this is the right thing to have built. Ask these first. A design that fails here cannot be saved by the other 2 layers.

**The problem**

- Is the problem this solves written down, and does the design solve that one?
- Does the research in `project/research/` support this direction, or only the person who proposed it?
- Would the beneficiary named in the compass recognise this as their problem?

**The people**

- Is it solving the problem for the person named, rather than for a category?
- Does it cost that person anything they had before?
- Does it cost anyone else something? Other users, people who share the account, people on the other end.

**The value**

- What can they do now that they could not do before? Name it.
- Has anything been made worse to make this better?

**The principles**

- Does it guide without crowding?
- Has somebody tried to break it, or only to use it?
- Is there anything here that is there because it was quick?

## Layer 2: the experience

Whether a person can get through it. These come from watching people, and each one is a thing you can observe.

**Where the person is**

- Can the person tell where they are without reading anything?
- Can they tell what happened before this screen and what comes after?

**What the person does**

- Can they find what they are meant to do here in under 5 seconds?
- Do they know how to do it, or only that it needs doing?

**How hard is it**

- Does the task take the fewest steps it could?
- Do the steps come in the order a person would expect?
- Is there any friction that is not protecting them from something?

**Does it behave as expected**

- Does it work the way the person already thinks things like this work?
- Does it use patterns they have met elsewhere, or invent its own?
- Does it fit with the rest of the product, or feel bolted on?

**When it goes wrong**

- When something fails, is there a clear next step on the screen?
- Does the error say what happened and what to do, in plain words?
- What happens with nothing entered, everything entered, the wrong thing entered, and the connection gone?
- Can they get help without leaving the task?

Where a yes rests on a guess about how people behave, it is a candidate for `knowledge/research/methods/observation.md`. A 20-minute watch answers most of this layer.

## Layer 3: the surface

Whether it is well made. `/review`'s 5 checks cover this in detail: distill, typeset, arrange, audit, polish. These 4 are the questions to ask before those checks run, so the checks have something to check against.

**Standards**

- Does it meet an accessibility standard, and which one?
- Does it use `project/design/design.md`, or values that escaped it?
- Does the copy follow the product's voice in the compass?

**Recognition**

- Are the things a person can do visible, rather than remembered?
- Can they get back to an instruction without leaving the screen?

**Familiarity**

- Does the layout feel like the tools this person already uses every day?
- Does it follow the conventions of the platform it runs on? A phone app that behaves like a website fails this.

**Craft**

- Does it follow the standards tightly, or roughly?
- Is anything here that could be removed without loss?
- Where is the one moment that could be better than it needs to be? There should be one, and only one.

## Running it

Do not read all 3 layers out. Pick the layer the situation needs:

| Situation | Layer |
|---|---|
| The direction is in doubt | 1 |
| Someone got stuck using it | 2 |
| It works but looks rough | 3 |
| Nobody can say what is wrong | 1, then 2 |

Report as `/review` reports: numbered, graded, what and where and the fix. A question that got a no becomes a finding. A question that got a yes with nothing behind it becomes a finding too, graded P2, because it is a claim nobody checked.

## Anti-patterns

- Accepting a yes with nothing after it.
- Running layer 3 on a design that fails layer 1. Polishing the wrong thing.
- Reading all 3 layers out as a questionnaire.
- Asking the user to answer questions the code or the compass already answers.
- Treating "it feels right" as a yes to anything.
