<!-- Proprietary. k-d studio. Not for redistribution. -->

# Design methods

Ways of working on a design direction with other people, or alone. Read by `/camp shape` before it offers anything, and only the method chosen gets used.

## Who is in the room decides what is offered

Most design methods were written for a team: a facilitator, a second note-taker, stakeholders, a product manager. Forest's user is often one person. The Team setting in `.forest/role.md` records who is actually there, and the Fits column below reads it:

| Team | Means |
|---|---|
| `solo` | One person. Methods that need a second person are never named |
| `small` | 2 to 5 people who work on this together |
| `larger` | More than 5, or people outside the working group who have a say: a client, a sponsor, a department |

The column is a floor. A `larger` team can run anything a `solo` person can, and often should first. A `solo` person is never shown a workshop. The sentence "you could run a workshop but you're on your own" is what makes a workflow feel like homework.

When the team changes, the offers change. Someone who packed as `solo` and now says a client wants to see the design has a `larger` team for this camp. Ask once, update `role.md`, offer differently.

## The methods

| Method | Fits | Good for | Smallest honest version |
|---|---|---|---|
| **Design objective** | `solo` | Turning the success metric into something the design can be checked against | One sentence: the goal, a number, a date. See below |
| **The 3 checks** | `solo` | Finding out what is wrong when nobody can say | One layer of `checks.md`, the one the situation needs |
| **Walk it as someone else** | `solo` | Seeing the design from outside your own head | Take the beneficiary from the compass and walk the main task as them, writing down where they stop |
| **Critique** | `small` | A direction review with people who have context | 2 people, 30 minutes, one task walked, notes on where each stopped. `/review`'s `critique.md` shapes it |
| **Who has a say** | `larger` | Knowing who can change the direction before they do, and what each one needs | The map below, on one page |
| **Walkthrough with the room** | `larger` | Catching what the people who will live with this see that you do not | The session below |

## Design objective

When to use it: once Camp 3 has a success metric and before any visual work. A design with no objective gets judged on taste, and taste is where arguments live.

The benefit: one sentence every later decision can be held against. When 2 directions look equally good, the one that serves the sentence wins.

You've got it right when: the sentence has a number and a date in it. Somebody outside the project could tell whether it was met.

The shape:

> [Change] the [part of the design] so that [the measure] [moves by this much] by [date].

Weak: "Make onboarding better."
Right: "Cut the booking form from 6 fields to 3 so that half of first visits end with a booking, by the end of October."

Take the measure from `project/compass.json.business.initialGoal`. If that is empty, Camp 3 is not finished, and the design objective waits.

Write it to `project/4-shape/objective.md`. `/sketch` reads it there, and holds every token against it.

## Who has a say

When to use it: only with a `larger` team. When there are people who can change the direction, or stop it, and they are not in the room every day. A client. A founder who is not designing. A department that will have to use this.

The benefit: nobody appears at the end and undoes a month of work. You know who needs to see what, and when, before you start.

You've got it right when: every person who could change the direction is on one page. Beside each: what they care about, and when they see the design next.

The map, on one page:

| Who | Role | What they care about | Can they change the direction? | When they see it next |
|---|---|---|---|---|

The 4 rules that keep it honest:

- List people, not departments. "Marketing" cannot say yes to anything. A named person can.
- The fourth column is the whole point. Somebody who can change the direction sees the design before it is finished, not after. Somebody who cannot gets told, not asked.
- What they care about is what they have said, not what you assume. If you do not know, that is the first conversation.
- Review it when the team changes. It is a page, not a document.

A solo person does not need this. The compass already holds the one person whose opinion the design serves, and that person is not a stakeholder. They are the point.

## Walkthrough with the room

When to use it: only with a `larger` team, and only once there is something to walk through: wireframes, a prototype, a first build. Not a mood board.

The benefit: the people who will live with the design see it while it can still change. Objections raised now cost an hour. The same objections raised after the build cost the build.

You've got it right when: at least one thing changed because of what somebody in the room saw, and the notes say who saw it.

The session, in an hour:

1. **5 minutes.** Say what the design is for and who it is for. Name the beneficiary from the compass. The room is there to see it as that person, not as themselves.
2. **10 minutes.** Set 2 rules. Everything said gets written down. Nobody in the room defends the design, including whoever made it.
3. **40 minutes.** One person from the room does the main task, out loud, while the others watch. Then a second person. The people who made the design say nothing unless asked a direct question.
4. **5 minutes.** Read the notes back. Say what changes and what does not, and why.

What to write down while it runs: where each person stopped, and what they said the screen was for. What they expected to happen next, and what happened instead. Not opinions about colour.

**If you are running it alone with a client's team:** you are the note-taker and the facilitator at once. Record the session if the room agrees, so the notes can be checked. Keep to one task, not 3. It is better to see one thing properly than 3 things in a rush.

Questions worth asking the room, from `knowledge/research/questions.md`, put in the product's terms:

> What is this screen for?
> What would you do next?
> What did you expect to happen there?
> Where would you look for [the thing they need]?
> What is missing?

Never ask the room whether they like it. They will say yes, and it tells you nothing.

## Ordering the work by impact and effort

When to use it: when there is more to do than time to do it. The argument about what comes first has gone round twice.

The benefit: the order gets decided by 2 questions instead of by whoever spoke last.

You've got it right when: every item has a place in one of the 4 boxes, and the top-left box is what gets built first.

Ask 2 questions per item. How much does it move the design objective? How long does it take?

| | Small effort | Large effort |
|---|---|---|
| **Big impact** | Do first | Do second, or split it |
| **Small impact** | Do when there is a gap | Do not do |

The bottom-right box is the useful one. Most of what fills it was somebody's favourite idea. Naming the box out loud is how a favourite idea gets let go of without an argument.

`/camp build` asks a harder version of the first question, what breaks if this is not built, when it writes the phases. This table is for ordering within a phase, or for a design that has grown a list.

## Anti-patterns

- Naming a method the Team setting rules out, even to explain why not.
- Offering a walkthrough before there is anything to walk through.
- Asking a room whether they like it.
- A design objective with no number or no date.
- Mapping departments instead of people.
- Running a session where the person who made the design talks.
