<!-- Proprietary. K-d studio. Not for redistribution. -->

# Planning a piece of research

Read after a method has been chosen in `choosing.md`. This file covers what gets written down before anyone goes out, and how much of it to write.

## How much plan

The plan scales with `compass.json.research.time`. A plan longer than the research it describes is a warning sign, not thoroughness.

| Time | The plan is |
|---|---|
| `minutes` | 2 lines in the camp folder. What you want to know, and where you are going to look |
| `afternoon` | 4 lines: the question, the method, who you are asking, and what would change your mind |
| `days` | The 4 lines, plus one row per method in the table below |
| `weeks` | The above, plus how participants are recruited and what they are told |

Never hand someone a research plan template. Ask the questions, write the answers into `project/2-learn/plan.md`, and show them the result.

## The 4 lines

Every piece of research, at any size, answers these:

1. **What do you want to know?** One sentence, ending in a question mark.
2. **How will you find out?** The method, named.
3. **Who from?** Not a category, a person, or a way of finding one.
4. **What would change your mind?** See below. This is the one people skip.

## The hypothesis, and the test that makes it honest

Writing down what you expect before you look is good discipline. It stops you rewriting your own memory afterwards, which everyone does.

But a hypothesis that survives every possible result is not a hypothesis. It is a hope, and research built on one is a machine for confirming what you already believed.

**So 2 questions, and both have to be answerable:**

> What do you expect to find?
>
> What would you have to see to decide you were wrong?

If the second has no answer, the belief is not yet testable. That is worth knowing, and it is not a failure. Say so plainly and help turn it into something that could be checked:

| Not yet testable | Testable |
|---|---|
| People find the current process frustrating | At least half the people you watch will abandon the task or build a workaround for it |
| There is demand for this | 3 of 5 people will say they have already paid for something to solve it |
| The onboarding is confusing | People will not reach the second screen without asking me a question |

**Then the third question, which is the one that catches a bad plan early:**

> Could the method you picked actually show you that?

Asking 5 people whether they like an idea cannot show you that nobody will pay for it. If the method cannot produce the disconfirming evidence, either the method is wrong or the question is.

This is not a gate. Nothing is blocked. But the answers get written down, because `/weather` reads them later. A prediction made before the research is worth more than a conclusion drawn after it.

## The method table

Only at `days` and above. One row per method, in `project/2-learn/plan.md`:

| Question | Method | Why this one | What would change your mind |
|---|---|---|---|

The why column is the one that earns its keep. A method with no recorded reason cannot be evaluated afterwards, including by the person who chose it.

## Who you are asking

Write down who, and how you will reach them. If the honest answer is "I do not know yet", that is the first task, not a blocker. See When they have nobody to talk to in `choosing.md`.

There are 2 rules worth stating out loud. Both are simple and both ruin the result if missed:

- **Convenience is not a sample.** A colleague, a friend and your co-founder will confirm almost anything. One stranger who genuinely does this work beats 3 people who like you.
- **Say who is not included.** "Nobody over 50", "only people already using a competitor", "all in one country". Writing the gap down now means you find it before it surprises you at the gate.

## What it costs them

Anyone giving you half an hour is giving you something. Decide before you ask:

- how long it will actually take, honestly
- whether it is recorded, and who sees the recording
- whether there is an incentive, and what
- how they say no, or stop partway

None of this needs a consent form for 2 conversations with people you know. It needs to be said out loud at the start, and it takes 15 seconds.

## What lands where

| File | What it holds |
|---|---|
| `project/2-learn/plan.md` | The plan, questions, method, who, what would change your mind |
| `project/research/*.md` | The raw material afterwards, one file per session |
| `project/2-learn/synthesis.md` | What it added up to, written by `/gather` once there are 3 |

Keep the plan and the findings in separate files. A plan edited after the fact to match what was found is how a project quietly loses the ability to tell you it was wrong.

## Anti-patterns

- A plan longer than the research it plans.
- Handing the user a template to fill in. Ask, then write it for them.
- Accepting a hypothesis nothing could disprove.
- Picking a method that could not produce the disconfirming evidence.
- Recording who you asked and not who you left out.
- Rewriting the plan once the findings are in.
