<!-- Proprietary. K-d studio. Not for redistribution. -->

# Interviews

A semi-structured conversation with one person who does the thing you are building for.

Read this only when interviews have been chosen. See `../choosing.md` for that decision.

## What it is good for

Motivation, history and choice. Why they do it this way, what they tried before, what they rejected and why, what it would take to make them switch. Interviews reach the reasoning behind behaviour.

**What they are not good for:** what people actually do. Memory tidies things up, and nobody reports their own workarounds accurately. If the question is about behaviour, watch instead, see `observation.md`.

## The smallest honest version

**One 20-minute call with somebody who genuinely does this work.**

That is real research, and it fits under an hour. It will not give you a pattern, and it does not need to. Its job is to find out which of your questions were the wrong questions. Almost everyone's first conversation does that.

**3 conversations** is where patterns start to separate from personality, and it is `/gather`'s threshold for calling anything a theme. Do the first before planning the other 2.

## Semi-structured, and why

Fully scripted, and you get a survey read aloud. You learn only what you already thought to ask. Unscripted, and every conversation is about something different, so nothing compares.

Semi-structured is a spine you keep and a licence to leave it. Same 4 or 5 topics every time, in roughly the same order, and you follow whatever interesting thing appears.

## The shape of a conversation

**Open it.** Who you are, why you are asking, how long it will take, that you want the honest version including the unflattering parts, and, if you are recording, ask before you start, not after.

> "I'm trying to understand how [the work] actually goes, not how it's supposed to go. There are no wrong answers, and the boring parts are usually the useful ones. About 20 minutes. Is it all right if I record it so I'm not scribbling?"

**Warm up.** 2 simple questions they can answer without thinking. This is not filler, it sets the register, and people who have answered 2 questions comfortably answer the third honestly.

> What does a normal working day look like for you?
> How long have you been doing this?

**The substance.** 4 or 5 topics, each one anchored in something that actually happened. This is the whole interview.

**Close it.** 2 questions, always:

> What else should this have covered?
> Who else is worth talking to?

The first regularly produces the best thing in the conversation. The second is how you find the next person without a recruiting budget.

## The questions that earn their place

Anchor everything in the past and the specific. See What makes a question worth asking in `../choosing.md` for why.

**What actually happens:**

> Walk me through the last time you did this.
> How often does that come up?
> What do you do when it goes wrong?

**What they have already tried:**

> What did you use before this? Why did you stop?
> What else did you consider?
> What have you rigged up to make it easier?

**What it costs:**

> How much time does this take you in a week?
> How much are you already spending to solve it?
> If this never got fixed, what would happen?

**Their own words for it:** listen for what they call things. The vocabulary people use for their own work is the vocabulary your interface should use, and it is almost never the vocabulary in your head.

## Following an answer

The follow-up is where interviews stop being surveys. 4 prompts, then stop talking:

> Because…
> When you…
> So you are saying…
> Can you give me an example?

**The silence is the technique.** Most people fill it with the thing they had decided not to say. Count to 3 before you speak. It will feel much longer than it is.

**"Tell me more about that"** is worth more than any question you prepared, because it follows their interest rather than yours.

## What not to do

- **Do not pitch.** The moment they know what you want to hear, you stop learning anything. If they ask what you are building, say "you will hear at the end" and mean it.
- **Do not ask about the future.** Would you use this? Would you pay for it? People are kind and they are bad at predicting themselves. Ask what they have already done instead.
- **Do not ask them to design it.** What feature would help? gets their guess at a solution and loses you the problem.
- **Do not correct them.** If they describe your product wrongly, that is the finding. Write it down; do not fix it.
- **Do not ask 2 questions at once.** They will answer the second and you will lose the first.

## If you have nobody to talk to

Interview people who do the work, not people who use your product. They exist whether or not you have users, and they are often easier to reach:

- someone who posted about the problem in public
- someone doing this job in a business near you
- a competitor's customer, found in their reviews
- someone who used to do this and stopped

One person who genuinely does this work is worth 10 who are being polite.

## If you are on your own

Record it, with permission, and listen back the next day. Writing while talking costs you the follow-up, and the follow-up is where the value is.

Your second listen is your second analyst. You will hear things you did not hear live. Particularly the moments you talked over.

## Afterwards

Write it up within a day, while you can still hear the voice. One file per person in `project/research/`, named by date and role rather than by name, `2026-09-24-independent-bookkeeper.md`.

Keep these apart in the file:

- **What they said:** their words, quoted where the phrasing matters
- **What it might mean:** yours, marked as yours

Everything in the first section is `said`. Everything in the second is `inferred`. An interview does not produce `observed`, however vivid it was, and the gate weighs it accordingly.

After 3, `/gather` looks across them for what repeats.

## Anti-patterns

- Pitching, at any point before the end.
- Hypothetical and future-tense questions.
- Leading: "That's frustrating, isn't it?"
- Interviewing friends and colleagues because they are available.
- Writing conclusions into the notes file.
- Forest reading the raw notes and handing back the themes. The user does that pass; forest challenges what they find.
