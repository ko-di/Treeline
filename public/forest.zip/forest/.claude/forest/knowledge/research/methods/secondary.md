<!-- Proprietary. k-d studio. Not for redistribution. -->

# Reading what already exists

These are 4 desk methods that need nobody's time but the user's. Read this when any of them has been chosen, see `../choosing.md`.

## Why this comes first

It is the cheapest research there is and the most skipped, because it does not feel like research. It is also the only kind that fits every setting of `research.time` above `none`.

An hour here routinely does 2 things. It answers part of the question outright. It sharpens the rest, so the conversations you do have are not spent on things you could have looked up.

**Always offer this before sending anyone out to talk to people.** Interviewing 5 people to learn something written in 100 public reviews is a waste of 5 people's goodwill, and goodwill is the scarcest thing a new product has.

## The evidence it produces

This is the part to be straight about. Reading what other people wrote about their users produces `said`, and it is `said` at one remove. It tells you the problem is real; it does not tell you it is real for the person you are building for.

That is genuinely useful and it is not the same as knowing. Record it as what it is, and the gate will weigh it accordingly.

---

## Existing material

**Fits `minutes`.** Anything already written about this problem by anyone.

Where to look, roughly in order of how much it repays:

- **Reviews of the closest existing product:** app stores, G2, Trustpilot, Amazon. Sort by the low scores. People explain their workflow in detail when they are annoyed.
- **Support threads and forums:** Reddit, Discord, trade forums, the competitor's own community. Search the problem, not the product.
- **Anything the user already has:** an earlier attempt, notes from a job they used to do, a spreadsheet they built for themselves, complaints in their inbox.

**The smallest version:** read 20 reviews of the nearest product. Write down the 5 complaints that repeat. That is a finding, and it took half an hour.

**What to record:** the complaint in the reviewer's words, where it came from, and how many people said something like it. Quotes beat summaries, the phrasing is data.

## Competitors

**Fits `minutes`.** What exists, what it costs, and where it gives up.

**The smallest version:** use the 2 closest products yourself for an hour each, doing the real task rather than a tour. Note the exact point each one becomes annoying.

Worth capturing per competitor: who it is for, what it costs, what it does well, where it stops, and what its own users complain about. That last column is the one that matters, it is the gap you might be able to stand in.

**Doing nothing is a competitor, and usually the strongest one.** Most people solving this problem today are using a spreadsheet, paper, or their memory. If you cannot say why someone would switch from nothing, you do not yet have a product, and that is better to discover now.

## Published work

**Fits `minutes`.** Questions somebody has already studied properly.

Worth a search when the question is about general human behaviour, accessibility, a regulated domain, or anything with an established body of evidence behind it. Not worth it for anything specific to this product or this audience, nobody has studied those.

**The smallest version:** one focused search. If the answer exists, take it and move on. If 20 minutes turns up nothing usable, stop; that is also an answer.

**Check the date and check who paid.** A vendor's report about the market for their own product is marketing wearing a lab coat.

## Product review

**Fits `afternoon`.** Only when something already exists that is being redesigned.

**The smallest version:** do the product's main task yourself, slowly, writing down every single step including the ones that seem too small to write down. Most teams have never done this, and it is uncomfortable in a productive way.

Make 3 passes, each looking for a different thing:

- **What is there:** the screens, the steps, the count of them
- **What it is like:** where you hesitate, where you have to remember something, where you would give up if you were not paid to be here
- **What you know but cannot see:** the thing support gets asked constantly, the feature everyone uses wrongly

Write the third one separately. It is `inferred`, and it comes from inside the building. That is the kind of knowledge that feels most like fact and least deserves to.

---

## Afterwards

One file per source in `project/research/`, named by date and what it is, `2026-09-24-reviews-competitor-a.md`.

Keep 2 sections apart:

- **What it said:** quoted, with the source named so it can be found again
- **What it adds:** yours, marked as yours

Then stop. Pattern-finding is `/gather`'s job once there are 3 sources to compare.

## Anti-patterns

- Sending someone out to interview people before this has been offered.
- Presenting second-hand findings as though they were about this product's users.
- Reading only the 5-star reviews, or only the one-star ones.
- Treating a vendor's report as neutral.
- Leaving out doing nothing from the competitor list.
- Summarising a source without keeping a quote you can point at later.
