<!-- Proprietary. k-d studio. Not for redistribution. -->

# Observation

Watching someone do the real thing, in the real place, without helping.

Read this only when observation has been chosen. See `../choosing.md` for that decision.

## Why this method carries weight

Forest weighs a claim by where it came from, and `observed` outranks `said`. This is the method that produces `observed`. It is the reason the tag exists.

People are reliable witnesses to how they feel and unreliable witnesses to what they do. Not dishonestly, they compress, they tidy, they describe the version of the process that makes sense in hindsight. The workaround someone has used every day for a year never comes up in an interview, because to them it is not a workaround. It is just how it works.

**What it tends to buy:**

- the steps nobody mentions, because they stopped noticing them
- the exact place someone hesitates before committing
- the paper note stuck beside the screen, which is a requirement nobody wrote down
- the moment something goes wrong, and what they do next, which is the part that never survives retelling
- at least one feature someone was certain about, killed. That is the cheapest cut anyone makes

That usually takes 20 minutes.

## When to reach for it

When the question is about behaviour in context: how the work actually gets done, where it breaks, what else is in the room. When you suspect the official process and the real process have drifted apart. When someone keeps telling you the current way is "fine".

## When not

When the question is about motivation, history or choice. Why they picked this, what they tried before, what would make them switch. That is an interview. Watching tells you what happens; it does not tell you why, and guessing at why from the outside is how observation goes wrong.

## The smallest honest version

**One person. 20 minutes. The real task, not a demonstration of it.**

The 20 minutes is the simple part. Arranging to be there is the rest, which is why this sits at an `afternoon` of research time rather than under an hour. A screen-share counts, and costs less to set up than a visit.

That is a complete piece of research. It is not a compromised version of a better study. For most questions at Camp 2 it is the whole answer, and a longer session mostly produces more of the same.

Doing 3 sessions is where patterns start to separate from personality. Do the first one before planning the other 2; it usually changes what you would have asked.

## What to look for

There are 4 lenses. Do not try to hold them all at once. Glance across them when the task pauses.

**What they do.** The task itself, step by step. Where they slow down or hesitate. The moment something goes wrong, what they do about it, and whether they notice it went wrong at all. Visible frustration, and what caused it.

**Who they involve.** When they pull someone else in, and what they ask for. When they get interrupted, and how they find their place again. Whether anyone is waiting on them.

**What they use. Every tool, not just yours. The device, the screen size, the second window. Above all the workarounds, the spreadsheet, the notebook, the photo of a screen, the message they send themselves. A workaround is a specification.** It is someone building the missing feature by hand.

**Where they are.** How busy it is, what competes for attention, whether they are sitting or moving. What time of day, and whether that matters.

## How to behave

Say who you are, how long you will be there, whether you are recording, and, this one plainly, that you are not evaluating them. You are trying to understand the work.

Ask 2 questions before they start, and write the answers down:

> What are you trying to get done in the next hour?
> How long do you think it will take?

The second is the one that earns its place. The gap between the estimate and the clock is a finding by itself, and it is one nobody reports accurately afterwards.

**Then go quiet.** Do not answer questions. Do not help. Do not point at the right button.

This is the hard part and it is the entire method. When someone gets stuck, that is not a gap in the session, that is the session. Helping converts the most valuable minute into nothing, and you cannot get it back.

Sit where you can see both the screen and their hands. Every question waits for the end.

## Questions for the end

During the task you ask nothing. Afterwards you ask plenty, and each question is anchored to something you actually saw.

**Anchored to a moment in your notes:**

> Around 20 past, you stopped and went back twice. What was happening there?
> You opened that spreadsheet 3 times, what is it for?
> When that failed, what did you do next, and why that?

**About the workarounds.** These are the highest-value minutes of the whole session:

> What have you rigged up to make this easier?
> What did you need to have ready before you could start?
> What do you do when that does not work?

**To size what you just watched:**

> How often does this come up?
> How much time does it take you in a week?
> Describe the last time this went badly. What was that like?
> If this never got fixed, what would happen?

**To follow a thin answer:** short prompts, then stop talking:

> Because…
> When you…
> So you are saying…
> Can you give me an example?

The silence after a follow-up is the technique. Most people fill it with the thing they were not going to say.

**Do not ask what they want built.** "What would help here?" trades the problem you just watched for their guess at a solution. You already have the better material.

## Notes: facts only

Write what happened, not what it meant.

- **Do not write everything.** A task completed smoothly is not data. The data is hesitation, error, recovery, interruption, asking for help, and the workaround.
- **"Unclear why" is a legitimate entry**, and a better one than a plausible guess. Write it down as unknown and ask at the end.
- **The moment you write because, you have crossed a line.** "Clicked back twice" is observed. "Clicked back twice because the label confused them" is inferred, and inference belongs in synthesis, not in the notes file.

Keeping those apart is not bureaucracy. It lets the gate weigh them differently later. It also stops a guess made on the day from hardening into a fact by the following week.

## If there is nobody using your product yet

Watch someone do the job without it, with whatever they use now. A spreadsheet, paper, a competitor's product, or nothing at all.

This is often the better session. You see the problem itself rather than someone's reaction to your solution, and you find out what they are already willing to put up with.

You do not need a user base. You need one person who does this work, and 20 minutes of their time.

## If you are on your own

You are the only observer, so record it if they agree. You will miss things live; everyone does, and the parts you miss are usually the ones you were not expecting.

Watch it back the next day rather than the same afternoon. The gap is what makes it a second perspective instead of the same one twice.

## Afterwards

Write the notes up within a day, while your shorthand still reads. One file per person in `project/research/`, named by date and role rather than by name, `2026-09-24-warehouse-supervisor.md`.

Keep 2 sections apart in that file:

- **What happened:** the observed record
- **What surprised me:** yours, marked as yours

Then stop. Do not pull themes out yet; that is `/gather`, after there are 2 or 3 sessions to compare. One session read for patterns gives you the patterns of one person.

## Anti-patterns

- **Helping.** Every time.
- Asking "why did you do that?" during the task. It stops the work and turns a doer into an explainer. Save it.
- Watching a demonstration instead of the real task. If they are showing you, you are getting the tidied version.
- Watching a colleague rather than someone who does the work. Convenience is not sampling.
- Writing conclusions into the notes file.
- Forest reading the raw notes and handing back the themes. The user does that pass; forest challenges what they find.
- Treating one session as too small to count. One is enough to be worth doing, and it is the one that changes what you ask next.
