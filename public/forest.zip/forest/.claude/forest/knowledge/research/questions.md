<!-- Proprietary. K-d studio. Not for redistribution. -->

# Questions

A shelf to pick from, grouped by what each question gets at rather than by method. Any method can draw from any group.

**Never read a group out as a list.** Pick the 3 or 4 that serve the question in `plan.md` and put them in the user's own words about their own product. A question bank handed over whole is a survey, and surveys asked in conversation get survey answers.

## How many

| `research.time` | Questions in one session |
|---|---|
| `minutes` | 3 or 4 |
| `afternoon` | 6 to 8, with room to follow |
| `days` and above | The same 6 to 8, asked the same way each time so answers compare |

More questions is not more research. 8 asked well, with follow-ups, beats 20 read out.

## What each group is worth

The groups are ordered by the weight of what they produce. This ordering is the reason the file is arranged this way.

| Group | Produces | Weight |
|---|---|---|
| What actually happened | `said` about real events, and points you at things to go and watch | Strongest available from talking |
| What they have tried | `said` about real decisions already made | Strong |
| What it costs | `said`, and countable | Strong |
| What they expected | `said`, checkable against what they then do | Useful |
| What they think | `said`, about feelings | Weak on its own |
| What they would do | `said` about a future that has not happened | Weakest. Never load-bearing |
| Who they are | Context for everything above | Neutral |

---

## What actually happened

The best questions in the file. Every one asks for a real event rather than a general impression.

> Walk me through the last time you did this.
> Describe the last time it went badly. What was that like?
> How often does that come up?
> What do you do when it goes wrong?
> What did you need to have ready before you could start?
> Who else is involved when you do this?
> What does a normal working day look like for you?

**The workaround questions**, which are the highest-yield in the whole file, a workaround is a feature somebody has already built by hand:

> What have you rigged up to make this easier?
> What are you doing at the moment to get around it?
> What do you keep outside the system, on paper, in a spreadsheet, in a message to yourself?

## What they have tried

Real decisions, already made, with reasons attached.

> What did you use before this? Why did you stop?
> What else did you consider, and why not that?
> What is missing from what you have already tried?
> What would you use instead if this disappeared tomorrow?
> What made you start using it in the first place?

## What it costs

Turns a complaint into a size. Without this, everything in the notes sounds equally urgent.

> How much time does this take you in a week?
> How much are you already spending to solve it?
> How many people does this touch?
> What is the hardest part of it?
> If this never got solved, what would happen?

The last one is the single most useful question in early research. If the honest answer is not much, the problem is real and it is not a product. Better to know now than after a build.

## What they expected

Most valuable asked before someone does something, then checked against what they actually do. The gap is the finding.

> What do you think this screen lets you do?
> What would you expect to happen after that?
> How long do you think this will take?
> What would you do next?
> Where would you look for that?

## What they think

Real, and weak on its own. Useful for language and for priority; never as evidence that something works.

> What is the hardest part about this?
> What would you change, and why?
> How would you describe this to a colleague?
> What is missing?
> What do you like about how you do it now?

That last one matters more than it looks. Whatever they like about the current way is the thing your version must not lose.

## What they would do

Future-tense and hypothetical. People are kind, and poor witnesses to their own future.

> Would you use this?
> Would you pay for it, and how much?
> Would this fit into your week?

**Use sparingly, and record what they produce as `assumed` unless something real backs it.** Pricing answers in this form are close to worthless: what somebody says they would pay and what they pay are different numbers.

Where the question matters enough to need a real answer, replace it with a past-tense one. What have you paid for something like this? Or use something that costs them a real action today.

## Who they are

Ask last, not first. Demographics at the top of a conversation set a form-filling register that is hard to climb back out of.

> What is your role, and what does it actually involve?
> How long have you been doing this?
> Who decides what tools you use?
> What else are you using day to day?

Only ask what changes what you build. Age, gender and company size are worth asking when they change the product and intrusive when they do not.

## Closing

Ask these 2 questions every time, whatever the method:

> What else should this have covered?
> Who else is worth talking to?

The first regularly produces the best thing in the session, because it hands the frame to the person who knows the work. The second is how the next participant gets found without a budget.

---

## Rewriting for the product

Every question here is generic on purpose. Before using one, put it in the user's words about the user's thing:

- "the last time you did this" → "the last time you closed off a month's invoices"
- "what you are using at the moment" → "how you're tracking it in the spreadsheet"

A question in the participant's own vocabulary gets a specific answer. A question in research vocabulary gets a research answer.

## Anti-patterns

- Reading a group out as a list.
- 2 questions in one.
- Leading, "that's frustrating, isn't it?"
- Future and hypothetical questions where a past-tense one exists.
- Demographics first.
- Asking a question whose answer the compass already holds.
- Asking anything you would not change a decision over.
