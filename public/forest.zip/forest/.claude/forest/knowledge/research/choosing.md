<!-- Proprietary. k-d studio. Not for redistribution. -->

# Choosing a research method

Read this before suggesting any research. It is short on purpose: it gets read every time, and only the one method file chosen after it gets opened.

## The frame the user needs first

Most people meet a list of research methods and hear you are behind. That reaction stops the work before it starts, and it is the wrong reaction.

What they should hear instead:

> You are not doing all of this. You are doing one thing, because there is one thing you do not know. Then you carry on building.

Research here is not a phase to complete. It is what you do the moment you notice you are guessing. One afternoon of the right method beats a month of the wrong one, and beats a thorough plan nobody runs.

Never show the whole list. Narrow first, offer 2 or 3, and say what each one buys. A menu of 18 reads as homework; a choice between 3 reads as a decision.

## The rule

**A method answers a question you can name.**

If the user cannot say what they do not know, do not pick a method. Help them name the gap first. A method chosen before the question produces material nobody uses.

These 2 questions get there quickly:

- What are you about to decide?
- What would you have to be wrong about for that decision to be a mistake?

The second one is usually the research question.

## Narrowing: time first

Most people arriving here do not have a research budget. They have a gap in the week and something to ship. Time filters before camp and before kind. A list containing a 2-week diary study is a stressful list, even when the afternoon option sits next to it.

Ask it plainly, once:

> How much time do you want to put into this before you decide?

| Time | What fits | What it gets you |
|---|---|---|
| **`minutes`**, under an hour | Reading what people already say. One phone call. A desk exercise | Enough to stop the worst guess. Rarely enough to settle a direction |
| **`afternoon`**, half a day | One observation, or 2 conversations, and the notes written up | One real account. Usually kills at least one assumption |
| **`days`**, 2 or 3 | 3 sessions and a synthesis pass | Where patterns separate from personality. The first point you can honestly say people rather than someone |
| **`weeks`**, 2 or more | Diary studies, longitudinal work, more than one method | Behaviour over time, and anything that does not happen while you are watching |

Write it to `compass.json.research.time`. Re-ask when it visibly stops fitting. Someone who said `minutes` when they packed and now offers to talk to 8 people has changed their mind. That is good news rather than an inconsistency.

**`none` is a real answer**, and no lecture follows it. The decision then rests on `assumed`, that gets recorded, and the gate will say so at the close of the camp. Bookkeeping, not punishment. Offer the 20-minute version once; if it is declined, drop it and carry on.

### The rule that makes this work

**Never name a method that does not fit the time.**

Not "you could run a diary study, but you haven't got time", that sentence is the stress. Do not mention it.

One exception. When the time genuinely cannot answer the question, say so as a fork rather than a shortfall:

> An hour gets you what people complain about in public, which tells you the problem is real. It will not tell you how they work around it, that needs somebody's afternoon, and 20 minutes of yours. Want the hour version now, or park this until you have the afternoon?

That is 2 routes and no verdict. See Never a dead end in `QUESTIONING.md`.

## Then: camp, and kind

There are 4 kinds of research. The camp usually settles the kind.

| Kind | The question it answers | Where it belongs |
|---|---|---|
| Secondary | Has someone already found this out? | Camp 1–2, always first |
| Exploratory | What is actually going on for these people? | Camp 2 |
| Generative | What should get made? | Camp 3–4 |
| Evaluative | Does the thing that got made work? | Camp 5–6 |

**Secondary comes first, always.** It is the cheapest and the most skipped. An hour reading what already exists routinely answers half the question and sharpens the other half, and it costs nobody's time but the user's, which is why it is the one kind that fits every setting above `none`.

In the tables below, the Fits column is a floor rather than an exact match. A `days` setting can run anything marked `minutes` or `afternoon`, and often should: a desk hour before the conversations makes the conversations better.

## Secondary — has someone already found this out?

| Method | Fits | Good for | Smallest honest version |
|---|---|---|---|
| Existing material | `minutes` | Anything already written about this problem: support threads, reviews, forum posts, an earlier attempt, notes from a job they used to do | Read 20 reviews of the closest existing product. Write down the 5 complaints that repeat. See `methods/secondary.md` |
| Competitors | `minutes` | What already exists, what it costs, what its users say is wrong with it | Use the 2 closest products yourself for an hour each. Note where each one gives up. See `methods/secondary.md` |
| Published work | `minutes` | Questions somebody has already studied properly, behaviour, accessibility, pricing, a regulated domain | One focused search. If the answer exists, take it and move on. See `methods/secondary.md` |
| Product review | `afternoon` | An existing product being redesigned: what is there now, and what it is like to use | Do the main task yourself, slowly, writing down every step. See `methods/secondary.md` |

## Exploratory — what is actually going on?

| Method | Fits | Good for | Smallest honest version |
|---|---|---|---|
| Observation | `afternoon` | How the work really happens, including the parts nobody mentions | One person, 20 minutes, the real task. See `methods/observation.md` |
| Interviews | `minutes` → `days` | Motivation, history, what they tried before, what they chose against | One 20-minute call with somebody who does this work. 3 conversations over a few days. See `methods/interviews.md` |
| Journey map | `days` | A process with stages, where the trouble is somewhere in the middle | Walk one person through the whole path, start to end, and mark where it goes wrong |
| Jobs to be done | `days` | What people are actually hiring a solution for, and what they would drop for it | Ask 5 people what they used before this and why they stopped |
| Diary | `weeks` | Anything that happens over days or weeks, or in places you cannot go | 5 people, one short prompt a day, one week |

## Generative — what should get made?

| Method | Fits | Good for | Smallest honest version |
|---|---|---|---|
| Gap analysis | `minutes` | Naming the distance between how it works now and how it should | 2 columns, what happens now, what should happen, and a list of what is missing between them. Needs nobody but the user |
| Value proposition | `afternoon` | Why anyone would choose this over what they do today | One sentence: who it is for, what it replaces, why it wins. Show it to 3 people who fit |
| Card sorting | `afternoon` | How people expect things grouped and named, before the navigation is built | Write each item on a card. Ask 5 people to group them. Watch where they hesitate |
| Group session | `days` | Range of opinion fast, or getting people who disagree into one room | 4 or 5 people, one hour, 3 topics. Needs a second person taking notes |

## Evaluative — does it work?

| Method | Fits | Good for | Smallest honest version |
|---|---|---|---|
| Analytics | `minutes` | Where people stop, on a product that already has traffic | One funnel, one drop-off, one question about it |
| Usability test | `afternoon` | Whether someone can actually complete the task in the thing you built | 2 people, one task each, watching without helping |
| Survey | `afternoon` → `days` | Numbers across more people than you can sit with | 3 questions, one scale, 2 open. An afternoon to write, days to gather. Never more before you have run it once |

## Choosing with the user

Use Guided mode from `QUESTIONING.md`: the question, why it matters, 3 options, each traced to something they have said.

**All 3 must fit the time.** That is the filter; within it, offer variety of a different kind:

1. **The desk one:** needs nobody's time but theirs
2. **The one that involves a person:** costs access as well as hours
3. **The one closest to the decision they are about to make**

Say what each buys in outcomes rather than method names. "20 minutes of watching usually kills one feature you were certain about" lands; "ethnographic observation" does not.

If only one method fits the time, it is not a guided question any more, it is a recommendation. Make it as one, in a sentence, and move on. Padding to 3 with options that do not fit is how the list becomes homework again.

**If the honest answer is "you do not need research for this", say so.** A decision that is cheap to reverse does not need evidence; it needs a decision. Sending someone to do research they do not need teaches them that research is a tax.

## What makes a question worth asking

The method decides who you speak to and how. The questions decide whether it was worth doing. Most disappointing research is a sound method carrying weak questions.

The 4 tests, in the order they matter.

**Past beats future.** People are poor witnesses to their own future behaviour, and polite about hypotheticals.

| Weak | Stronger |
|---|---|
| Can you see yourself using something like this? | Describe the last time you struggled with this. What was that like? |
| Would you use this feature? | What are you doing at the moment to make this easier? |
| How likely are you to buy it? | What have you already tried, and why did you stop? |

The weak column is not worthless, but it is `said` about a future that has not happened, the thinnest evidence there is. The gate will treat it that way, so nothing load-bearing should rest on it.

**Behaviour beats opinion.** "What feature would help?" gets you someone's guess at a solution. "What workarounds have you built for this?" gets you the problem itself, already specified, by someone who has been living with it.

**Put a number on it.** A complaint with no size attached cannot be prioritised later, and everything sounds urgent in the room.

- How often does this come up?
- How much time does it take in a week?
- How much are you already spending to solve it?

**Ask what happens if it stays broken.** The most useful question in early research, and the one most often skipped:

> If this never got solved, what would happen?

If the honest answer is not much, the problem is real but it is not a product. That is a finding, and it costs far less to get now than after a build.

## When they have nobody to talk to

Common at Camp 2, and not a blocker. Every exploratory method has a version for it:

- Watch someone do the job without your product, with a spreadsheet, on paper, with a competitor, or not at all. This is often better data, because you see the problem rather than a reaction to your solution.
- Read what people already say in public about the problem. It is secondary research, it is real, and it is tagged accordingly.
- One person who genuinely does this work is worth more than 10 who are being polite. Finding that one person is the task, not a prerequisite for it.

Never let "I have no users" end the conversation. See Never a dead end in `QUESTIONING.md`.

## When they are on their own

Most of these methods were written for teams with a researcher, a second facilitator and a product manager. Forest's user is frequently one person. Say the solo version plainly rather than describing a team the user does not have:

- **2 facilitators** becomes: record it, so the second pass is the second observer. Do that pass the next day, not the same hour.
- **A colleague to co-analyse** becomes: forest challenges the themes it did not generate. The user finds the patterns; forest asks which note each one rests on, and which notes argue against it.
- **A stakeholder to set scope** becomes: the compass. It already holds who this is for and what it promised them.

## Write down the choice

One line per method, in `project/2-learn/plan.md`: the question, the method, and why that method. See `planning.md`, which also covers how much plan is worth writing at each setting of `research.time`.

The questions themselves come from `questions.md`, and what to do with the answers is in `outcomes.md`.

The why is the load-bearing part. A method with no reason recorded is one nobody can evaluate afterwards, including the person who chose it.

## What comes back

Everything gathered is `observed`, `said`, `inferred` or `assumed`, and a method does not upgrade a tag. Watching someone produces `observed`. Someone telling you what they usually do produces `said`, even in the middle of an observation session. A published study produces `said` about somebody else's users, which is not the same as knowing about these ones.

Research narrows what you are guessing about. It does not turn a guess into a fact, and the kit will not pretend otherwise at the gate.

## Anti-patterns

- Showing the full method list. Narrow by time, then offer up to 3.
- Naming a method that does not fit the time, even to rule it out.
- Picking a method before the question is named, or before the time is known.
- Treating little time as a problem to be talked out of. It is a constraint, like any other, and the kit designs inside it.
- Describing a team. Say the solo version.
- Treating "I already know this" as laziness. Sometimes they do know. Secondary research is how they check cheaply.
- Letting research become the work. The point is to stop guessing and get back to building.
- Sending someone to research a decision that is cheap to reverse.
