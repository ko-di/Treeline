<!-- Proprietary. k-d studio. Not for redistribution. -->

# Turning findings into decisions

What happens after the research and before the requirements. Read this when Camp 2 is closing, or whenever a piece of research has produced notes that nobody has done anything with yet.

## The gap this closes

Research that stops at a list of findings changes nothing. The common failure is not a shortage of findings. It is a pile of them with no owner, no order, and no link to anything that will get built.

It takes 3 moves. Separate what you saw from what you conclude. Turn conclusions into recommendations pointed at somebody. Then turn the ones in scope into requirements that carry their evidence with them.

## First, keep the layers apart

| Layer | What it is | Tag |
|---|---|---|
| Observation | What happened. "4 of 5 went back twice on the payment screen" | `observed` |
| Finding | What it means. "The back button reads as cancel" | `inferred` |
| Recommendation | What to do about it. "Label it, and move it out of the primary position" | A decision, not evidence |
| Requirement | What gets built, and how you know it is done | Goes to Camp 3 |

Each layer is a step further from the room, and each is easier to argue with than the one before. Keeping them in separate paragraphs is what lets somebody 6 months from now see which is which. Including the person who wrote them.

**A recommendation is never evidence.** If it travels into the brief without the observation attached, the thing that was actually seen gets lost and only the opinion survives.

## Recommendations point at somebody

Split them by who acts, because an unaddressed recommendation is a wish:

**For the design:** what has to be true for the person, without prescribing the solution. "Someone must be able to tell, before they commit, what they are about to be charged." This states the goal, and leaves the designer their job.

**For the build:** what the system has to do. "Prices need to be available on the review screen without a second request."

**For more research:** what you now know you do not know. This is the one everyone drops, and it is the one that compounds: every study produces new questions, and unrecorded they get re-discovered at cost later.

Each one carries the observation it came from. One line is enough.

## Priority, when there is no metric

The standard advice is to rank by KPI. Plenty of forest users have no KPI at Camp 2. Telling them to go and get one is how a workflow starts feeling like a corporate process.

**Rank against the promise instead.** The compass holds who this is for and what it promised them. So, per recommendation:

1. Does this stop the beneficiary getting what the product promised? → high
2. Does it make that harder or slower? → medium
3. Is it something you noticed and did not like? → low

Say the bands out loud. Most of the value is in agreeing what is not high, and it is much easier to agree that when the alternative is named.

## 3 of 15 can matter more than 9

A small number is not automatically noise. The question is not how many, it is whether the few represent somebody who matters.

Say 3 people out of 15 hit a problem. If they are the only 3 who had never used the product before, that is not a small finding. It is everything about first use, and the other 12 could not have shown it to you.

So when a count is small, ask who the people were before deciding it does not count. Context, not arithmetic.

## What gets deferred, and where it goes

Some of what research turns up is real and not for now. Write it down rather than losing it:

| Kind | Goes to |
|---|---|
| A requirement that is real but out of scope | The later column in Camp 3's scope split |
| A question research raised and did not answer | `project/2-learn/open-questions.md` |
| A decision taken on thin evidence | `/rationale`, so the thinness is recorded with it |

`/summit` and `/retro` both read the open questions. A question written down at Camp 2 and answered at the 3-month mark is the cheapest research in the whole trail.

## Into Camp 3

A requirement that carries its evidence can be argued with honestly. One that does not becomes folklore within a month. Nobody remembers why it is there, and nobody dares remove it.

So each requirement going into `project/3-decide/prd.md` carries:

- what it requires, in terms of what the person can do
- what would show it is finished
- the finding behind it, and that finding's tag

Where a requirement has no finding behind it, say so and tag it `assumed`. That is honest, common, and `/weather` has already seen it. A requirement nobody researched is not a scandal. It is a requirement nobody researched, and nothing more.

## Anti-patterns

- Presenting findings without recommendations, or recommendations with no owner.
- Recommendations that prescribe a solution where a goal would do.
- Dropping a finding because only a few people showed it, without asking who they were.
- Letting a recommendation travel without the observation it rests on.
- Losing the questions the research raised.
- Writing a requirement that nothing can tell you is finished.
