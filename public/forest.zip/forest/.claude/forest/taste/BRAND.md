# k-d studio — Brand Identity Framework

> Proprietary — k-d studio. Not for redistribution.

This framework governs how brand identity is created for any project — whether a product built from scratch or a client engagement with existing guidelines. It is not a brand guide for k-d studio itself. It is the method by which k-d studio constructs brand identity for others.

DESIGN.md governs layout. MOTION.md governs animation. BRAND.md governs the construction of identity. The same standard applies: every decision must be traceable to a reason. A brand that could belong to anyone belongs to no one.


## 1. Brand Discovery

Before any visual work begins, the brand must be understood — not described, understood. Description produces adjectives. Understanding produces constraints.

### Questions to ask

These are not a checklist. They are a conversation. The answers rarely arrive in order. Listen for what the person says without prompting — that is where the real brand lives.

**About the work:**
- What do you actually do? (Not the elevator pitch. The real answer.)
- What problem did you start by solving? Has that changed?
- What would your best customer say about you to a friend?
- What would they never say?

**About position:**
- Who do people confuse you with? Why are they wrong?
- What are you deliberately not? (This answer is often more useful than what you are.)
- If you disappeared tomorrow, what would be unfillable?

**About character:**
- If your brand walked into a room, what would people notice first?
- What's the emotional register? (Calm authority? Sharp energy? Quiet warmth?)
- What do you want people to feel after interacting with you — not during, after?

**About aesthetics:**
- Show me three things you've made that feel like you.
- Show me three things other people made that you wish were yours.
- What visual work makes you uncomfortable? Why?

### What to listen for

The brand is rarely in the direct answers. It is in the patterns across answers:
- Repeated words or phrases the person gravitates toward
- The gap between what they say they are and what they demonstrate they are
- Aesthetic reactions that are visceral rather than considered ("I hate that" is more useful than "I prefer something more minimal")
- The things they mention without being asked

### Extracting brand essence

Distill the conversation into a single sentence that is not a tagline and not a mission statement. It is a constraint: "Everything we make must feel like ___." If this sentence could apply to a competitor, it is not specific enough. If it could not guide a colour choice, it is not concrete enough.


## 2. Identity Components

Every brand identity is built from these components. None are optional. An identity missing any one of them will drift — it will make decisions by habit rather than by principle.

### Positioning

Positioning is not a statement. It is a set of boundaries.

Define three things:
- **What you are** — in concrete terms, not aspirational language
- **What you are not** — the adjacent things you could be mistaken for but refuse to be
- **Where you stand** — relative to the landscape, not above it

Positioning must be falsifiable. "We make beautiful software" is not positioning — no one claims to make ugly software. "We make dense, professional tools for people who already know what they're doing" is positioning — it excludes an audience, which means it includes one.

### Values

Three to five. Not words — commitments.

A value is not "innovation" or "excellence" or "integrity." These are decorations. A value must be specific enough to resolve a disagreement. When two team members propose different approaches, the values should make the answer obvious.

**Test:** if the opposite of a stated value is something no reasonable company would claim, it is not a value. It is a platitude. "We value quality" — who doesn't? "We ship before it's comfortable" — now there is a real position.

Format each value as a short phrase followed by one sentence that explains what it means in practice.

### Personality

If the brand were a person, describe them — not with a persona document, but with five to seven adjectives that could not all apply to the same competitor.

Pair each adjective with its boundary:
- "Direct — but never aggressive"
- "Warm — but never sentimental"
- "Precise — but never cold"

The boundaries matter more than the adjectives. Without them, "warm" means nothing.

### Voice & Tone

Voice is constant. Tone shifts by context.

Define the voice along these spectrums:
- Casual ←→ Formal
- Playful ←→ Serious
- Irreverent ←→ Respectful
- Enthusiastic ←→ Matter-of-fact

Place the brand on each spectrum with a specific position, not the middle. Brands that live in the middle of every spectrum have no voice at all.

Provide DO and DON'T examples for key contexts:
```
DO:  "Your project is live."
DON'T: "Congratulations! 🎉 Your amazing project is now live and ready for the world!"

DO:  "We couldn't process that. Try again, or contact us."
DON'T: "Oops! Something went wrong. We're super sorry about that!"
```

### Visual Language

Not specific colours or typefaces — those come later. This is the principle that governs how visual choices are made.

Define:
- **Density** — how much information per screen (sparse, moderate, dense)
- **Contrast** — how much variation between elements (subtle, moderate, dramatic)
- **Temperature** — warm tones, cool tones, neutral
- **Texture** — flat, layered, dimensional
- **Movement** — still, restrained motion, expressive motion

Each of these should trace back to the brand personality. A "direct, precise, confident" brand does not produce sparse layouts with soft pastels. A "gentle, approachable, human" brand does not produce high-contrast interfaces with sharp edges.


## 3. Colour System Principles

Colour is the fastest channel of communication. Before the viewer reads a word, they have already received a message from the palette. That message must be intentional.

### Structure

Every palette needs exactly four layers:

- **Primary** — the brand's signature. One colour, or at most two. This is what people remember. It carries the weight of recognition.
- **Secondary** — supporting tones that create range without competing with the primary. These exist to give the primary room to work.
- **Neutral** — the background, the text, the infrastructure. Neutrals are not an afterthought. They are the surface on which everything else performs. A warm neutral and a cool neutral produce entirely different emotional registers from the same accent colour.
- **Semantic** — success, warning, error, info. These must be legible and must not clash with the brand palette. They are functional, not decorative.

### Relationships

Colours do not exist in isolation. They exist in relationship.

- **Contrast ratio** — every colour pairing must meet WCAG AA at minimum. This is not a suggestion. It is a legal and ethical requirement.
- **Harmony** — adjacent colours on the wheel produce calm. Complementary colours produce energy. Split-complementary produces sophistication. Choose the relationship that serves the brand personality.
- **Hierarchy** — the most saturated colour draws the eye first. Use saturation to direct attention, not to decorate.

### How many is enough

Fewer than you think. A strong identity can operate with:
- 1 primary colour
- 1-2 secondary colours
- 3-4 neutral steps
- 4 semantic colours

If the palette has more than 8 non-semantic colours, audit it. Each colour must have a role. A colour without a role is visual noise.

### Dark mode

Dark mode is not an inversion. It is a redesign.

- Primary colours often need adjustment — a hue that works on white may not work on near-black
- Saturation typically needs to decrease to avoid eye strain on dark surfaces
- Neutral steps must be re-established, not reversed
- Semantic colours need re-testing against dark backgrounds
- The emotional register may shift — account for this deliberately rather than discovering it accidentally


## 4. Typography Pairing Principles

Typography is the primary medium of communication. Every other visual decision is secondary to type. A wrong typeface will undermine correct colour, correct spacing, and correct layout simultaneously.

### Display vs body

These serve different functions and are chosen by different criteria:

- **Display** (headings, heroes, feature text) — chosen for character. This is where the brand's personality is most visible in type. It can be expressive, distinctive, even challenging — because it appears at large sizes where legibility is not in question.
- **Body** (paragraphs, UI text, captions) — chosen for endurance. This typeface will be read for minutes or hours. Comfort, rhythm, and even colour (the overall darkness of a text block) matter more than personality.

### Serif vs sans-serif

This is not a stylistic preference. It is a structural decision.

**Serif** communicates: established, considered, editorial, literary, authoritative. Use when the brand's personality is rooted in depth, tradition, or intellectual rigor.

**Sans-serif** communicates: contemporary, direct, systematic, technical, clean. Use when the brand's personality is rooted in efficiency, modernity, or simplicity.

**Monospace** communicates: technical, precise, mechanical, honest. Use when the brand operates in engineering, data, or code-adjacent domains — or when the rawness of monospace serves an intentional aesthetic.

These are defaults, not rules. A serif used unexpectedly in a tech product creates tension that can be powerful — if intentional. An unintentional choice is not tension. It is confusion.

### What makes a good pairing

Two typefaces pair well when they share structural similarity but differ in character.

- Same x-height, different personality (a geometric sans with a humanist serif)
- Same era of design influence, different category
- Complementary weights — if the display face is heavy, the body face benefits from being lighter

Two typefaces from the same category (two geometric sans-serifs, two transitional serifs) will compete rather than complement. They are too similar to justify their coexistence.

**The one-typeface test:** before adding a second typeface, ask whether a single family with sufficient weight range could serve both roles. One typeface used well is always superior to two typefaces used without purpose.

### Type scale and brand personality

The ratio between heading sizes and body sizes communicates directly:

- **Large ratio** (heading 3-4x body) — dramatic, editorial, high-impact
- **Moderate ratio** (heading 2-2.5x body) — balanced, professional, versatile
- **Small ratio** (heading 1.5-2x body) — dense, efficient, tool-like

The scale must match the personality. A brand described as "bold and expressive" with a tight type scale is contradicting itself.


## 5. Imagery Direction

Photography, illustration, and iconography are not decoration. They are communication. Every image must earn its place the same way every element earns its place — by serving the task and the brand simultaneously.

### Style

Define the approach:

- **Documentary** — real moments, real people, unposed. Communicates authenticity, groundedness, honesty.
- **Editorial** — composed, styled, intentional. Communicates sophistication, taste, point of view.
- **Lifestyle** — aspirational but plausible. Communicates warmth, relatability, desire.
- **Abstract** — texture, form, colour without representation. Communicates conceptual thinking, modernity, design-forward identity.

Choose one primary mode. A brand that mixes documentary and editorial photography without discipline will feel uncertain of its own identity.

### Composition

Define preferences that constrain:
- Centred vs rule-of-thirds vs asymmetric
- Tight crops vs environmental context
- Single subject vs ensemble
- Negative space: abundant or minimal

### Colour treatment

Photography must coexist with the brand palette. Define:
- Warm, cool, or neutral cast
- Saturated or desaturated
- High contrast or flat
- Whether a consistent colour grade is applied across all imagery

The colour treatment is one of the strongest unifying forces in a visual identity. Inconsistent colour treatment across images produces the impression of inconsistent identity.

### What to avoid

Be explicit about exclusions:
- Stock photography with visible staging (handshakes, pointing at whiteboards, diverse-team-around-laptop)
- Imagery that contradicts the brand's emotional register
- Visual cliches of the industry (every fintech uses blue gradients; every wellness brand uses sage green and linen textures)
- Illustration styles that undermine the type system (cartoon illustrations paired with a serious serif)


## 6. Tone of Voice Framework

Voice is deeper than copywriting guidelines. It is the way the brand thinks out loud.

### Voice spectrum

Place the brand precisely on each axis. Document the position with a brief rationale:

| Axis | Position | Rationale |
|------|----------|-----------|
| Casual ←→ Formal | e.g., 70% toward casual | "We're experts who don't need to prove it with jargon" |
| Dry ←→ Warm | e.g., 60% toward dry | "Respect for the reader's time over emotional padding" |
| Confident ←→ Humble | e.g., 80% toward confident | "We've earned our perspective" |
| Concise ←→ Expansive | e.g., 90% toward concise | "Every word earns its place" |

### Writing principles

- **Active voice** as default. Passive voice only when the actor is genuinely irrelevant.
- **Sentence length** — define the target. Short sentences (under 15 words) create urgency and clarity. Longer sentences create depth and nuance. The brand needs one as its centre of gravity.
- **Jargon policy** — define precisely. "No jargon" is itself unclear. Better: "Use technical terms only when the audience would find the plain-language alternative patronizing."
- **Punctuation personality** — em dashes or parentheses? Oxford comma or not? Exclamation marks: never, rarely, or strategically? These small decisions accumulate into a recognizable voice.

### Per-context tone shifts

Voice is constant. Tone adapts. Define the shift for each context:

| Context | Tone Shift | Example |
|---------|------------|---------|
| Marketing / landing page | Most expressive end of the voice | The place to make promises |
| Product UI | Most concise, most neutral | Get out of the user's way |
| Error messages | Calm, specific, solution-oriented | Never blame. Always direct. |
| Onboarding | Slightly warmer, slightly more patient | The user is learning |
| Support / help docs | Clear, thorough, unhurried | Assume good faith and real confusion |
| Email / notifications | Brief, respectful of the inbox | Earn the open |


## 7. Anti-Patterns

These are the marks of a brand that was assembled rather than designed. Recognizing them is the first defence against producing them.

### Stock identity

- **Stock photography** — if the image could appear on a competitor's site without anyone noticing, it is not brand photography. It is inventory.
- **Template copy** — "We're passionate about helping businesses grow." This sentence has been written ten million times. It communicates nothing except that the writer did not think hard enough to write something specific.
- **Safe colour choices** — blue and white. Not because blue is bad, but because blue-and-white is the colour choice of organisations that did not make a colour choice.
- **Default typefaces** — Inter, Poppins, Montserrat. These are fine typefaces rendered meaningless by ubiquity. If the typeface is the first result in a "best Google Fonts" article, it cannot differentiate.

### Labels instead of constraints

Brand guidelines that state "Our brand is modern, innovative, and human-centred" have said nothing actionable. These are labels — they describe without constraining. A useful brand guideline makes certain decisions impossible. If the guideline permits everything, it governs nothing.

**Test:** take the stated brand attributes and ask whether they would prevent any specific design decision. If "modern and innovative" would not prevent a single layout choice, type choice, or colour choice, it is not a guideline. It is a caption.

### The consensus trap

Brands designed by committee converge toward the centre of every spectrum. They are moderately warm, moderately professional, moderately approachable. They offend no stakeholder and attract no viewer. A brand must be willing to exclude — to be wrong for some people in order to be unmistakably right for others.

### Mistaking trends for identity

A brand built on the current trend (glassmorphism, brutalism, AI-gradient-mesh) will expire with the trend. Identity is built on specificity, not style. The visual execution may evolve; the underlying character must not.


## 8. Generating brand-context.md

Every project receives a brand context file at `.claude/brand-context.md`. This file is the operational translation of the brand identity. It is read by all review skills (audit, critique, polish, typeset, arrange, normalize, etc.) to evaluate design decisions against the brand.

### Process

1. Complete the brand discovery process (Section 1)
2. Define all identity components (Section 2)
3. Make specific visual decisions (colours, typefaces, imagery)
4. Write the file

### Format

```markdown
# Brand Context — [Project Name]

## Positioning
[What you are. What you're not. Where you stand. 2-4 sentences.]

## Values
- [Value phrase] — [What it means in practice]
- [Value phrase] — [What it means in practice]
- [Value phrase] — [What it means in practice]

## Personality
[5-7 adjectives with boundaries. e.g., "Direct — but never aggressive"]

## Voice & Tone
[Spectrum positions. Writing principles. Per-context shifts.]

## Colour Palette
- Primary: [hex] — [name/description]
- Secondary: [hex] — [name/description]
- Neutral scale: [hex values from lightest to darkest]
- Semantic: success [hex], warning [hex], error [hex], info [hex]

## Typography
- Display: [Typeface name] — [weights used]
- Body: [Typeface name] — [weights used]
- Mono (if applicable): [Typeface name]
- Scale: [ratio and base size]

## Imagery Direction
[Style, composition, colour treatment. What to use. What to avoid.]

## Anti-Patterns
[Specific things this brand must never do. Be concrete.]
```

### Rules

- Every field must be filled. An empty section means a decision was not made, and an unmade decision will be made by accident later.
- Hex values must be exact. "A warm blue" is not a specification.
- Typeface names must be specific and available (hosted or licensed). "A clean sans-serif" is not a specification.
- Anti-patterns must be specific to this brand, not generic. "No stock photography" is generic. "No overhead flat-lay product shots" is specific.


## 9. Client Brand Intake vs Building From Scratch

There are two paths to a brand-context.md. The process differs. The output is identical.

### Path A: Client has existing brand guidelines

The client arrives with a PDF, a Figma file, a Notion page, or a slide deck. The task is translation, not creation.

1. **Audit the guidelines** — what is actually specified? Brand guidelines vary enormously in completeness. Some define everything. Most define a logo, two colours, and a typeface, then fill the remaining pages with aspirational language.
2. **Identify the gaps** — what decisions remain unmade? The most common gaps: voice and tone, semantic colours, dark mode palette, type scale, imagery direction beyond "professional and high quality."
3. **Fill the gaps** — using the framework above, make the decisions the original guidelines left open. Present these to the client as proposals, not assumptions.
4. **Translate to brand-context.md** — convert the guidelines (plus gap-fills) into the operational format.

The goal is not to redesign the client's brand. It is to make their brand actionable in code.

### Path B: Client has no brand

The client arrives with a product idea, a company name, and opinions. The task is creation.

1. **Run the discovery process** (Section 1) — this is not optional and cannot be abbreviated. A brand built without discovery is a brand built on the designer's preferences, not the client's identity.
2. **Build the identity components** (Section 2) — positioning, values, personality, voice, visual language. Present these for approval before any visual work begins.
3. **Make specific visual decisions** — colour palette, typography, imagery direction. These flow from the approved identity components. If a colour choice cannot be traced back to the personality and positioning, it is arbitrary.
4. **Generate brand-context.md** (Section 8) — the deliverable.

The brand-context.md is not the brand. It is the operating instructions for the brand. The brand lives in the totality of decisions made across the identity — the context file makes those decisions available to every tool and process in the system.


## 10. Client Brands and k-d studio's Design System

k-d studio's design principles (DESIGN.md) are universal. They apply to every project regardless of brand:

- Start with the person, not the screen
- Nothing without reason
- Reduce until it breaks
- Every state is a design problem
- Against the arbitrary

These are principles of craft. They do not dictate a visual style. They dictate a standard of intentionality.

The brand-context.md dictates the visual style. The design principles dictate the rigor with which that style is applied. A client's brand might call for warm, rounded, approachable surfaces — but those surfaces will still be built on a precise grid, with deliberate spacing, with every state resolved, with every element earning its place.

**What k-d studio controls:** precision, structure, craftsmanship, the standard of execution.

**What the brand controls:** colour, type, tone, personality, emotional register, imagery.

When they conflict — when a client's brand guidelines specify a treatment that violates a design principle (e.g., mixing depth techniques, using decoration without function) — raise it. Explain the principle. Propose an alternative that honours both the brand's intent and the standard of craft. Do not silently override the client's brand. Do not silently violate the design principles. Resolve the tension explicitly.
