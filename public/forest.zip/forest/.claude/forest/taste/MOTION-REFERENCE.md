<!-- Proprietary — k-d studio. Not for redistribution. -->

# k-d studio — motion reference

Deep reference for easing, duration, and spring tuning. Paired with `MOTION.md` (the principles and tokens) and `MOTION-PATTERNS.md` (code recipes).

Use this file when tuning existing motion, choosing between 2 curves, or bridging to platform-specific token systems.

---

## Cubic Bézier cheat sheet

All values are `cubic-bezier(x1, y1, x2, y2)`.

### Standard curves

| Name | Value | Feel | Use for |
|---|---|---|---|
| `--ease-out` (default) | `(0.22, 1, 0.36, 1)` | Fast start, gentle settle | Elements entering |
| `--ease-in` | `(0.42, 0, 1, 1)` | Slow start, quick finish | Elements leaving |
| `--ease-in-out` | `(0.42, 0, 0.58, 1)` | Smooth both ends | On-screen repositioning |
| CSS default `ease` | `(0.25, 0.1, 0.25, 1)` | Balanced | Avoid, too generic; use named token |
| `linear` | `(0, 0, 1, 1)` | Constant speed | Opacity, colour, progress bars |

### Expressive curves

| Name | Value | Feel |
|---|---|---|
| `--ease-productive` | `(0.22, 0.61, 0.36, 1)` | Sharp deceleration |
| `--ease-expressive` | `(0.4, 0.14, 0.3, 1)` | Slower start, confident finish |
| `--ease-dramatic` | `(0.16, 1, 0.3, 1)` | Strong deceleration |

### With overshoot (playful contexts only)

| Intensity | Value | Feel |
|---|---|---|
| Mild | `(0.34, 1.2, 0.64, 1)` | Subtle bounce at end |
| Medium | `(0.34, 1.56, 0.64, 1)` | Noticeable spring feel |
| Strong | `(0.2, 1.8, 0.4, 1)` | Pronounced bounce |

Use overshoot only where playfulness fits. Most k-d studio work demands restraint. Reach for overshoot deliberately, never by default.

---

## Spring parameters (Framer Motion, Reanimated)

**Springs are for gestures only**, a drag, a swipe release, a pull, where the element is answering the hand. Transitions (open, close, appear, move) use the easing tokens. And a k-d studio spring never overshoots: every preset below is critically damped, so it settles as fast as physics allows with no bounce.

Springs simulate physics. They do not have a fixed duration, the animation takes as long as the physics dictates.

| Parameter | Range | What it controls |
|---|---|---|
| **stiffness / tension** | 50-1000 | Spring tightness. Higher = snappier. |
| **damping / friction** | 5-100 | Friction slowing the spring. Higher = less bounce. |
| **mass** | 0.1-5 | How heavy it feels. Higher = slower start/stop. |

### k-d studio spring presets

Damping is set to `2 × √(stiffness × mass)`, the critical value. Change stiffness to change speed; recompute damping to stay bounce-free.

| Name | Stiffness | Damping | Mass | Feel | Use |
|---|---|---|---|---|---|
| Default | 170 | 26 | 1 | Balanced | Most gesture releases |
| Snappy | 400 | 40 | 1 | Quick, firm settle | Small elements, toggles dragged into place |
| Gentle | 120 | 22 | 1 | Slow, soft | Editorial, photography, sheets |
| Stiff | 600 | 49 | 1 | Very fast | Dense data UIs, dashboards |
| Heavy | 200 | 49 | 3 | Slow, weighty | Large panels and sheets |
| Micro | 500 | 40 | 0.5 | Almost instant | Small drag handles |

### Damping ratio

- **Underdamped (ratio < 1):** Oscillates before settling. The "bounce."
- **Critically damped (ratio = 1):** Settles as fast as possible without oscillating.
- **Overdamped (ratio > 1):** Slower than critical, no oscillation.

k-d studio motion is critically damped (ratio = 1). Underdamped springs bounce, and bounce reads as a toy. If a brand explicitly asks for playfulness, that is a brand decision to record in its rationale, not a default to reach for.

---

## Tuning progressions

When the motion is close but not right, don't guess. Walk through these.

### Spring: too stiff → too soft

Start at the default. Move one step in the direction that feels right. Every step is critically damped, so only the speed changes, never the bounce.

| Step | Stiffness | Damping | Feel |
|---|---|---|---|
| 1, Very stiff | 600 | 49 | Near instant |
| 2 | 400 | 40 | Very snappy, firm settle |
| 3 | 300 | 35 | Quick |
| 4, Default | 170 | 26 | Balanced |
| 5 | 120 | 22 | Soft, gentle settle |
| 6, Very soft | 80 | 18 | Slow, weighty |

### Spring: what happens below critical damping

Keep stiffness fixed; lower only the damping. This is what you get, and why k-d studio stays at the top row.

| Damping (at stiffness 400) | Behaviour |
|---|---|
| 40+ | No overshoot. Critically damped. |
| 30-35 | Barely perceptible overshoot. Natural. |
| 20-25 | Noticeable overshoot. Satisfying for toggles. |
| 12-18 | Visible bounce. Playful. |
| 8-10 | Heavy bounce. Use only when brand is playful. |

### Cubic bezier: too sharp → too soft (for ease-out curves)

| Step | Value | Feel |
|---|---|---|
| 1, Very sharp | `(0, 0, 0, 1)` | Slams to a stop. Dramatic. |
| 2 | `(0.1, 0, 0, 1)` | Strong deceleration |
| 3, Default M3 | `(0.2, 0, 0, 1)` | Standard snappy feel |
| 4 | `(0.25, 0.1, 0.25, 1)` | CSS `ease`. Softer. |
| 5 | `(0.4, 0, 0.2, 1)` | Gentle |
| 6, Very soft | `(0.4, 0, 0.6, 1)` | Nearly linear |

### Duration: fine-tuning in 50ms steps

| Starting at | Try shorter | Try longer | For context |
|---|---|---|---|
| 150ms | 100ms | 200ms | Buttons, toggles, micro-interactions |
| 250ms | 200ms | 300ms | Panels, menus, cards |
| 350ms | 300ms | 400ms | Modals, page transitions |

The difference between 200ms and 250ms is subtle but perceptible. Between 200ms and 300ms it's obvious.

---

## CSS `linear()` for native springs

The `linear()` CSS timing function accepts multiple data points, enabling spring-like curves without JavaScript.

```css
/* Critically damped: x(t) = 1 − (1 + ωt)·e^(−ωt), ω = 12, sampled every 5% over 600ms. No value passes 1. */
.spring-transition {
  transition: transform 600ms linear(
    0.000, 0.051, 0.163, 0.294, 0.422, 0.537, 0.636, 0.717, 0.782, 0.834, 0.874, 0.905, 0.929, 0.947, 0.961, 0.971, 0.979, 0.984, 0.989, 0.992, 1
  );
}
```

To make your own, use Spring Easing Generator or Josh Comeau's spring visualiser with the damping ratio set to 1. Check that no value in the list exceeds 1. Do not hand-author.

**Browser support:** ~88% global support. For the remaining ~12%, the CSS falls back to linear, which is acceptable for most transitions.

---

## Platform token mappings

Bridge k-d studio tokens to platform systems when working within M3/Carbon/Apple design language.

### k-d studio → Material Design 3

| k-d studio | Material 3 duration | Material 3 easing |
|---|---|---|
| `--duration-instant` (100ms) | `duration.short2` | `easing.standard` |
| `--duration-micro` (150ms) | `duration.short3` | `easing.standard` |
| `--duration-fast` (200ms) | `duration.short4` | `easing.standard-decelerate` |
| `--duration-standard` (300ms) | `duration.medium2` | `easing.standard` |
| `--duration-emphasis` (400ms) | `duration.medium4` | `easing.emphasized-decelerate` |
| `--duration-dramatic` (600ms) | `duration.long2` | `easing.emphasized` |

### k-d studio → IBM Carbon

Carbon has 2 motion modes: Productive (efficient, subtle) and Expressive (enthusiastic, bold).

| k-d studio | Carbon Productive | Carbon Expressive |
|---|---|---|
| `--duration-instant` (100ms) | `fast-01` (70ms) |, |
| `--duration-micro` (150ms) | `fast-02` (110ms) | `fast-01` (150ms) |
| `--duration-fast` (200ms) | `moderate-01` (150ms) | `fast-02` (240ms) |
| `--duration-standard` (300ms) | `moderate-02` (240ms) | `moderate-01` (400ms) |
| `--duration-emphasis` (400ms) | `slow-01` (400ms) | `moderate-01` (400ms) |
| `--duration-dramatic` (600ms) |, | `moderate-02` (700ms) |

### k-d studio → Apple Human Interface (iOS)

SwiftUI doesn't expose named tokens. Use the standard animation presets and map mentally:

| k-d studio | SwiftUI | Notes |
|---|---|---|
| `--duration-instant` (100ms) | `.linear(duration: 0.1)` | Button feedback |
| `--duration-micro` (150ms) | `.easeOut(duration: 0.15)` | Toggle, icon |
| `--duration-fast` (200ms) | `.easeOut(duration: 0.2)` | Sheet presentation |
| `--duration-standard` (300ms) | `.default` (~0.35s spring) | Navigation push/pop |
| `--duration-emphasis` (400ms) | `.spring(response: 0.4)` | Hero reveals |
| Spring default (170, 26) | `.spring(response: 0.5, dampingFraction: 0.8)` | Balanced |

iOS conventions (navigation, modals, tab switches) use the system animation. Don't override these, respect platform muscle memory.

---

## When to use what

| Situation | Easing | Why |
|---|---|---|
| Element appears on screen | `--ease-out` or spring (critically damped) | Arrives with energy, settles |
| Element leaves screen | `--ease-in` | Accelerates away, clears space |
| Element moves between positions | `--ease-in-out` | Smooth pickup and landing |
| Colour or opacity change | `linear` | Constant rate feels natural for non-spatial changes |
| Playful interaction (toggle, like) | Spring with mild bounce | Physics feel makes it satisfying |
| Trust-critical context | `--ease-out` no overshoot | Controlled motion builds trust |
| Long scrolling narrative | Scroll-linked linear | Progress matches scroll input directly |
| Loading progress bar | `linear` | Progress should feel honest, not deceptive |
| iOS-native transitions | SwiftUI default `.spring` | Matches platform expectations |
