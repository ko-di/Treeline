<!-- Proprietary — k-d studio. Not for redistribution. -->

# k-d studio — Design References

These are the studios, galleries, and resources that define the aesthetic territory k-d studio operates in. When making design decisions, the work should feel at home among these references — not imitate them, but belong to the same conversation.

## Studios & Portfolios
- **Pentagram** (pentagram.com) — the benchmark for systematic, rigorous identity work
- **Collins** (wearecollins.com) — bold conceptual brand thinking, unafraid of strong moves
- **JP Works** (jp.works) — Japanese-influenced minimalism, extreme restraint
- **Ben Mingo** (benmingo.com) — clean editorial portfolio, photography-forward
- **EBGE** (ebge.gr) — Greek design studio, European sensibility
- **Beetroot** (beetroot.gr) — Greek studio, warm modernism

## Curated Galleries
- **Site Inspire** (siteinspire.com) — curated minimal web design
- **Awwwards** (awwwards.com) — technical and creative excellence
- **Godly** (godly.website) — modern, curated web design
- **The Brand Identity** (the-brandidentity.com) — brand and identity focus

## Digital Assets
- **Studio Size** (size-assets.com) — Curated digital assets

## Systems & Resources
- **Branding Style Guides** (brandingstyleguides.com) — how systems are documented
- **Logo System** (logosystem.co) — identity systems and mark-making

## What These References Share

The common thread across these references:
- **Editorial restraint** — content leads, chrome disappears
- **Typography as the primary medium** — type does the heavy lifting, not decoration
- **Photography given room** — images are not cropped into cards; they breathe
- **European sensibility** — confident quietness over American maximalism
- **Systematic thinking** — every decision is part of a larger order
- **Craft over trend** — timeless over fashionable

When in doubt about a design direction, ask: would this feel at home on these sites? If it feels like a template, a SaaS landing page, or a Bootstrap derivative — it has drifted from the territory.
