<!-- Proprietary — k-d studio. Not for redistribution. -->

# k-d studio — tech stack and conventions

k-d studio projects follow these conventions unless a project's own CLAUDE.md overrides them.

## Web stack
- **Framework**: Next.js (App Router)
- **CMS**: Sanity
- **Styling**: Tailwind CSS + CSS custom properties (design tokens)
- **Animation**: Framer Motion, GSAP, Rive, Theatre.js (see `MOTION.md` for when to use which)
- **Deployment**: Vercel
- **Package manager**: npm

## Mobile stack (React Native)
- **Framework**: Expo (managed workflow)
- **Language**: TypeScript
- **Navigation**: Expo Router
- **Animation**: React Native Reanimated (see `MOTION.md`)
- **Styling**: NativeWind (Tailwind for RN) or StyleSheet
- **Testing**: Detox (E2E), Jest (unit)
- **Deployment**: EAS Build → TestFlight (iOS) / Play Console (Android)

## iOS Stack (Native)
- **Language**: Swift
- **Framework**: SwiftUI
- **Animation**: SwiftUI animations, Core Animation (see `MOTION.md`)
- **Testing**: XCTest, XCUITest
- **Deployment**: Xcode → TestFlight → App Store

## Desktop stack
- **Electron** — mature, largest ecosystem, familiar web stack. Default when you need deep OS integration or the largest plugin library.
- **Tauri** — Rust-based, much smaller bundles (~3MB vs 50MB+), lower memory, faster startup. Default when bundle size and performance matter.
- **Testing**: Playwright (for renderer), Jest/Vitest (for main process)
- **Distribution**: electron-builder (Electron), Tauri bundler (Tauri), code signing + auto-update

## Code principles

### For a designer who codes
- Keep code simple and readable. Clever abstractions make future changes harder
- Prefer flat file structures over deep nesting
- Name things by what they are, not what they do technically
- Comments should explain why, not what

### Performance
- Native browser scroll (no scroll-hijacking libraries)
- Images served from CDN (Sanity image pipeline)
- No backdrop-blur on scroll-dependent elements
- Animations on transform/opacity only (compositor thread), see `MOTION.md` for full performance rules
- Prefers `will-change` sparingly and only when measured
- Respect `prefers-reduced-motion`, see `MOTION.md`

### Design tokens
- Colours, typography, and spacing defined as CSS custom properties
- Injected from CMS (Sanity Design Tokens) where possible
- No hardcoded colour values in components, always reference tokens

## Testing

- **Tool**: Playwright (TypeScript)
- **Skill**: `playwright-skill`, runtime at `~/.claude/skills/playwright-skill/`, organised reference at `forest/skills/reference/playwright-skill/`

Claude has access to 50+ Playwright guides. When writing tests, always pull from this skill, do not guess patterns.

| Scenario | Pack to reference |
|---|---|
| Visual regression (layout, design tokens) | `core/visual-regression.md` |
| E2E user flows, auth, navigation | `core/authentication.md`, `core/test-organization.md` |
| Accessibility | `core/accessibility.md` |
| API testing | `core/api-testing.md` |
| Next.js specific patterns | `core/nextjs.md` |
| CI/CD (Vercel, GitHub Actions) | `ci/ci-github-actions.md` |
| Debugging flaky tests | `core/flaky-tests.md`, `core/debugging.md` |

**Always**: `getByRole()` over CSS selectors. Never `waitForTimeout()`. Isolate every test. `baseURL` in config.

## Git — what belongs in the repo

Only commit source code and essential config. Before every commit, verify nothing outside this list is staged.

**Commit:**
- Source code — `app/`, `components/`, `lib/`, `sanity/`
- Config — `next.config.mjs`, `package.json`, `package-lock.json`, `tsconfig.json`, `postcss.config.mjs`, `sanity.config.ts`, `sanity.cli.ts`
- Public assets that are actual site assets (icons, favicons)
- `.gitignore`

## Patterns

### Hydration-Safe localStorage

Never read localStorage in `useState` initializers. SSR returns different values than the client, causing hydration mismatch. Always:
1. Initialize state with server-safe defaults (null, "operator", false)
2. Restore from localStorage in a `useEffect` after mount
3. Use a `mounted` flag to gate data fetching until restoration completes

### Profile-based architecture

When different users need different views of the same system, use data-driven profiles (JSON definition + TS accessor):
- Each profile defines: visible sections, available tools, default voice, agent personality
- Store active profile in localStorage (client) + config file (server)
- Filter UI at the component level via props, not conditionally rendered routes
- Readiness rules per profile for soft workflow gating (visual dimming + agent steering, never hard locks)

**Never commit:**
- Build output — `.next/`, `dist/`, `out/`
- Generated files — `next-env.d.ts`, `tsconfig.tsbuildinfo`, `.sanity/`
- Dependencies — `node_modules/`
- Private assets — `fonts-private/`, licensed typefaces
- Environment files — `.env`, `.env*.local`
- Local tooling — `.mcp.json`, `.claude/`, `CLAUDE.md`
- Scaffold leftovers — `public/placeholder*`
- Deployment artefacts — `.vercel/`
