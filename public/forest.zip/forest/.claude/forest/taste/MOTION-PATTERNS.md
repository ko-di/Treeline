<!-- Proprietary — k-d studio. Not for redistribution. -->

# k-d studio — Motion Patterns

Implementation recipes per library. Paired with `MOTION.md` (principles) and `MOTION-REFERENCE.md` (tuning tables).

Read this when you're writing new motion code. Choose the library based on the decision flow in MOTION.md, then look up the recipe here.

---

## Table of Contents

1. [CSS Transitions](#css-transitions)
2. [CSS Keyframes](#css-keyframes)
3. [3D Transforms](#3d-transforms)
4. [CSS Scroll-Driven Animations](#css-scroll-driven-animations)
5. [Framer Motion](#framer-motion)
6. [GSAP](#gsap)
7. [React Native Reanimated](#react-native-reanimated)
8. [SwiftUI Animations](#swiftui-animations)
9. [Rive](#rive)
10. [View Transitions API](#view-transitions-api)
11. [Intersection Observer + CSS](#intersection-observer--css)

---

## CSS Transitions

Use for simple state changes (hover, focus, active, class toggles). Zero JS overhead.

### Button with hover and press

```css
/* Transform only. Animating box-shadow repaints every frame, and a lift reads
   clearly without it. */
.button {
  transform: translateY(0);
  transition: transform var(--duration-micro) var(--ease-out);
}

.button:hover {
  transform: translateY(-1px);
}

.button:active {
  transform: translateY(0) scale(0.97);
  transition-duration: var(--duration-instant);
}
```

### Accordion with smooth height (no JS)

```css
.accordion-content {
  display: grid;
  grid-template-rows: 0fr;
  transition: grid-template-rows var(--duration-standard) var(--ease-out);
}

.accordion-content > div {
  overflow: hidden;
}

.accordion--open .accordion-content {
  grid-template-rows: 1fr;
}
```

Avoid animating `height` directly. `grid-template-rows: 0fr → 1fr` handles dynamic content height smoothly.

---

## CSS Keyframes

Use for looping animations and multi-step sequences.

### Skeleton shimmer

```css
.skeleton {
  /* --surface-raised and --surface-highlight come from the project's design tokens */
  background: linear-gradient(90deg, var(--surface-raised) 25%, var(--surface-highlight) 50%, var(--surface-raised) 75%);
  background-size: 200% 100%;
  animation: shimmer 1.5s linear infinite;
  border-radius: 4px;
}

@keyframes shimmer {
  0% { background-position: 200% 0; }
  100% { background-position: -200% 0; }
}

@media (prefers-reduced-motion: reduce) {
  .skeleton { animation: none; background: var(--surface-raised); }
}
```

### Error shake

```css
.field--error { animation: shake var(--duration-emphasis) var(--ease-in-out); }

@keyframes shake {
  0%, 100% { transform: translateX(0); }
  20% { transform: translateX(-4px); }
  40% { transform: translateX(4px); }
  60% { transform: translateX(-4px); }
  80% { transform: translateX(2px); }
}
```

### SVG checkmark draw-on

```css
.checkmark-path {
  stroke-dasharray: 24;
  stroke-dashoffset: 24;
  animation: draw 400ms var(--ease-out) forwards;
}

@keyframes draw { to { stroke-dashoffset: 0; } }
```

---

## 3D Transforms

3D transforms are GPU-accelerated. Perspective is set on the **parent**, not the element.

### Card flip

```css
.card-flip { perspective: 1000px; }

.card-flip-inner {
  position: relative;
  transition:
    transform 500ms var(--ease-expressive),
    box-shadow 500ms var(--ease-expressive);
  transform-style: preserve-3d;
}

.card-flip--flipped .card-flip-inner {
  transform: rotateY(180deg);
  box-shadow: 0 12px 32px rgba(0, 0, 0, 0.15);
}

.card-flip-front,
.card-flip-back {
  position: absolute;
  inset: 0;
  backface-visibility: hidden;
}

.card-flip-back { transform: rotateY(180deg); }
```

The shadow lift during flip makes the 3D motion feel real. Without it, the rotation feels flat.

### 3D tilt on hover

```js
function tiltCard(card, maxTilt = 8) {
  card.addEventListener("mousemove", (e) => {
    const rect = card.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;
    card.style.transform = `
      perspective(800px)
      rotateY(${x * maxTilt}deg)
      rotateX(${-y * maxTilt}deg)
    `;
  });

  card.addEventListener("mouseleave", () => {
    card.style.transition = "transform 400ms var(--ease-out)";
    card.style.transform = "perspective(800px) rotateY(0deg) rotateX(0deg)";
    setTimeout(() => (card.style.transition = ""), 400);
  });
}
```

### 3D reduced-motion fallback

```css
@media (prefers-reduced-motion: reduce) {
  .card-flip-inner { transition: opacity 200ms; transform: none !important; }
  .card-flip--flipped .card-flip-front { opacity: 0; }
  .card-flip--flipped .card-flip-back { opacity: 1; transform: none; }
}
```

3D is more likely to trigger vestibular discomfort than 2D. Always provide a crossfade fallback.

---

## CSS Scroll-Driven Animations

Native API for tying animation progress to scroll. No JS scroll listeners.

### Fade-in on scroll

```css
.reveal {
  opacity: 0;
  transform: translateY(20px);
  animation: fade-up 1s var(--ease-out) forwards;
  animation-timeline: view();
  animation-range: entry 0% entry 30%;
}

@keyframes fade-up {
  to { opacity: 1; transform: translateY(0); }
}
```

### Scroll progress bar

```css
.progress-bar {
  transform-origin: left;
  transform: scaleX(0);
  animation: grow linear forwards;
  animation-timeline: scroll();
}

@keyframes grow { to { transform: scaleX(1); } }
```

**Browser support:** ~85%. Provide a fallback using Intersection Observer.

---

## Framer Motion

Declarative React animation. Springs, layout animations, gestures.

### Entrance animation

```jsx
import { motion } from "motion/react";

<motion.div
  initial={{ opacity: 0, y: 20 }}
  animate={{ opacity: 1, y: 0 }}
  transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
/>
```

### Hover and press

State changes are transitions, so they use the easing tokens, not springs.

```jsx
<motion.div
  whileHover={{ scale: 1.02 }}
  whileTap={{ scale: 0.97 }}
  transition={{ duration: 0.15, ease: [0.22, 1, 0.36, 1] }}
/>
```

### Gesture spring — drag release

The one place a spring belongs: the element is answering the hand, and settles where it's let go. Critically damped, so it never overshoots.

```jsx
<motion.div
  drag="x"
  dragConstraints={{ left: 0, right: 0 }}
  dragElastic={0.2}
  dragTransition={{ bounceStiffness: 400, bounceDamping: 40 }}
/>
```

See `MOTION-REFERENCE.md` for the spring presets.

### Staggered list

```jsx
const container = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.04, delayChildren: 0.1 },
  },
};

const item = {
  hidden: { opacity: 0, y: 16 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.2 } },
};

<motion.ul variants={container} initial="hidden" animate="visible">
  {items.map((i) => (
    <motion.li key={i.id} variants={item}>{i.content}</motion.li>
  ))}
</motion.ul>
```

### Shared element transition (`layoutId`)

```jsx
// List view
<motion.div layoutId={`card-${id}`} transition={{ duration: 0.3 }}>
  <img src={image} />
</motion.div>

// Detail view — same layoutId, different position
<motion.div layoutId={`card-${id}`} transition={{ duration: 0.3 }}>
  <img src={image} />
</motion.div>
```

Framer Motion automatically morphs between the two.

### Sliding active indicator (pill)

```jsx
function Tabs({ tabs, activeTab, onSelect }) {
  return (
    <div className="tabs">
      {tabs.map((tab) => (
        <button key={tab.id} onClick={() => onSelect(tab.id)} className="tab">
          {tab.id === activeTab && (
            <motion.div
              layoutId="active-pill"
              className="active-indicator"
              transition={{ duration: 0.25, ease: [0.22, 1, 0.36, 1] }}
            />
          )}
          <span className="tab-label">{tab.label}</span>
        </button>
      ))}
    </div>
  );
}
```

### AnimatePresence (exits)

```jsx
import { AnimatePresence, motion } from "motion/react";

<AnimatePresence>
  {isOpen && (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.2 }}
    />
  )}
</AnimatePresence>
```

### Reduced motion

```jsx
import { useReducedMotion } from "motion/react";

const shouldReduce = useReducedMotion();

<motion.div
  initial={shouldReduce ? false : { opacity: 0, y: 20 }}
  animate={{ opacity: 1, y: 0 }}
  transition={shouldReduce ? { duration: 0 } : { duration: 0.25 }}
/>
```

---

## GSAP

Industry standard for complex timelines. Framework-agnostic.

### Basic tween

```js
import gsap from "gsap";

gsap.to(".card", { y: 0, opacity: 1, duration: 0.3, ease: "power2.out" });
```

### Timeline with overlap

```js
const tl = gsap.timeline();

tl.to(".backdrop", { opacity: 1, duration: 0.2 })
  .to(".modal", { scale: 1, opacity: 1, duration: 0.25, ease: "power2.out" }, "-=0.1")
  .to(".modal-content", { y: 0, opacity: 1, duration: 0.2 }, "-=0.05");
```

The third arg (`"-=0.1"`) is the position parameter — start this tween 0.1s before the previous ends. Creates the overlap that makes sequences feel fluid.

### ScrollTrigger

```js
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

gsap.from(".section-title", {
  y: 30,
  opacity: 0,
  duration: 0.5,
  ease: "power2.out",
  scrollTrigger: { trigger: ".section-title", start: "top 80%", once: true },
});
```

**Important:** clean up ScrollTriggers on component unmount (React).

### GSAP easing → k-d studio token mapping

| GSAP ease | Maps to k-d studio token |
|---|---|
| `power2.out` | `--ease-out` |
| `power3.out` | `--ease-productive` |
| `power4.out` | `--ease-expressive` |
| `expo.out` | `--ease-dramatic` |
| `back.out(1.4)` | Overshoot — only where the brand explicitly asks for it, recorded in its rationale |

---

## React Native Reanimated

Runs on the UI thread (not JS thread). The only performant animation option for React Native.

### Fade in with timing

```tsx
import Animated, { useSharedValue, useAnimatedStyle, withTiming, Easing } from "react-native-reanimated";
import { useEffect } from "react";

function FadeIn({ children }) {
  const opacity = useSharedValue(0);
  const style = useAnimatedStyle(() => ({
    opacity: withTiming(opacity.value, {
      duration: 300,
      easing: Easing.out(Easing.cubic),
    }),
  }));

  useEffect(() => { opacity.value = 1; }, []);

  return <Animated.View style={style}>{children}</Animated.View>;
}
```

### Press feedback

A state change, so it's timed, not sprung.

```tsx
const scale = useSharedValue(1);

const style = useAnimatedStyle(() => ({
  transform: [{ scale: withTiming(scale.value, { duration: 150, easing: Easing.bezier(0.22, 1, 0.36, 1) }) }],
}));

// Trigger:
scale.value = 0.97;
```

### Gesture spring — release only

After a pan or swipe ends, the element settles with a critically damped spring (damping = 2 × √stiffness), so it never overshoots.

```tsx
// withSpring from "react-native-reanimated"; Gesture from "react-native-gesture-handler"
const x = useSharedValue(0);

const pan = Gesture.Pan()
  .onUpdate((e) => { x.value = e.translationX; })
  .onEnd(() => { x.value = withSpring(0, { stiffness: 300, damping: 35 }); });
```

### Shared element-style transition (with Expo Router)

```tsx
// Expo Router handles shared transitions via `sharedTransitionTag` on compatible components
<Animated.View sharedTransitionTag={`card-${id}`}>
  <Image source={{ uri: image }} />
</Animated.View>
```

### Reduced motion (iOS)

```tsx
import { AccessibilityInfo } from "react-native";
import { useEffect, useState } from "react";

function useReduceMotion() {
  const [reduce, setReduce] = useState(false);
  useEffect(() => {
    AccessibilityInfo.isReduceMotionEnabled().then(setReduce);
  }, []);
  return reduce;
}
```

---

## SwiftUI Animations

### Basic animation

```swift
@State private var isVisible = false

var body: some View {
    VStack {
        // ...
    }
    .opacity(isVisible ? 1 : 0)
    .offset(y: isVisible ? 0 : 20)
    .animation(.easeOut(duration: 0.3), value: isVisible)
    .onAppear { isVisible = true }
}
```

### Transition

```swift
withAnimation(.easeOut(duration: 0.25)) {
    isExpanded.toggle()
}
```

### Gesture spring — release only

`dampingFraction: 1` is critically damped: it settles without overshoot. Use it when a drag ends, not for state changes.

```swift
.onEnded { _ in
    withAnimation(.spring(response: 0.4, dampingFraction: 1)) {
        offset = .zero
    }
}
```

### Shared element (`matchedGeometryEffect`)

```swift
struct CardView: View {
    @Namespace private var namespace
    @State private var selectedID: UUID?

    var body: some View {
        if let id = selectedID {
            DetailView(id: id)
                .matchedGeometryEffect(id: id, in: namespace)
        } else {
            ForEach(items) { item in
                Card(item: item)
                    .matchedGeometryEffect(id: item.id, in: namespace)
                    .onTapGesture {
                        withAnimation(.easeOut(duration: 0.25)) { selectedID = item.id }
                    }
            }
        }
    }
}
```

### Respect reduce motion

```swift
@Environment(\.accessibilityReduceMotion) var reduceMotion

withAnimation(reduceMotion ? .none : .easeOut(duration: 0.25)) {
    isExpanded.toggle()
}
```

---

## Rive

Interactive, state-machine-driven animations. Smaller than Lottie. Built-in logic.

```jsx
import { useRive } from "@rive-app/react-canvas";

function InteractiveIcon() {
  const { RiveComponent } = useRive({
    src: "/icon.riv",
    stateMachines: "main",
    autoplay: true,
  });

  return <RiveComponent style={{ width: 48, height: 48 }} />;
}
```

Use Rive for:
- Animated icons that change state (loading → success → error)
- Interactive illustrations
- Animated toggles with complex visual states

Preferred over Lottie when you need interactivity or smaller file size.

---

## View Transitions API

Native browser API for animating between page states.

### Same-document

```js
document.startViewTransition(() => {
  updateDOM();
});
```

### Customise

```css
::view-transition-old(root) {
  animation: fade-out 200ms var(--ease-in);
}

::view-transition-new(root) {
  animation: fade-in 300ms var(--ease-out);
}
```

### Named transitions (shared element across pages)

```css
.card-image {
  view-transition-name: hero-image;
}
```

When elements on different pages share the name, the browser morphs between them.

**Browser support:** ~80%. Use as progressive enhancement.

---

## Intersection Observer + CSS

Lightest-weight scroll-reveal. No library needed.

```js
const observer = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
        observer.unobserve(entry.target);
      }
    });
  },
  { threshold: 0.2 }
);

document.querySelectorAll(".reveal").forEach((el) => observer.observe(el));
```

```css
.reveal {
  opacity: 0;
  transform: translateY(20px);
  transition:
    opacity var(--duration-emphasis) var(--ease-out),
    transform var(--duration-emphasis) var(--ease-out);
}

.reveal.visible {
  opacity: 1;
  transform: translateY(0);
}

@media (prefers-reduced-motion: reduce) {
  .reveal { opacity: 1; transform: none; transition: none; }
}
```
