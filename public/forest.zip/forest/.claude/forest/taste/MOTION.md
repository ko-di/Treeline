<!-- Proprietary — k-d studio. Not for redistribution. -->

# k-d studio — motion system

Motion is not decoration. Every animation must answer: what is this communicating that stillness cannot?

## Principles

**Precise, not playful.** No bounces, no wobble. Transitions use the easing tokens, never springs. The one exception is a physical gesture, a drag, a swipe release, where a spring that settles without overshoot is allowed. Movement resolves cleanly and quickly. The interface is a tool, it should feel like a well-made instrument, not a toy.

**Motion follows attention.** Animation guides the eye from where it was to where it needs to be. If the viewer's gaze is already in the right place, no animation is needed.

**One motion language per project.** Choose a consistent vocabulary, how things enter, exit, and transition, and apply it everywhere. Mixed motion languages feel unfinished.

**Less is more, always.** The best animation is the one the user never consciously notices. It should feel inevitable, not performative.


## Library hierarchy

Use the simplest tool that achieves the effect. Do not reach for a library when CSS will do.

### CSS transitions and animations
**Use for:** hover states, focus states, colour changes, simple opacity/transform transitions, micro-interactions under 200ms.
**Why:** zero bundle cost, compositor-thread native, no JS dependency. Always the first choice.

```css
/* Standard micro-transition */
transition: opacity 150ms ease-out, transform 150ms ease-out;
```

### Framer Motion
**Use for:** React component animations, layout transitions, enter/exit with AnimatePresence, gesture-driven interactions, shared layout animations.
**Why:** declarative API that reads well in JSX, handles mount/unmount elegantly, layout animation is unmatched.

```tsx
/* Page enter */
<motion.div
  initial={{ opacity: 0, y: 12 }}
  animate={{ opacity: 1, y: 0 }}
  transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
/>
```

### GSAP
**Use for:** complex multi-step timelines, scroll-driven sequences (ScrollTrigger), path animations, text splitting and stagger, pinned sections, effects that span multiple elements in coordinated choreography.
**Why:** frame-perfect control, timeline scrubbing, scroll-linked progress. Use when Framer Motion's declarative model can't express the sequence.

```ts
/* Scroll-driven reveal */
gsap.from(el, {
  y: 40,
  opacity: 0,
  duration: 0.6,
  ease: "power2.out",
  scrollTrigger: { trigger: el, start: "top 85%" }
});
```

### Rive
**Use for:** interactive illustrations, animated icons, stateful vector animations (loading → success → error), brand moments, animated logos.
**Why:** runtime is tiny (~60KB), animations are designed in the Rive editor with state machines, performance is GPU-accelerated. Better than Lottie for interactive/stateful work.

### Theatre.js
**Use for:** cinematic sequences, camera-like choreography, scroll-driven storytelling with precise keyframe control, complex coordinated animations that need a visual timeline editor.
**Why:** visual editor for designing sequences, exports to code, frame-perfect scrubbing. Use for hero moments and narrative sections where timing precision matters more than code simplicity.

### React Native Reanimated
**Use for:** All animation in React Native apps. Shared values, gesture-driven interactions, layout animations, spring physics (springs are acceptable in mobile, they feel native).
**Why:** Runs on the UI thread (not JS thread), 60fps native performance, gesture handler integration.

```tsx
/* Fade-in with Reanimated */
const opacity = useSharedValue(0);
const style = useAnimatedStyle(() => ({
  opacity: withTiming(opacity.value, { duration: 300, easing: Easing.out(Easing.cubic) }),
}));
```

### SwiftUI Animations
**Use for:** All animation in native iOS apps. View transitions, matched geometry, implicit/explicit animations.
**Why:** Declarative, hardware-accelerated, integrates with SwiftUI's state management.

```swift
/* View transition */
withAnimation(.easeOut(duration: 0.3)) {
  isVisible = true
}

/* Matched geometry for shared element transitions */
.matchedGeometryEffect(id: "hero", in: namespace)
```

### Decision flow

```
WEB:
  Is it a hover/focus/colour change? → CSS
  Is it a React component entering/exiting/layout? → Framer Motion
  Is it a multi-element timeline or scroll-driven? → GSAP + ScrollTrigger
  Is it an interactive illustration? → Rive
  Is it cinematic choreography? → Theatre.js

REACT NATIVE:
  Any animation → Reanimated (it's the only performant option)
  Gesture-driven → Reanimated + Gesture Handler
  Lottie/vector animation → Rive or Lottie

IOS (SWIFT):
  Simple state transitions → SwiftUI withAnimation
  Shared element transitions → matchedGeometryEffect
  Complex sequences → Core Animation
  Lottie/vector animation → Rive or Lottie

Could 2 of these work? → Pick the simpler one.
```


## Duration scale

Consistent timing across every project. Named tokens, not hard-coded numbers.

| Token | Value | Use |
|-------|-------|-----|
| `--duration-instant` | 100ms | Hover states, button feedback, toggle switches |
| `--duration-micro` | 150ms | Micro-interactions, icon transitions, small reveals |
| `--duration-fast` | 200ms | Tooltips, dropdowns, small component transitions |
| `--duration-standard` | 300ms | Page element reveals, card transitions, modal enter |
| `--duration-emphasis` | 400ms | Section reveals, hero animations, meaningful transitions |
| `--duration-dramatic` | 600ms | Full page transitions, narrative sequences, scroll reveals |
| `--duration-slow` | 800ms+ | Cinematic moments only, use sparingly, justify every use |


## Easing tokens

Every easing curve has a name and a purpose. No bare cubic-bezier values in components.

| Token | Value | Use |
|-------|-------|-----|
| `--ease-out` | `cubic-bezier(0.22, 1, 0.36, 1)` | Default, elements arriving, appearing, settling. Fast start, gentle settle |
| `--ease-in` | `cubic-bezier(0.42, 0, 1, 1)` | Elements leaving, disappearing |
| `--ease-in-out` | `cubic-bezier(0.42, 0, 0.58, 1)` | Elements moving between positions |
| `--ease-productive` | `cubic-bezier(0.22, 0.61, 0.36, 1)` | Quick, purposeful, UI responses, navigation |
| `--ease-expressive` | `cubic-bezier(0.4, 0.14, 0.3, 1)` | Slower start, confident finish, reveals, heroes |
| `--ease-dramatic` | `cubic-bezier(0.16, 1, 0.3, 1)` | Strong deceleration, impactful entrances |

### In code

```css
/* CSS custom properties */
:root {
  --ease-out: cubic-bezier(0.22, 1, 0.36, 1);
  --ease-productive: cubic-bezier(0.22, 0.61, 0.36, 1);
  --ease-expressive: cubic-bezier(0.4, 0.14, 0.3, 1);
  --ease-dramatic: cubic-bezier(0.16, 1, 0.3, 1);
}
```

```tsx
/* Framer Motion — reusable objects */
const ease = {
  out: [0.22, 1, 0.36, 1],
  productive: [0.22, 0.61, 0.36, 1],
  expressive: [0.4, 0.14, 0.3, 1],
  dramatic: [0.16, 1, 0.3, 1],
};
```

```ts
/* GSAP equivalents */
const ease = {
  out: "power2.out",
  productive: "power3.out",
  expressive: "power4.out",
  dramatic: "expo.out",
};
```


## Transition patterns

Standard patterns for common UI moments. Use these as defaults, deviate only with reason.

### Page enter
Content fades up from a subtle offset. Stagger child elements if the page has distinct sections.
- Duration: `--duration-standard` to `--duration-emphasis`
- Easing: `--ease-expressive`
- Transform: `translateY(12px)` → `translateY(0)`

### Page exit
Opacity out, no transform. Fast. Don't make the user wait for the old page to leave.
- Duration: `--duration-fast`
- Easing: `--ease-in`

### List and grid stagger
Each item enters with a slight delay after the previous. Keep total stagger duration under 400ms, if 20 items each take 50ms delay, the last item waits a full second. Cap it.
- Per-item delay: 30–50ms
- Max total stagger: 400ms
- Easing: `--ease-out`

### Scroll reveal
Elements reveal as they enter the viewport. Trigger once. Do not replay on scroll back up.
- Trigger: element top crosses 85% of viewport
- Duration: `--duration-standard`
- Easing: `--ease-expressive`
- Transform: `translateY(20–40px)` → `translateY(0)` with opacity

### Modal / Overlay
Enter: scale from 0.97 to 1 with opacity. Exit: opacity only, fast.
- Enter: `--duration-standard`, `--ease-out`
- Exit: `--duration-fast`, `--ease-in`
- Backdrop: fade opacity independently

### Hover states
CSS only. No Framer Motion for hover unless it involves layout change.
- Duration: `--duration-instant` to `--duration-micro`
- Easing: `--ease-out`
- Transform: subtle scale (1.02) or translateY(-1px), never both

### Image reveal
Fade in from 0 opacity on load. Optional: reveal with a clip-path wipe for editorial feel.
- Duration: `--duration-standard`
- Easing: `--ease-out`

### Accordion / Expand
Height animation via Framer Motion layout or `grid-template-rows: 0fr → 1fr`. Never animate `height` directly.
- Duration: `--duration-fast` to `--duration-standard`
- Easing: `--ease-productive`


## Performance rules

Non-negotiable. Every animation must comply.

### Web
1. **Compositor thread only.** Animate `transform` and `opacity`. Never animate `width`, `height`, `top`, `left`, `margin`, `padding`, `border-width`, `font-size`, or `background-color` transitions on large surfaces.
2. **`will-change` is a last resort.** Only add it when you've measured jank without it. Remove it after the animation completes if possible.
3. **No `backdrop-blur` on scroll-dependent elements.** It forces main-thread compositing on every frame.
4. **No scroll-hijacking.** Native scroll, always. ScrollTrigger pins and progress are fine, overriding scroll velocity is not.
5. **Reduce motion.** Respect `prefers-reduced-motion`. Disable non-essential animation, keep functional transitions (layout changes, state indicators).
6. **Stagger responsibly.** Total stagger duration under 400ms. Users shouldn't wait for animation to finish before they can act.
7. **Lazy load animation libraries.** GSAP, Rive, and Theatre.js should be dynamically imported, never in the initial bundle for pages that don't use them.

### React Native
1. **UI thread only.** Use Reanimated's `useAnimatedStyle` and `withTiming`/`withSpring`. These run on the UI thread. Never animate with `setState` or `Animated` from React Native core (JS thread, will drop frames).
2. **`useNativeDriver: true`** if using the legacy Animated API (but prefer Reanimated).
3. **Avoid layout animations on long lists.** Use `LayoutAnimation` sparingly, it animates the entire tree.
4. **Springs are acceptable.** Unlike web, spring physics feel native on mobile. Reanimated's `withSpring` is appropriate for interactive gestures.
5. **Reduce motion.** Check `AccessibilityInfo.isReduceMotionEnabled` on iOS.

### iOS (Swift)
1. **SwiftUI handles performance.** `withAnimation` and view transitions are GPU-accelerated by default.
2. **Core Animation for complex sequences.** Drop to `CAAnimation` only when SwiftUI's declarative API can't express the sequence.
3. **Match platform conventions.** iOS users expect specific motion patterns (navigation push/pop, modal present/dismiss). Don't override them without reason.
4. **Reduce motion.** Respect `UIAccessibility.isReduceMotionEnabled`.


## Proactive suggestions

When building or reviewing components, suggest motion improvements when:

- A page or section has no enter transition, suggest page enter pattern
- A list renders without stagger, suggest stagger with capped duration
- A modal or overlay appears/disappears without transition, suggest modal pattern
- Content below the fold has no scroll reveal, suggest scroll reveal
- An interactive element has no hover state, suggest CSS micro-transition
- A state change (loading → loaded, open → closed) is abrupt, suggest appropriate transition
- A sequence of elements would benefit from choreography, suggest GSAP timeline or Theatre.js
- An icon or illustration could be interactive, suggest Rive

Always suggest the simplest appropriate library per the decision flow. Include the specific duration token and easing token in the suggestion.


## Motion by project type

k-d studio works across several project types. Each has a distinct motion personality. Match the motion to the work, not the trend.

| Project Type | Personality | Preferred easing | Duration range | Key principle |
|---|---|---|---|---|
| **Photography portfolio** | Quiet, cinematic, image-forward | `--ease-expressive` | 400-700ms | Let the work breathe. Slow, deliberate reveals. No bouncy interactions, the images are the subject. |
| **Brand identity site** | Deliberate, editorial, confident | `--ease-dramatic` | 300-600ms | Motion is a brand statement. Each transition should feel intentional. Text arrives with weight, images reveal with restraint. |
| **Editorial / content-heavy** | Scroll-led, narrative | `--ease-out` | 200-400ms + scroll-linked | Motion follows reading. Reveal on scroll once. Never re-trigger. Keep chrome static so content dominates. |
| **E-commerce (client)** | Snappy, efficient, trustworthy | `--ease-productive` | 100-200ms | Never block the path to checkout. Cart feedback is instant. Product imagery animates on interaction, not load. |
| **Restaurant / hospitality** | Warm, atmospheric | `--ease-expressive` | 300-500ms | Photography-forward, generous whitespace, subtle parallax. Motion evokes place, not performance. |
| **SaaS product (your own)** | Efficient, informative | `--ease-productive` | 150-250ms | Motion communicates state change. Skip stagger on data. Users are working, not watching. |
| **Motion-forward creative** | Expressive, bold, technical | `--ease-dramatic` or custom | 400-800ms | Motion IS the design. Pick 2-3 signature interactions and make them extraordinary. Everything else stays quiet so the signature moments land. |
| **Native iOS app** | Platform-native, matched to OS conventions | SwiftUI `.easeInOut` / default | 200-400ms | Respect iOS conventions (navigation push/pop, modal present/dismiss). Use `matchedGeometryEffect` for shared transitions. Don't invent custom patterns that confuse muscle memory. |

When a new project starts, check `.claude/brand-context.md` for brand personality. Map it to the closest project type above. If no brand context exists, ask the user what the motion should feel like before picking defaults.

---

## When motion feels wrong

When the user says "this feels off," translate the subjective feeling into a specific parameter fix. Do not guess, walk through this table.

| What they say | What's actually wrong | Fix |
|---|---|---|
| "It feels sluggish" | Duration too long | Reduce duration by 30-50%. Most common mistake is animations that are too slow. Try `--duration-fast` instead of `--duration-standard`. |
| "It feels janky" | Animating layout properties, or too many elements at once | Switch to `transform` + `opacity` only. Reduce simultaneous animations. Check DevTools Performance tab. |
| "It feels robotic" | Linear easing, or duration-based curves that feel stiff | Switch from `--ease-productive` to `--ease-expressive`, or lengthen the settle with `--ease-dramatic`. Don't reach for a spring: springs are for gestures, not transitions. |
| "It feels cheap" | Using default CSS `ease` or identical timing on everything | Use named easing tokens. Vary duration by element importance. Add subtle stagger to lists. |
| "It feels aggressive" | Easing is too sharp, overshoot too strong | Reduce spring stiffness, increase damping. Switch from `--ease-dramatic` to `--ease-out`. Soften the curve. |
| "It feels disconnected" | No spatial relationship between trigger and result | Animate from the point of interaction. Use `transform-origin`. Use shared element / `layoutId` transitions. Add directional continuity. |
| "It's distracting" | Animation draws attention but communicates nothing | Remove it, or reduce amplitude/distance. If it doesn't serve feedback, spatial, state, or attention purposes, it shouldn't move. |
| "It feels like too much" | Too many things animate, or choreography takes too long | Reduce stagger count. Group elements. Cut total sequence to under 500ms. Remove the least important animations first. |
| "It feels too bouncy" | Spring damping too low | Increase damping (fewer oscillations). For web: switch to `cubic-bezier` ease-out. For mobile: increase Reanimated spring damping from 10 → 20+. |
| "It's not arriving" | Duration too short, or transform distance too small | Increase duration 50%, or increase the `translateY`/`translateX` offset so the motion is visible. Animations under 100ms read as instant. |

---

## Extending this system

To add a new animation library:

1. Add a section under "Library Hierarchy" with: name, use cases, why, and a code example
2. Add it to the decision flow
3. Add any library-specific easing mappings to the easing tokens section
4. Add any new transition patterns it enables

To add a new project-type profile, add a row to the "Motion by project type" table above. Give it a personality, preferred easing, duration range and key principle.

For deeper implementation details (cubic-bezier cheat sheets, spring tuning progressions, platform tokens, code patterns per library), see:
- `MOTION-REFERENCE.md` (beside this file). Tuning progressions, native CSS springs, Material/Carbon tokens
- `MOTION-PATTERNS.md` (beside this file). Code recipes per library (Framer Motion layoutId, GSAP timelines, Reanimated shared values, SwiftUI matchedGeometryEffect, 3D transforms, View Transitions API, Intersection Observer)

## Project implementations

### Taste (SKStudio) — SaaS tool

Tokens defined in `app/taste/taste.css`:

| Token | Value | Use |
|---|---|---|
| `--taste-duration-instant` | 100ms | Hover feedback, button state |
| `--taste-duration-micro` | 150ms | Slide-in icons, modals, fades |
| `--taste-duration-fast` | 200ms | Dropdowns, drawer open/close |
| `--taste-duration-standard` | 300ms | Sidebar width, layout shifts |
| `--taste-ease-productive` | `(0.22, 0.61, 0.36, 1)` | All UI transitions (SaaS default) |
| `--taste-ease-out` | `(0.25, 0.1, 0.25, 1)` | Opacity fades, gentle arrivals |
| `--taste-ease-modal` | `(0.32, 0.72, 0, 1)` | Modal/drawer scale entrance |

Reduce-motion: blanket `@media (prefers-reduced-motion: reduce)` sets all animation-duration and transition-duration to 0.01ms. No per-element exceptions.

Pattern: all 31 transitions in the file reference tokens, zero bare `ease` or hard-coded durations.

Claude reads this file at the start of every session. Changes take effect on the next conversation.
