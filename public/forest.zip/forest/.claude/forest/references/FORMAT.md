# Format

How a reply is laid out. This is the contract. When a skill has something to put on screen, it takes the shape that matches the content, then writes as little as that shape needs.

[`TEXTURE.md`](./TEXTURE.md) governs the moments that earn weight. [`QUESTIONING.md`](./QUESTIONING.md) governs how a question is worded. This file governs the shape of everything else. They do not overlap.

## Why shape comes first

Someone 4 camps deep has read a lot of output. Shape is the only part of a reply they take in before reading it. A table means compare. A numbered list means do these in order. A set of options means choose. Prose means read.

When the shape matches the content, the reading is half done on arrival. When every reply is prose, none of it is.

## The shapes

| The content is | The shape |
|---|---|
| A decision with 2 to 4 answers | The `AskUserQuestion` tool |
| Things weighed on the same axes | A table, one row per thing |
| A sequence somebody follows | One numbered list, shown whole |
| Findings from a check | One graded table, then a stop |
| Anything else | Sentences |

The last row is the one most often got wrong. A shape is for content that has that shape. A table with one row, or options with one option, is decoration, and decoration costs the reader the same attention as substance.

---

## Decisions

A decision with 2 to 4 answers uses the `AskUserQuestion` tool, so the user picks rather than types. This is the render rule Branch mode already carries in `QUESTIONING.md`, and it covers Guided mode's 3 suggestions too.

**What goes where:**

| The contract says | The field |
|---|---|
| The question | `question` |
| The axis being decided, at most 12 characters | `header` |
| The option | `label`, 1 to 5 words |
| The one-line rationale for that option | `description` |
| A choice easier to see than to read | `preview` |

**"Pick, modify, or write your own" is never typed out.** The tool carries its own free-text answer. Writing the line as well tells the user something already in front of them.

**How many.** Guided offers 3, because 3 is a sample of a wider space and `QUESTIONING.md` fixes it there. Branch offers 2 to 4, because the branches are the whole space rather than a sample of it. A branch with 5 real answers is 2 questions.

**When the tool is absent,** fall back to letter-labelled options, as `QUESTIONING.md` sets out. The rationales stay. Losing the buttons is a loss of rendering, not a loss of content.

**Echo still applies.** The tool returns a choice. The skill still names what changes because of it.

## Comparisons

A comparison of 2 or more named things goes in a table. Things are rows, axes are columns. Never a paragraph per thing, and never a bullet list where each bullet measures something different.

The test: if the reader would have to hold one option in their head while reading the next, it is a table.

## Sequences

Anything somebody follows in order is one numbered list, shown whole, before the first step runs. Steps handed over one at a time read as an interrogation. Somebody who cannot see the end cannot judge whether to start.

This covers a camp's contents at its opening, a phase list, an install, a recovery and a handoff.

**Steps are not questions.** `QUESTIONING.md` asks for one question at a time, and that rule holds. A skill may show 10 steps and still ask one thing. The list says what is coming. The question is still asked alone, and answered, before the next one arrives.

## Findings

A check that produces findings returns one table, graded, then stops.

| Grade | What | Where | Fix |
|---|---|---|---|

Number every row, so the user can answer by number. Sort by grade, worst first. One line per finding: what it is, where it is, what would fix it. Then the stop, asking which to apply: all, some by number, or none.

One table, not one per grade. A reader comparing a P0 against a P2 should not have to scroll between 2 lists to do it.

## Hierarchy

These hold in every reply, whatever its shape.

- **Lead with the answer.** The reason comes second. Where the reply is a verdict, the verdict is the first line.
- **One idea per block,** with a blank line between blocks. A wall of text is a wall whether or not every sentence in it is short.
- **Bold is structural.** It opens a row or a bullet to name what follows. It never stresses a word inside a sentence. Move the word to the front instead.
- **No headings in a reply under about 6 lines.** A heading over 3 lines of text labels rather than organises.
- **Nothing nests.** Not lists, not tables. A second level is a sign the first level holds 2 different things.
- **Terse inside the shape.** A 2-line answer stays 2 lines. Structure is for content that has a shape, never a way of making a short answer look considered.

## Style modes

`QUESTIONING.md` sets 3 styles. Shape does not change with them. Density does.

| Style | What changes |
|---|---|
| Structured | Every option carries its rationale. Sequences say what each step is for |
| Balanced | Options carry rationales. Sequences are the steps alone |
| Terse | Options carry labels alone. Tables drop their closing line |

The shapes never weaken. A decision is options in every style, and a sequence is a whole numbered list in every style. Terse strips words, never structure. Structure is what makes a reply fast to read, and Terse is the setting for people who want it faster.

## Anti-patterns

- A table with one row, or a set of options with one option.
- Options offered for something the user cannot choose, such as a fact.
- A numbered list for things with no order. That is a set, so use bullets.
- Revealing a sequence one step at a time.
- Writing "Pick, modify, or write your own" beside a tool that already offers it.
- Bold for stress inside a sentence.
- A heading on a 3-line reply.
- Emoji anywhere. See `TEXTURE.md`.
- Any new box. Boxes belong to `TEXTURE.md` and its inventory. A table is not a box, and nothing in this file creates a framed moment.

## The contract, in one paragraph

Every reply takes the shape of its content. A decision is options. A comparison is a table. A sequence is one numbered list, shown whole. Findings are one graded table followed by a stop. Everything else is sentences. The shape holds across all 3 style modes, and only the density inside it changes. Bold names things and never stresses them. Nothing nests, and nothing gets a shape it does not have. Boxes stay where `TEXTURE.md` put them.
