# Bridges

Sometimes the trail needs work the kit can't do well: real conversations, Figma boards, domain provisioning. Then the skill steps out of the way and sends the user to the right tool. This file is the catalogue of those handoffs.

A bridge is not a failure. It's the kit recognising that some work belongs elsewhere, and orchestrating the round trip cleanly so the user doesn't get lost.

Read [`TEXTURE.md`](./TEXTURE.md) for the rendering format (handoff block + return pickup). This file specifies when to bridge and what to send the user to do.

## Why bridges exist

The kit runs inside Claude Code or Cursor. It's good at: structured conversations, file authoring, code generation, reading and analysing imagery via MCP, capturing decisions. It's bad at: scheduling a real human, drawing a wireframe, deploying to a custom domain, sending an email from your account.

Pretending to do the bad-at things produces slop. The right move is a bridge: a brief, numbered handoff that tells the user where to go, what to do, and what to bring back.

The 3 principles:

1. **Bridge to the simplest tool that fits.** If pen and paper works, send them to pen and paper. Not every bridge needs a SaaS subscription.
2. **Always close the loop.** Every bridge ends with the command the user types when they return. The kit waits on a specific signal, not a vague hope.
3. **Read what comes back.** When the user pastes a Figma link, the kit fetches via MCP. When they paste a transcript, the kit files it. The return is not just acknowledgment. It's the kit picking up the work.

---

## The bridge inventory

Where bridges fire on the trail. Skills check this list before deciding to ask another question. If the answer needs real-world work, bridge instead.

| Camp | Need | Bridge to | Bring back |
|---|---|---|---|
| 2, Learn | Real audience conversation | Calendly or direct outreach + an interview guide | Transcript or notes in `project/research/*.md` |
| 3, Decide | User flow / journey map | FigJam (or paper, or Whimsical) | Link to the board, or a screenshot |
| 4, Shape | Mood board / visual references | Figma board | Link to file (anyone-with-link, view) |
| 4, Shape | Wireframes or mockups | Figma | Link to file |
| 4, Shape | Logo or wordmark mark-making | Pen and paper, or Figma, or hire a designer | Final files in `project/design/brand/` |
| 5, Build | Domain provisioning | `/publish`, which owns the registrar bridge | Domain name confirmed in `project/compass.json` |
| 5, Build | Hosting and deploy | `/publish`, which owns the host bridge | Deploy URL pasted back |
| 5, Build | Email sending | Resend / Postmark / Mailgun | API key stored in `.env.local`, sender domain verified |
| 5, Build | Auth provider setup | Auth.js + Google/GitHub OAuth consoles | Client IDs and secrets in `.env.local` |
| 5, Build | Database (managed) | Turso / Neon / Supabase | Connection string in `.env.local` |
| 6, Ship | Domain DNS pointing | `/publish`, which owns the DNS bridge | DNS records confirmed propagated |
| 6, Ship | Analytics setup | Vercel Analytics or Plausible | Tracking ID in `project/compass.json` |
| 6, Ship | Social launch posts | Twitter / LinkedIn / your channels | Public links pasted back for the launch log |

The 4 infrastructure rows above name `/publish` rather than a provider. Getting somebody from no account to a live address runs to about 20 steps, and the anti-patterns below cap a bridge at 5. A need that big is a skill, and improvising it a stage at a time is what this file exists to stop.

When something breaks on the far side of a bridge, the route back is `/debug`, not a second bridge.

A skill that needs something not in this list should not invent a new bridge silently. It should ask the user how they want to handle it, and the answer gets added to this file later.

---

## Bridge details

### Camp 2 — Real interviews

Triggered by `/scout` when the audience is named but no real conversations have happened.

**Pre-departure:**

```
Real conversations are needed before Camp 2 closes, and 3 is the
minimum that makes Camp 3's PRD honest.

Bridge:

1. Pick 3 people who match the audience you named:
   "[audience phrase from project/compass.json]"
2. Contact them with a short DM or email. Keep it brief: who you are, what you're
   exploring, and a specific 30-minute ask. Don't pitch the product.
3. Schedule 30 minutes each. Use the interview guide at
   project/2-learn/interview-guide.md (drafted by /scout).
4. Take notes or record (with permission). Drop the file in
   project/research/ — name it with the date and a one-word person tag,
   for example, project/research/2026-04-30-emma.md.

Type /scout when you're back with at least one note.
```

**On return:** the kit reads the new files in `project/research/`, surfaces themes if more than one note exists, and offers to run `/gather` for synthesis.

**Why this bridge matters:** Camp 2 is the most-skipped camp on every solo project. Without real conversations, Camp 3's PRD is fan fiction. The bridge enforces the gate without blocking the user.

---

### Camp 3 — User flow

Triggered by `/camp decide` when the PRD calls for a user flow and none exists.

**Pre-departure:**

```
Before the PRD locks, sketch the primary flow.

Bridge:

1. Open FigJam, Whimsical, or paper, whatever you sketch fastest in.
2. Map: entry point → key decision → primary action → outcome.
3. Don't add edge cases yet. Only the happy path.
4. Share the file (anyone-with-link, view) or take a photo.

Drop the link or image in chat when you're back. Type /camp decide
to continue.
```

**On return:**
- If a Figma link: the kit fetches via the Figma MCP and analyses the flow.
- If a screenshot: the kit reads the image and extracts the steps.
- If pasted text: the kit reads it as-is.

In all 3 cases, the kit echoes a one-line read of the flow back to the user before continuing.

---

### Camp 4 — Mood board

Triggered by `/sketch` when called without imagery.

**Pre-departure:**

```
Before tokens, references are needed: a mood board you'd actually
want this product to live next to.

Bridge:

1. Open Figma. Start a new file or use any board.
2. Pull in 5–10 references that match the territory:
   - 3 studio or product sites you respect
   - 3 details (a component, a transition, a use of type)
   - 2 or 3 references from outside the web (print, packaging, signage)
3. Don't annotate. Just place them.
4. Share the file (anyone-with-link, view).

Paste the link back. /sketch will analyse via the Figma MCP.

Need direction? See the taste layer's INSPIRATIONS.md for categories to
pull from.
```

**On return:** the kit reads the file via the Figma MCP, extracts colours, typography, density, depth treatment, and proposes a token block. The user reviews, the kit writes `project/design/design.md`.

**The Figma MCP is wired in this environment.** When a user pastes a Figma URL, skills should reach for `mcp__claude_ai_Figma__get_design_context` (or similar) rather than asking the user to describe the imagery.

---

### Camp 4 — Wireframes

Triggered by `/camp shape` when the design.md exists but no flow-level mockups do.

**Pre-departure:**

```
Wireframes for the primary flow. Low fidelity, no styling yet.

Bridge:

1. Open the Figma file from your mood board (or start a new one).
2. Sketch the 3 or 4 most important screens. Boxes and
   labels, no real type, no real images.
3. Focus on hierarchy: what does the eye land on first on each
   screen?
4. Share the file (anyone-with-link, view).

Paste the link. We'll review screen by screen.
```

**On return:** the kit reads each frame via the Figma MCP, applies the principles in the taste layer, and surfaces friction or hierarchy issues.

---

### Camp 4 — Logo or wordmark

Triggered by `/sketch` or `/camp shape` when the project needs a mark and none exists.

**Pre-departure:**

```
The mark is the one thing in the kit that should not be generated.
A typed wordmark is fine. A drawn mark is better.

Bridge:

1. If a wordmark is enough: pick a typeface from the design.md and
   set the project name. Save as SVG.
2. If a drawn mark: sketch on paper or in Figma. 3 or 4
   directions, then pick one.
3. If you'd rather hire someone: do that. Don't generate.

Drop the SVG or PNG into project/design/brand/ when ready. Type
/camp shape to continue.
```

**Why this bridge has no return-via-paste:** marks should land in the file system, not via chat. Once the file is in `project/design/brand/`, the kit picks it up automatically.

---

### Camp 5 — Domain, hosting, email, auth, database

Triggered by `/camp build` when `project/compass.json` lists infrastructure needs that haven't been provisioned. One bridge per provider as needed.

**Pre-departure (example, Vercel):**

```
Hosting next.

Bridge:

1. Go to vercel.com → New Project.
2. Connect this repo.
3. Set environment variables from .env.local (don't paste secrets in
   chat. Vercel reads them from your local file via CLI: vercel env
   pull, or paste into Vercel's UI).
4. Deploy.

Paste the deploy URL back when it's live.
```

**On return:** the kit confirms the URL responds, files it in `project/compass.json` under `deployment`, and continues.

**Pattern for any provider:** name what to do in 3–5 numbered steps, name what to bring back (URL, API key, confirmation), let the user execute.

The kit never asks for secrets in chat. Always "add to `.env.local`", the kit reads files locally, doesn't accept pasted credentials.

---

### Camp 6 — DNS, analytics, social launch

These are smaller bridges and follow the same pattern. Pre-departure block, return pickup, one-line acknowledgment. The format is in [`TEXTURE.md`](./TEXTURE.md). The specific steps are project-dependent (registrar, analytics provider, channels) and `project/compass.json` should already record the choices.

---

## Return-recognition rules

When the user pastes something back after a bridge, skills should recognise what kind of return it is and act accordingly.

| User pastes | Kit recognises | Kit does |
|---|---|---|
| `https://figma.com/...` URL | Figma file | Fetches via Figma MCP, analyses, files context |
| `https://*.vercel.app` or custom domain | Deploy URL | Files in `project/compass.json.deployment`, runs `/summit` checks if Camp 6 |
| Markdown text starting with a date or interview heading | Transcript | Saves to `project/research/[date]-[slug].md` |
| A long block of pasted prose | Notes | Asks: "Where should this go, project/research/, project/[N]-/, or project/decisions/?"* |
| A screenshot or image | Visual reference | Reads the image, asks for context (which bridge it answers) |
| A short string with no URL or formatting | Probably an answer to a question | Treats as a normal answer, echoes |

When recognition is ambiguous, ask once. "Is this the FigJam flow link or the mood board file?", then file accordingly.

---

## When NOT to bridge

The kit should not bridge for:

- Decisions that fit inside the kit (those use `/rationale`).
- Brainstorming or ideation (that's `/scout` and `/sketch`'s domain).
- Synthesis of existing notes (that's `/gather`).
- Anything the kit can do well via MCP (Figma reads, Sanity queries, Gmail/Calendar where wired).
- Small clarifications that can be resolved by re-asking a question.

Bridging when the kit could do the work itself wastes the user's time and breaks the partner posture. A skill may be tempted to bridge for something not on the inventory list. The right move is usually to ask the user a sharper question instead.

---

## Anti-patterns

- Bridging without a return command. The user comes back, types nothing happens, the trail stalls.
- Bridges with more than 5 steps. If a bridge takes more than 5 steps, it's a project of its own. Break it into smaller bridges per camp.
- Asking for secrets in chat. Always `.env.local`.
- Sending the user to a paid tool when a free one fits. The kit is local-first; bridges should be too where possible.
- Multiple simultaneous bridges. One handoff at a time. Wait for the return before opening another.
- Re-bridging on return. The user came back; pick up the work. Don't immediately send them out again.

---

## The contract, in one paragraph

Sometimes the trail needs work the kit can't do: real conversations, Figma boards, infrastructure, real-world launch. Then the skill emits a bridge. It is a numbered pre-departure block in the format from [`TEXTURE.md`](./TEXTURE.md), naming the destination, the steps, and the command to type on return. The kit never asks for secrets, always closes the loop with a return command, and reads what comes back via MCP or file recognition. Bridges are not failures, they are the kit recognising the limits of its surface and orchestrating the round trip cleanly.
