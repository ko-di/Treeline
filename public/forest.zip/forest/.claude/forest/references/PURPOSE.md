# Purpose

Why this kit exists. Read once. Skills don't reference this file for behaviour — it sits at the top of the repo as the *why*. The mechanics elsewhere enforce it.

---

## What this kit is for

This kit exists to help one person — a maker working alone or alongside one or two others — turn an idea into something real. A product. A website. A brand. A business.

Not faster. Not slicker. **Better.** With more honesty about who it's for, more refusal to ship the wrong thing, more stubbornness about whether the work matters.

The kit is built for someone who already has skill and judgement, and wants a workflow that respects that — not a workflow that hides the work behind automation. The aim is to surround the user with what feels like a small studio of sharp workmates — a researcher, a design director, a strategist, an engineer — each showing up at the right moment, each refusing to nod. The judgement — what to build, who it's for, whether to ship at all — stays with the user. The studio's job is to keep the work honest and the trail clean.

## The position this kit takes

Design is being redefined. The two failure modes are obvious — refuse AI and lose ground; use AI without taste and lose the work itself. This kit is built for the third path: **scale design without losing craft.** Close the gap between an idea and a real product, without filling that gap with slop.

That's the durable claim. The timely one — that this is the specific moment in design history when this kit needs to exist — is also true, but it's the context, not the headline. The role of design is being rewritten. The kit is a bet on what gets written. Specifically: that one person with skill, taste, and the right workmates can carry an idea further than a team used to — and the work can still feel made, not generated.

A note on the studio metaphor. The kit runs on one model. The "small studio of workmates" is a constraint on voice and posture across skills, not a claim that separate AIs are at work. The personas are real because they're enforced — different skills wear different hats, ask different questions, refuse different things. But the surface is one tool, honestly named.

---

## What this kit is *not* for

The dominant frame in AI tooling right now is *velocity*: ship faster, generate more, do in an hour what used to take a week. That frame produces a specific output — products that exist because they could exist, not because they should.

This kit is a deliberate counter-frame. Not anti-AI — the kit *runs on* an AI agent — but **AI-skeptical** in the sense that matters: it applies friction where most AI tools apply acceleration. It refuses to fill in the gaps the user should fill in themselves. It surfaces whether the work has a real beneficiary before the work starts. It forces the user to name a real person whose day is measurably better because of what they're building.

If your goal is to ship as much as possible as fast as possible, this kit will frustrate you. The challenge layer will refuse thin work. The discovery bridge will send you out to talk to real people instead of synthesising fake user research. The "do not generate the mark" rule will reject the easiest path. By design.

---

## The thesis

The real opportunity for this generation of tools is not to help teams ship faster. It is to help teams **stay focused on the right problems** — improving people's lives, reducing burden, refusing to build the things that shouldn't exist.

A workflow that ships ten products a year, all of them generic, all of them solving for the maker's boredom rather than someone's burden, is not a workflow that has helped anyone. A workflow that ships one product a year that measurably reduces a real person's friction is.

This kit is structurally biased toward the second outcome.

---

## How this shows up in the mechanics

Read elsewhere for the details. Briefly:

- **The challenge layer** ([`CHALLENGE.md`](./CHALLENGE.md)) — nine structural challenges placed along the trail, refusing to let the user move on without engagement. The first fires before any work begins: *"Who's one real person this makes life easier for?"*
- **The discovery bridge** ([`BRIDGES.md`](./BRIDGES.md)) — Camp 2 cannot close until real conversations have happened. The kit will not synthesise fake user research to keep the trail moving.
- **The "do not generate the mark" rule** — logos and wordmarks are the one thing the kit refuses to produce. They land in the file system, made by hand or hired out. The mark is where craft and care live; AI-generated marks are slop signals.
- **The challenge against generic audiences** — "small businesses," "creators," "professionals" trigger immediate pushback. The audience is a specific person you can name, or it isn't real.
- **The summit reflection** — the trail does not end at "shipped." It ends at *"three months from now — whose life changed?"*

None of these mechanics announce themselves. They just refuse to move forward without engagement. That refusal is the kit's leverage.

---

## What this means for the user

Three things.

**The kit will frustrate you sometimes.** That's the design. When the kit pushes back on an audience description or refuses to generate a brand mark, the friction is the feature. The friction is what keeps the work from drifting toward the universal average.

**The kit will not produce slop.** Not because it can't, but because it has structurally refused to. If something feels off about an output, the answer is almost always one camp earlier in the trail — a thin answer that didn't get challenged hard enough. Go back. Do the camp again.

**The kit will not protect you from your own taste.** The mechanics are aligned, but taste is the user's. The kit will surface whether you're avoiding a question. It will not answer the question for you. The judgement — what to build, who to build it for, when to stop — is yours.

---

## Who this is for

Anyone turning an idea into something real, with the skills to do good work and the discipline to want a workflow that holds the line.

Solo founders. Designers who code. Small studios. Independents who hate Notion sprawl. People who'd rather have a partner that pushes back than a tool that nods.

If you want a tool that nods, there are many. This isn't one.

---

## The contract, in one paragraph

This kit exists to help skilled people turn ideas into real things — products, sites, brands, businesses — without losing sight of who the work is for. It is AI-skeptical: built on an AI agent but structurally biased against the generic, the unfocused, and the un-needed. It rewards engagement, refuses thin work, and treats the user as a serious professional. The thesis is simple: *the right problem solved well, for one real person whose day is measurably better*, is worth more than ten generic products shipped on schedule. The mechanics enforce that thesis. The user keeps the judgement.
