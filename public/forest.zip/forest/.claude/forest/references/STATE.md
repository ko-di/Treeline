# State — where the project is, and who gets to say so

Most skills read the project's position on the trail. 4 depend on it:
`/trail`, `/compass`, `/map` and `/camp`. Before this file existed they each worked it out for
themselves, and they disagreed, most often after `/camp` was used to work
out of order, which is exactly what `/camp` is for.

One rule, written once, read by all 4.

## The rule

**`**Current camp:**` in `project/map.md` is the position. Nothing else is.**

Checkboxes record work done. They do not record where you are. A ticked
box in Camp 4 means Camp 4 work happened; it does not mean the trail has
reached Camp 4. Those are different facts and the kit keeps them apart.

## Reading the position

1. Read `**Current camp:**` from `project/map.md`. Match it case-insensitively
   against `frame · learn · decide · shape · build · ship`, and against the
   pre-1.1.0 names `intake · discover · define · design`, which map onto the
   first 4. That is the
   answer, with one exception: if it reads `ship` and Camp 6's `Deployed`
   box is ticked, the position is `summit`. The rest of Camp 6's boxes —
   `/summit`, `/retro`, `/handoff`. Are summit work, ticked by those skills
   as they run, so waiting for them would keep the trail at Ship for good.
2. If the field is missing, empty, still the template placeholder, or names
   something not in that list, derive it: the lowest-numbered camp that
   is not fully ticked. Exactly one camp always satisfies this, so there is
   never a tie to break.
3. If every camp is fully ticked, or Camps 1–5 are and Camp 6's `Deployed`
   box is, the trail is walked. Position is `summit`, not a camp.
4. If `project/map.md` does not exist, the project has not been packed. Say so and
   name `/pack`. Do not derive anything.

Step 2 is a repair, not a second opinion. When the field is readable it wins,
even if the checkboxes suggest otherwise.

## Projects started before 1.1.0

Camps 1–4 were renamed in 1.1.0: Intake → Frame, Discover → Learn, Define → Decide, Design → Shape. The folders moved with them.

An update replaces `.claude/` and never touches `project/`, so a project started earlier still has the old folder names. That is not broken, and working it out is not the user's job.

**The check.** When `project/1-intake/` exists and `project/1-frame/` does not, this project predates the rename. Any skill that reads position, `/trail`, `/camp`, `/compass`, `/map`, offers once per session:

> "This project uses the old camp folder names, from before they were renamed. Want me to rename them? Nothing inside the folders changes, and your work is untouched."

**On yes:** rename the 4 folders, then update the `## Camp N — Name` headings and the mermaid labels in `project/map.md`, and `**Current camp:**` if it names one of the old 4. Say what moved, one line per folder.

**On no:** carry on, and do not ask again this session. Read the position from the old names, per Reading the position above. Everything keeps working. Offer again next session, once.

**Never rename without a yes**, and never touch anything inside the folders. The offer is a separate act from the update that prompted it, which is the whole reason it is an offer.

## Drift

The field and the boxes can disagree honestly. Someone unticks a Camp 1 item
while the trail sits at Camp 4, or finishes Camp 2 work without breaking camp.
That is information, not an error.

When the position from step 1 is a camp whose boxes are all ticked,
surface one line and continue. Do not silently advance:

```
Camp 2 reads complete but the trail hasn't broken camp. /trail closes it.
```

When boxes are ticked in a camp later than the position, surface one line
and continue. Do not move the position:

```
Work filed in Camp 4, trail still at Camp 2. That's fine. /camp allows it.
```

Neither line is a challenge and neither blocks anything. The user made a
choice; the kit says it saw the choice and carries on.

## Writing the position

Only 2 skills move `**Current camp:**`:

| Skill | When |
|---|---|
| `/trail` | Closing a camp at a trail transition |
| `/weather` | Closing Camp 2 on a press on reading, the gate owns that one transition |

`/pack` sets it in exactly 2 situations, and never on any other run:

- **Creating `project/map.md` for the first time.** `Frame`, or, when a project is
  packed from documents it already has (Beat 5, Branch C), the earliest camp
  those documents did not satisfy.
- **Opening a new cycle on request** (Beat 1b), to the camp the user names.

Both start a trail rather than move one, which is why `/pack` is not in the
table above.
On any later run it leaves the field exactly as it found it.

`/camp` never writes it. `/compass` and `/map` never write anything at all.
Out-of-order work ticks boxes and leaves the position alone, that is the
whole reason the 2 facts are stored separately.

## Status

`**Status:**` in `project/map.md`, mirrored at `project/compass.json.meta.status`. 4 values,
and the position is read the same way whatever it says:

| Status | Means |
|---|---|
| `active` | Being worked. The default. |
| `parked` | Deliberately stopped, with a reason written down. `/retro` files it. |
| `shipped` | `/summit` has run. The trail is walked. |
| `turned-back` | `/weather` returned turn back and the user accepted it. |

`parked` and `turned-back` are outcomes, not failures, and nothing in the kit
should treat them as incomplete work. A project parked with a written reason is
worth more than one left silently open, the reason is what you read when you
come back, and the thing you would otherwise have to reconstruct.

Only `/retro`, `/summit`, `/weather` and `/pack` (Beat 1b) write status, and
they always write both places: `**Status:**` in `project/map.md` and
`project/compass.json.meta.status`. Writing one and not the other is how a shipped
project goes on reading `active`.

## Staleness

`**Last updated:**` in `project/map.md` is the date any skill last wrote to it.
Every skill that writes `project/map.md` sets it. `/compass` and `/map` read it.

More than 21 days behind today, on an `active` project, is worth one line —
see `/compass`. It is a question, never a nag, and it is asked once per session.

## Memory

`project/memory/` holds the kit's only cross-session note, `project/memory/session.md`,
append-only, newest last:

```
2026-04-30 · Camp 2 · 2 interviews filed. Said the third is booked for Friday.
2026-05-06 · Camp 2 · Third interview didn't happen. Gate deferred.
```

One line per working session: date, camp, what actually happened, and anything
the user said they would do next. `/pack`, `/trail` and
`/camp` append one line when a session's work ends. `/compass` and `/map` read the last 3.

It is not a transcript and not a summary of the documents, those are already
on disk and re-reading them is cheap. It exists for the one thing the files
cannot hold: what the person said they were going to do, so the kit can ask
about it next time instead of starting cold.

Keep it under 100 lines. If it grows past that, drop the oldest, the
camps hold the record, this holds the thread.
