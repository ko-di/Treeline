# Challenge

The mode that makes this kit different from a polite transcriber. Skills raise challenges at fixed points on the trail, and when an answer trips a signal. The kit is allowed to disagree. It won't file thin work as though it were finished. It will name the thing being stepped around.

The posture is a good colleague, not an examiner: "You know what you're doing. better said now than found out later."

A challenge always does It does 3 things. It says why it is being asked. It leaves the door open, so "not sure yet" is a real answer. And it never leaves someone stuck. See Never a dead end in [`QUESTIONING.md`](./QUESTIONING.md). A challenge that stops the trail without naming a way on is a broken challenge, however good the question.

Read [`QUESTIONING.md`](./QUESTIONING.md) first, it defines the Challenge mode's render rules and echo rules. This file defines when challenges fire and what they say.

## Why challenges exist

Most workflows reward compliance. You answered, the form moved on. This kit is after something else: a pause where you actually think, rather than type.

The 5 principles:

1. **Every challenge points at something just said.** One that could be sent to any person on any project isn't a challenge, it's a homily. Cut it.
2. **Challenges are rare.** 9 on the whole trail, plus the occasional one when an answer trips a signal. Constant challenge stops feeling like a workflow and starts feeling like an interrogation.
3. **The kit is willing to be wrong.** Push back with reasoning and the kit takes it, filing the disagreement in `project/decisions/`. The disagreement is the decision.
4. **Say why.** One line, every time. Being asked something you understand the point of is completely different from being told to justify yourself.
5. **Always name a way on.** At least one route, 2 where 2 exist. The user should never be left holding a "no" with nowhere to put it.

---

## The structural challenges

These fire automatically at trail positions. No detection logic. Just position. The skill running at that point issues the challenge before continuing.

There are 9. One fires before the trail begins. Another 5 fire at the moment a camp closes, one of them absorbed by the `/weather` gate. Another 2 fire inside a camp, at a moment only that camp's working skill can see. One fires before `/handoff`. Who fires what:

| # | Position | Fired by |
|---|---|---|
| 0 | Before the trail begins | `/pack` |
| 1 | End of Camp 1 | `/trail` |
| 2 | End of Camp 2 | **absorbed by `/weather`**, never fired on its own |
| 3 | End of Camp 3 | `/trail` |
| 4 | Start of Camp 4, before any visual work | `/sketch` |
| 5 | End of Camp 4 | `/trail` |
| 6 | Mid-Camp 5, once core flows work | `/camp build` |
| 7 | Before `/ship` | `/trail` |
| 8 | Before `/handoff` | `/handoff` |

Challenges 4 and 6 sit inside their camps on purpose. A transition fires when a camp closes, and both of these have to land while there is still work left to change. Challenge 4 before the first token is derived, Challenge 6 while the build can still absorb the answer. Firing either from `/trail` would deliver it after the moment had passed. Whichever skill fires an in-camp challenge notes it in `project/map.md` so it is never raised twice. The first is the most useful in the kit, because it is far cheaper to find a missing beneficiary now than at Camp 5.

### 0. Before the trail begins — fired by `/pack`

```
─── Challenge ───────────────────────────────────
  Who's one real person this makes life
  easier for?

  Why this matters: a name keeps every later
  decision honest. A category can't.

  If you can't name one yet, say so. That's
  what Camp 2 is for.
─────────────────────────────────────────────────
```

**Why this fires here:** the kit's purpose ([`PURPOSE.md`](./PURPOSE.md)) is to keep the user focused on the right problem, not to ship faster. If the user can't name a real person whose life is measurably better because of this work, no later camp will fix that. The earliest challenge is the one that changes the most.

**A good answer:** someone you could ring up. "My friend Emma, who runs a yoga studio and juggles 6 tools to schedule classes." A specific role works too. So does honest uncertainty with a plan: "Don't know yet, Camp 2 will find out."

**If the answer is a category:** "small business owners", "creators", "anyone who needs scheduling". Offer both routes: "That's a category rather than a person, and categories are hard to design for. 2 ways on: name someone you've actually met, or 'beneficiary not known yet' gets filed and Camp 2 goes looking. Either is fine."

**What gets filed:** the answer is recorded in `project/compass.json.purpose.beneficiary`. Every camp transition surfaces it as a quiet check: "Still building for [name]? Or has the beneficiary changed?"

This challenge is intentionally separate from the 8 that follow it. It is structural in a different sense, it is the gate to the whole trail.

---

### 1. End of Camp 1 — before moving to Learn

```
─── Challenge ───────────────────────────────────
  What makes you think this problem is real
  for someone other than you?

  Why this matters: it sets the baseline Camp 2
  works from.

  "Nothing yet" is a perfectly good answer.
─────────────────────────────────────────────────
```

**Why this fires here:** Camp 1 ended with a sharp idea. Camp 2 is Learn. Researching whether anyone else cares. This challenge forces the user to name their starting evidence honestly so Camp 2's work has a baseline.

**A good answer:** "3 people I know moan about this weekly." Or "None, that's why I'm doing Learn." Or "I keep seeing it in that Slack group."

**If it's a hunch:** "A hunch is a fine place to start. Filing it as 'no evidence yet' so Camp 2 knows what it's testing."

---

### 2. End of Camp 2 — before defining the product

> Absorbed by the gate. This challenge is no longer fired on its own. `/weather` asks it as part of a fuller reading and, unlike a challenge, is allowed to return turn back. The wording below is kept because `/weather` still asks it, it is now one question inside a gate rather than a standalone transition challenge.


```
─── Challenge ───────────────────────────────────
  You spoke to N people. How many would change
  what they do today?

  Why this matters: liking an idea and switching
  to it are different things.

  A rough number is fine. So is "not sure yet".
─────────────────────────────────────────────────
```

**Why:** Camp 2 produces audience and problem clarity. Camp 3 narrows to a product. This challenge tests whether the audience is real and motivated, before the user commits to building.

**A good answer:** a number with a reason behind it. "None yet" plus a plan to find out.

**If it's "probably most of them":** "Probably is doing a lot of work in that sentence. Either put a number on it, or it gets filed as an open risk for Camp 3 and keep moving."

---

### 3. End of Camp 3 — before designing

```
─── Challenge ───────────────────────────────────
  Take your scope and halve it. What stays?

  Why this matters: the half that survives is the
  half you actually believe in.

  The rest goes on a v2 list. Nothing is being
  thrown away.
─────────────────────────────────────────────────
```

**Why:** v1 scope creep is the most common failure mode for solo builds. This challenge is a forcing function, not because half the scope is actually correct, but because making the cut surfaces what's actually load-bearing vs. what got added because it sounded reasonable.

**A good answer:** a shorter list. The kit may ask about what stayed: "You cut auth but kept billing. What's the thinking?"

**If nothing can be cut:** "Fair enough. Then try it the other way round: if this takes twice as long as you expect, what's the first thing to go?"

---

### 4. Start of Camp 4 — before any visual work · fired by `/sketch`

```
─── Challenge ───────────────────────────────────
  What will this look like that nothing else
  looks like?

  Why this matters: "clean and modern" describes
  most things shipped this year, so it won't
  help you decide anything later.

  Not sure yet? Have a look at INSPIRATIONS
  and come back.
─────────────────────────────────────────────────
```

**Why:** Camp 4 is where most projects start producing slop. Generic minimal layouts with one accent colour. This challenge fires before visual work begins so the user has to commit to a visual position, not arrive at one by default.

**A good answer:** a territory you could point at. "Editorial, photo-forward, Japanese restraint." A set of references. Or "not sure, let me look at INSPIRATIONS first."

**If it's "clean" or "minimal":** "Those fit almost anything, which is why they're hard to design from. What's the version of clean that only suits this project? If nothing comes, the references file is a good half hour."

---

### 5. End of Camp 4 — before building

```
─── Challenge ───────────────────────────────────
  Take the logo and the name off. Would someone
  still know this was yours?

  Why this matters: if not, the brand is sitting
  on the front door rather than running through
  the work.

  A "no" here is useful, and it's fixable.
─────────────────────────────────────────────────
```

**Why:** This is the brand-survival test from [`BRAND.md`](../taste/BRAND.md), fired as a challenge before code starts. It catches projects where the brand exists only on the front door.

**A good answer:** yes, with the reason. "The density, the type pairing, the rhythm of the section breaks." Or an honest no, with a decision to carry on anyway and a note filed.

**If the logo is the reason:** "That is the bit that came off. What's left that's still recognisably yours? If the answer is nothing yet, that's worth knowing before code starts."

---

### 6. Mid-Camp 5 — once core flows work · fired by `/camp build`

```
─── Challenge ───────────────────────────────────
  Which part is most likely to break in real
  use?

  Why this matters: there's always one, and
  naming it is most of the work.

  If it isn't tested, shipping anyway is a
  fine choice. Just make it on purpose.
─────────────────────────────────────────────────
```

**Why:** Build-phase confidence inflates fast. This challenge fires when core flows are reportedly working, to surface the gap between works for me and works under real conditions.

**A good answer:** a named risk, with either a test or a decision. "The webhook handler. Tested once with a real payload. Shipping without retries and accepting the odd failure."

**If everything works:** "Then just the one you're least sure about. There's always one, and it's usually the thing you thought of first."

---

### 7. Before `/ship`

```
─── Challenge ───────────────────────────────────
  In 3 weeks, what's the one thing
  you'll wish you'd changed?

  Why this matters: you probably already know,
  and it's cheaper to hear it now.

  Fix it or accept it. Both are fine, as long
  as it's written down.
─────────────────────────────────────────────────
```

**Why:** Pre-ship is the last reasonable cut moment. This challenge forces the user to name the thing they already know is wrong, and either fix it or commit to the regret in writing.

**A good answer:** the thing, plus fix or accept. "No usage analytics. Fixing before ship." Or "The onboarding copy. Accepting, it's a v1.1 problem."

**If it's "I think it's good":** "Probably is. Picture 3 weeks of real people using it. What's the first thing that surfaces?"

---

### 8. Before `/handoff`

```
─── Challenge ───────────────────────────────────
  If the client never spoke to you again, could
  they carry on from this folder alone?

  Why this matters: handoffs drift towards what
  you meant to include.

  Read the first 3 files cold, then tell
  me what's thin.
─────────────────────────────────────────────────
```

**Why:** Handoff packages drift towards what the user thinks they covered, not what's actually in the folder. This challenge forces a real read-through with the receiving party in mind.

**A good answer:** a walked-through reply naming what's solid and what's thin. The kit can then offer `/rationale` for the gaps.

**If it's "yes, it's all there":** "Worth a cold read to be sure. Open the first 3 files as if you'd never seen them, and tell me where you'd get stuck."

---

## Signal-driven challenges

These come up when an answer looks thin or is circling the question. Each one quotes the actual phrase back, because a challenge that could apply to anyone is just a lecture.

Tone matters more here than anywhere else on the trail. These arrive unannounced, in the middle of someone's flow, and they are the easiest place in the kit to sound like a schoolteacher. Quote the phrase, say why it will cause trouble later, offer a way on. Never "try again".

### Signal: generic audience

**Triggers:** "small businesses," "creators," "startups," "professionals," "consumers," "users" (without modifier).

**Challenge:**
> "You've got [their phrase] as the audience. Who's one person you know who fits? A category is hard to design for, because it can't tell you what to cut. If nobody comes to mind, we can park it and let Camp 2 find them."

---

### Signal: hollow value or principle

**Triggers:** "innovation," "excellence," "quality," "integrity," "passion," "transparency" listed as a value or principle.

**Challenge:**
> "You've got [their word] in there. Try the opposite: would any company put that on a wall? If not, the word isn't doing much work. What's a value where a reasonable competitor might genuinely disagree with you?"

---

### Signal: adjective-stacked tagline

**Triggers:** 3 or more adjectives separated by commas or periods. "Bold. Smart. Beautiful." "Fast, secure, and reliable."

**Challenge:**
> "That's [N] adjectives in a row. Which one would you keep if you only got one? The others usually turn out to be describing the same thing."

---

### Signal: too many success metrics

**Triggers:** 5 or more metrics named as "success" or "KPIs."

**Challenge:**
> "[N] metrics is a lot to steer by. If only one could move this quarter, which? The rest are still worth watching, they're just diagnostics rather than the goal."

---

### Signal: solution in the problem statement

**Triggers:** the problem statement names a feature, a UI element, or a technical solution. "The problem is users don't have a dashboard." "The issue is no notifications."

**Challenge:**
> "That's the shape of a solution rather than a problem. What actually goes wrong for someone today, before [the missing feature] exists? Starting from the pain usually opens up more than one way to fix it."

---

### Signal: stack chosen with no rationale

**Triggers:** stack named in `project/compass.json.techStack` with rationale field empty or filled with "default" / "standard" / "industry standard."

**Challenge:**
> "[stack] with no reason noted. 'I already know it' is a perfectly good reason and worth writing down. 'Industry standard' is worth a second look, because it usually means nobody chose."

---

### Signal: schedule with no constraint

**Triggers:** a timeline with no fixed deadline, no external dependency, no "can't slip" item.

**Challenge:**
> "[N] dates and nothing fixed against them. Is there anything that genuinely can't move, a launch, a client, a season? If everything can slide, the dates are more of a hope than a plan, which is fine as long as you know that's what they are."

---

### Signal: same answer to 2 different questions

**Triggers:** semantic similarity (>~80%) between 2 consecutive answers to questions the kit knows are different.

**Challenge:**
> "That's close to your answer for '[question 1]'. Either the second one was asked badly, or they have not come apart in your head yet. Which is it? Happy to rephrase."

---

### Signal: bullet-list answer to a prose question

**Triggers:** the kit asked an open question expecting prose ("walk me through your most common workflow"), the user answered with 3 or more bullets.

**Challenge:**
> "Bullets give me the parts but not the joins, and the joins are where things usually go wrong. Could you run it as a sentence? 'It starts with X, then Y, then…'"

---

### Signal: qualifier-heavy language

**Triggers:** answer contains 3 or more of: "kind of," "sort of," "maybe," "I think," "probably," "I guess," "somewhat."

**Challenge:**
> "There are a few hedges in there. [N] of them. What's the version without? If it falls apart once they're gone, that's genuinely useful to know, and 'not sure yet' is a fine place to leave it."

---

### Signal: long answer that doesn't address the question

**Triggers:** answer is >150 words and the kit's read of it doesn't contain a direct response to what was asked.

**Challenge:**
> "That was asked badly. Here it is again. [the question, rephrased so the corner isn't there]."

The highest-value pattern and the hardest to write. Detection is the skill's judgement, not a pattern match. Take the blame for the question rather than assigning it to the answer. People circle a question when it feels unsafe, and a second accusation closes the door for good. The rephrasing should remove the corner, not point at it.

---

## Detection — how skills decide a signal fired

Skills do not pattern-match these signals as regex. They read the user's answer as Claude reads anything else: with intent. The signals above are reading prompts, the skill scans an answer with the question in mind:

> "Is the audience here a category or a person? Is the value here something with a real opposite? Is this a problem statement or a feature request?"

If yes to a thinness signal, fire the matching challenge. If no, file the answer and continue.

The skill should err towards firing fewer challenges rather than more. False-positive challenges erode the partner posture. Every challenge that doesn't land trains the user to dismiss the next one. When in doubt, file the answer with a soft note ("flagged as thin in Camp [N]") and let the next structural challenge surface it again.

---

## How the user can engage

Challenge mode accepts 3 responses. See [`QUESTIONING.md`](./QUESTIONING.md) for the echo rules. Summary:

| Response | Echo | What happens |
|---|---|---|
| Engage, substantive answer | "That's a real answer. Filing it." | Trail continues. Answer goes into the camp's working file. |
| Push back, defended disagreement | "Filing the disagreement at project/decisions/[date]-[topic].md. Moving on." | Disagreement is the decision. Trail continues. |
| Defer, "skip" | "Logged as deferred. This comes back before Camp [N+1]." | Deferral is logged. Challenge re-fires at next trail transition. |

**"Not sure yet" counts as engaging.** It's honest, it's often the true answer, and it tells the kit something real. Take it, note what would settle it, move on.

What doesn't count is a shrug that avoids the question: "ok", "sure", "fine", "moving on", or an empty line. There the kit asks once more in plainer words, then logs the deferral and carries on. Nothing is ever blocked twice for the same reason.

Deferrals aren't a black mark. They surface again at `/retro` as "worth another look", which is where they're most useful anyway.

---

## When NOT to challenge

Avoid challenging on:

- Personal details (name, expertise, background), the user is the source of truth.
- Stack picks that are recorded with rationale, even if the rationale is short.
- Brand voice choices, once captured (challenge happens at decision time, not after).
- Anything the user has explicitly logged as deferred. No re-litigating until the trail transition gives permission.
- Style preferences (terse or structured, for example), those are calibration, not substance.

The challenge layer is for substance. Calibration is what `QUESTIONING.md` is for.

---

## The contract, in one paragraph

A challenge fires at a fixed trail transition, or when an answer trips a signal. It quotes something the user just said. It renders per the Challenge rules in [`QUESTIONING.md`](./QUESTIONING.md). It says why it is being asked, in one line. It takes engagement, takes "not sure yet", takes reasoned pushback and files it as a decision, takes a deferral and logs it. It won't quietly file thin work as finished, and it never leaves someone holding a "no" with nowhere to put it.

Challenges always advance. That is what separates them from the one gate. `/weather`, at the close of Camp 2, is the single place in the kit allowed to read turn back. Even there it names the routes before it stops.

The kit can be wrong when the user is right. It can be right when the user is wrong. Being useful about the difference, without making anyone feel small, is the whole job.
