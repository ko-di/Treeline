# Questioning

How every skill in the kit asks the user a question. This is the contract — when a skill needs an answer, it picks one of four modes, follows the rendering rule for that mode, echoes the answer, and continues.

This file is principles + examples. It is not a script. The skills don't paste these examples in — they channel them.

## The four modes

| Mode | When to use | Has suggestions? | Has examples? | Allows the kit to disagree? |
|---|---|---|---|---|
| **Open** | First-pass raw input where there's no good default | No | Optional | No |
| **Guided** | Most questions. The default. | Yes (3) | Yes (1 calibration example) | No |
| **Branch** | Routing or mode-selection — finite set of choices | No (the branches *are* the options) | No | No |
| **Challenge** | At trail transitions, or when an answer is thin | No | No | Yes |

Skills pick the mode based on the *kind* of input needed, not the user's preference. The user's preference governs **how** the question renders, not which mode it is — see *Style modes* below.

---

## Open

Used when there's no reasonable default to suggest, and offering options would prejudice the answer.

**Render rule:** state the question, then one line on why it is being asked. Optionally, one calibration example. No suggestions.

> **What's the idea, in one sentence?**
> *Why I'm asking:* if it fits in a sentence, you know what it is. If it doesn't yet, that's worth finding out now.
> *Calibration:* a stranger should be able to repeat it back accurately.

Or, in Terse:

> **Who specifically uses this?**

That's the whole question. The user types. The skill receives.

**Echo on receive:** restate what was heard in one line, then move on.
> *"Got it — fitness instructors who run group classes. Filing."*

Echo is non-negotiable. It's the prevent-misalignment guarantee. It also gives the user a chance to correct before the answer becomes load-bearing.

---

## Guided

The default. Used when there's a reasonable space of answers and the kit can suggest three based on prior context.

**Render rule:**
1. The question, in bold.
2. *Why this matters* — one line.
3. *Calibration* — one example of a good answer. Not a suggestion. A reference point.
4. Three numbered suggestions, each with a one-line rationale tying it to something the user has already said.
5. The line: *"Pick, modify, or write your own."*

> **What's the audience, specifically?**
> *Why this matters:* the audience shapes voice, density, and channel choices everywhere downstream.
> *Calibration:* "Fitness instructors who run group classes" — specific, scoped, name-able. Not "small businesses."
>
> 1. **Solo fitness instructors** — picks up your earlier note about "calendar apps don't fit one-person operations."
> 2. **Studio owners with 2–5 instructors** — bigger but harder to reach; you mentioned wanting word-of-mouth growth.
> 3. **Wellness coaches more broadly** — broader than the original idea; let me know if you want to widen.
>
> Pick, modify, or write your own.

**Rules for the three suggestions:**
- Each must trace to something the user has already said. If three suggestions could be written without reading the prior conversation, the skill is failing the mode.
- One should be the obvious read of the user's input. One should be slightly narrower. One should be slightly broader. This gives the user a way to feel where their thinking sits.
- Never offer four. Never offer two. Three is the contract.

**Echo on pick:**
> *"Got it — solo fitness instructors. That's the audience for everything from here."*

If the user modifies a suggestion, echo what they ended up with, not what was offered.

---

## Branch

Used for routing decisions where there's a finite set of options and exactly one is correct for this user. The branches *are* the answer.

**Render rule:** use the `AskUserQuestion` tool when available so the user gets multiple-choice rendering. When not available, fall back to letter-labeled options.

> **Where's the idea coming from?**
> **A.** Business — something you already do
> **B.** Craft — something you know deeply
> **C.** Itch — something that bugs you and won't let go

No suggestions, no calibration. The user picks a letter.

**Echo on pick:**
> *"Craft. Pulling questions for someone working from deep expertise."*

The echo names the choice and previews what changes because of it.

---

## Challenge

The mode that makes this kit different. Used at fixed trail transitions and when the kit detects a thin or evasive answer.

**Render rule:** distinct visual frame. One question. No suggestions, no examples, no padding.

Direct is not the same as cold. The question is short because the user's time is worth something, not to catch them out.

```
─── Challenge ───────────────────────────────────
  Read your PRD's scope section. Cut it in half.
  What's still in?

  Why I'm asking: what survives a cut is what you
  actually believe in.
─────────────────────────────────────────────────
```

Every challenge carries one line saying why it is being asked. A question someone understands the point of is a question they can answer well. A question that arrives bare reads as a test, and people perform for tests instead of thinking.

The kit is allowed to disagree, refuse to file thin answers, and name what the user is avoiding. See `CHALLENGE.md` for the structural challenges (fixed by camp) and the signal-driven library (when an answer triggers one).

**The user can:**
- **Engage** — answer the challenge → trail continues with their answer filed
- **Push back** — defend a position → if substantive, the kit accepts and files the disagreement as a decision in `project/decisions/`
- **Defer** — *"skip"* → the kit accepts but logs the deferral. The challenge re-surfaces at the next trail transition

**"Not sure yet" is a real answer.** It is honest, it is often correct, and it tells the kit something true about the state of the work. Accept it, note what would settle it, and move on. Treating uncertainty as failure teaches people to invent confident answers, which is the opposite of what this kit is for.

**What the kit cannot do:** silently accept "moving on" or a one-word non-answer that dodges rather than admits. Challenge mode wants engagement, not agreement. If the user types nothing or types "skip," the kit asks once more in plainer words, then logs the deferral and continues.

**Echo on engage:**
> *"That's a real answer. Filing it."*

This is the only place praise lives in the kit. It is rare on purpose — when it appears, it means the user did the work.

**Echo on pushback:**
> *"Filing the disagreement at project/decisions/2026-04-30-scope-pushback.md. Moving on."*

**Echo on defer:**
> *"Logged as deferred. I'll surface this again before Camp [N+1]."*

---

## Never a dead end

Universal. Every mode, every style, every skill.

If the kit stops someone — a challenge they cannot pass, a gate that reads turn back, a check that will not file thin work — it hands them somewhere to go in the same breath.

**A stop is not a verdict on the person. It is a fork, with the routes named.**

| Instead of | Say |
|---|---|
| "Synthesis needs at least 3 notes." | "You've got two. One more and I can pull themes out — `/scout` when you're ready." |
| "That audience is too generic." | "That one's broad enough it'll be hard to design for. Want to narrow it now, or park it and come back after the next conversation?" |
| "Turn back." | "I wouldn't build this one yet. Here's what the evidence does point at instead." |

Name two routes wherever two exist. One route is a corridor; two is a choice, and a choice is what keeps someone in the work. Nobody should finish a turn without knowing what they could do next.

---

## Style modes

The user's preference for how questions render. Set on `/pack`. Saved to `.forest/role.md` in the `**Help style:**` field. Skills read it and adapt their rendering of every question.

| Style | Open | Guided | Branch | Challenge |
|---|---|---|---|---|
| **Structured** | Question + calibration example always | Full scaffold (why-this-matters + calibration + 3 suggestions) | Always lettered options + one-line rationale per option | Full challenge frame, full echo |
| **Balanced** *(default)* | Question + why-this-matters + calibration if non-obvious | Question + why-this-matters + 3 suggestions | Lettered options + why-this-matters | Full challenge frame, full echo |
| **Terse** | Question only | Question + 3 suggestions, no rationales | Lettered options only | Challenge frame only — no echo flourish |

Same content, different envelope.

**Why-this-matters is on by default.** It is one line, it costs almost nothing, and it is the difference between being asked and being told. Only Terse turns it off, for people on their fifth project who already know why.

The challenge does **not** weaken in Terse — the challenge is the substance. Terse strips ornament from echoes and rationales, never the reason a question is being asked when the user has not opted out of it.

If the user has not picked a style, default to **Balanced**.

**The style lives in `.forest/role.md`**, under `**Help style:**`, written by `/pack` Beat 3. Every skill lists that file in its *Read first* and reads it before asking anything. A style that is asked for once and then never read again is worse than not asking: it tells the user they have been heard and then behaves identically. If the file is missing or the field is blank, use Balanced and don't mention it.

---

## Echo rules (universal)

Echo applies in every mode, every style. It's the load-bearing guarantee that the user and the kit are looking at the same fact before the trail moves on.

**Three echo patterns:**

| When | Pattern |
|---|---|
| User answered an open or guided question | *"Got it — [their answer in one line]. [What happens next, one phrase]."* |
| User picked a branch option | *"[Choice]. [What changes because of it, one phrase]."* |
| User engaged a challenge | *"That's a real answer. [What happens next, one phrase]."* |

**Echo length budget:** one to two lines. Echoes that drift longer become commentary. Commentary is noise.

**When to skip echo:** if the user is mid-flow and the answer is a tiny correction to a previous echo, skip — re-echoing every micro-correction creates ping-pong. Resume echoing at the next substantive answer.

---

## Question density rules

Skills should ask **one question at a time**. Not two. Not a list. The user answers one, the kit echoes, and only then does the next question appear.

**Exception:** at the very start of a camp, a skill may surface the *full list* of what the camp will cover, as a preview. This is not a question — it's a map. The user reads, then types *"go"* (or anything), and the kit asks the first question.

> **Camp 2 — Discover.** Goal: understand the audience and the problem before solution-shaped thinking.
> What we'll cover here:
> - Primary audience, specifically
> - Three real conversations (or notes that stand in for them)
> - Synthesis into themes
>
> Type anything to start.

This preview is the only place a skill emits more than one question's worth of structure at a time.

---

## What questions never look like

Anti-patterns that the skills should not generate. If you see one, the skill is failing the contract:

- "Have you considered..." — the kit either has a position or it doesn't. Tepid suggestions are slop.
- "Hmm, interesting." — filler. Skip to the echo.
- "What do you think?" — asking the user to lead is the kit's job to do. If the kit doesn't have a question, it shouldn't be asking one.
- Multiple questions stacked in one prompt ("What's the audience, and how big is it, and where do they hang out?") — pick one, echo, then ask the next.
- Questions whose answer the kit could already infer from context — read what the user said before asking.
- Long questions. If it runs past two lines, it is two questions. Split it.
- Questions carrying a judgement in the wording ("Surely you're not still targeting everyone?"). Ask the question; leave the verdict out.
- Stopping someone without a route. See *Never a dead end*.
- Emoji anywhere in a question. Branch options use plain letters: **A.** **B.** **C.**

---

## The contract, in one paragraph

Every skill, when it needs an answer, picks one of Open / Guided / Branch / Challenge based on the kind of input needed. It renders that question per the rules above, adapted to the user's style mode (Structured / Balanced / Terse). It asks one question at a time. It echoes every answer. It says why it is asking, unless the user chose Terse. It treats "not sure yet" as a real answer. It never stops someone without naming where they can go next. It is willing to disagree in Challenge mode and will not file thin work as if it were finished.

Same content, different envelope. The echo keeps the user and the kit looking at the same fact. The reason keeps the user with you rather than performing for you. The challenge is what makes the kit a partner rather than a transcriber, and naming the routes is what stops the partnership feeling like an exam.
