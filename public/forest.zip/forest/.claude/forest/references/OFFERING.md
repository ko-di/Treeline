# Offering

How every skill offers a piece of work: a method, an exercise, a check or a command. This is the contract. When a skill puts something in front of the user, it says 3 things, in this order, each in one line.

`QUESTIONING.md` governs how a question renders. This file governs how work is offered. They do not overlap.

## The 3 lines

> When to use it: the situation this fits, in the user's terms.
> The benefit: what they get for the time, stated as an outcome.
> You've got it right when: a test they can run themselves, without asking.

Then the work itself, or the command that starts it.

An offer without the third line is a suggestion. An offer with it is something a person can start, finish and check on their own. That third line is the one that does the work, and the one most often left out.

## The rule for the third line

**The user must be able to check it without asking forest.** It names a thing they can count, find or point at.

| Fails | Passes |
|---|---|
| Your research is thorough | 3 people named, each with a date |
| The direction is clear | Every token in `design.md` says which reference it came from |
| The brief is ready | Someone who was not there could build phase 1 from it |
| It feels right | Nothing on the screen is there by convention alone |

The failing column is praise wearing a checklist. The guide bans praise, and a line the user cannot check for themselves is that. If a test cannot be written for something, it is not ready to be offered as work.

## Where the lines come from

Skills do not invent them. Each method, check and exercise in `knowledge/` carries its own 3 lines as a header, written once. A skill reads them and puts them in the user's words about the user's product.

Generic:

> When to use it: when the question is about how the work actually gets done.

For this project:

> When to use it: when you want to know how Sam actually books a repair, rather than how he says he does.

The second is the one the user hears.

## Sizing

The 3 lines are always 3 lines. The work after them scales with the user's settings, the same way research does:

- `compass.json.research.time` decides how much research gets offered.
- `.forest/role.md` `**Team:**` decides which methods get offered at all. A method that needs 4 people is never named to somebody working alone. Not offered, not ruled out, not mentioned.

An offer that does not fit the settings is not made. The settings exist so the user never sees a list they cannot use.

## What an offer is not

- Not a menu. Up to 3, chosen for this user, per `QUESTIONING.md`'s guided mode.
- Not a lecture on why the work matters. The benefit is one line. If it needs more, the work is not clear enough yet.
- Not a promise about the result. "You'll find 3 patterns" is a guess. "You'll have 3 notes to compare" is a fact.
- Not the same shape every time. The 3 lines are fixed. The work under them is not, and a reader who sees identical structure 12 times stops reading.

## Anti-patterns

- Offering work without the third line.
- A third line the user needs forest to judge.
- Writing the 3 lines fresh instead of taking them from the knowledge file.
- Quoting the generic lines instead of rewriting them for the product.
- Naming a method the user's settings rule out, even to say why it was ruled out.
