# Texture

The moments where the workflow has weight. Linear-grade subtle. Dignified. Brief. Never celebratory.

This file specifies the visual and verbal treatment for every moment that earns weight: camp closes, milestones, summit, challenge frames, earned acknowledgments. Skills follow these formats exactly so the user gets a consistent rhythm across the trail.

## Why texture exists

A workflow without texture is a form. Files appear, files get filled, and the user never feels the work. A workflow with the wrong texture — confetti, exclamation marks, "Great job!" — is worse: it cheapens the work and trains the user to dismiss it.

Texture earns its weight by:
1. **Being rare.** Most of the kit is quiet. A milestone lands because the in-between is silent.
2. **Being honest.** No flourish without a real event behind it.
3. **Being brief.** A milestone is one to four lines. A summit is fifteen. Anything more becomes commentary.

The reference voice for texture is Linear's issue-closed notification, GitHub's PR-merge button, Stripe's checkout confirmation — minimal, factual, weighted. Not a fitness app, not a video game, not a children's product.

---

## The texture inventory

| Moment | When it fires | Format |
|---|---|---|
| Decision filed | `/rationale` writes to `project/decisions/` | One-line acknowledgment |
| Note added | A research note lands in `project/research/` | One-line counter |
| First commit at a camp | The first git commit while in a camp's working folder | One-line marker |
| Camp closed | The skill closing a camp (via `/trail`) | Box format with recap + next-camp preview |
| Challenge frame | Any challenge from `CHALLENGE.md` | Box format with `─── Challenge ───` header |
| Weather frame | `/weather` returns a reading at the close of Camp 2 | Box format with `─── Weather ───` header |
| Progress marker | Returning after a gap, half-way, last camp | One flat line stating position |
| Earned acknowledgment | After substantive engagement with a challenge | One-line acknowledgment |
| Bridge handoff | When the kit sends the user out (see `BRIDGES.md`) | Numbered pre-departure block |
| Bridge return | When the user pastes back what they did | One-line pickup |
| Trail summit | Position reaches `summit` (`STATE.md`): Camps 1–5 closed, Camp 6 deployed | Full summit block (largest texture in the kit) |

Anything not in this table gets no texture. A standard answer-and-echo exchange is texture-less by design — the silence is what makes the moments above land.

---

## Decision filed

Triggered by `/rationale` on any decision-capture. Format: one line, after the file is written, no flourish.

```
Decision filed at project/decisions/2026-04-30-stack.md.
```

That's it. No "Nice." No "Captured." No emoji. The fact that the file was written is the acknowledgment.

---

## Note added

Triggered when a research note is filed in `project/research/`. Format: one-line counter that gives a sense of accumulation.

```
Note 3 of ~5 filed.
```

The "~5" is approximate — surfaced from the camp's checklist target. If no target is set, just:

```
Note added.
```

---

## First commit at a camp

Triggered the first time a git commit happens while the user is working a specific camp. Once per camp.

```
First commit at Camp 5.
```

Subsequent commits get no texture. The first one matters because it marks the transition from planning to building. The fifteenth doesn't.

---

## Camp closed

Triggered when a skill closes a camp via `/trail`. This is the most common texture moment on a trail and the one users encounter most.

**Format:**

```
─── Camp 3 of 6 closed ──────────────────────────
  Define · 4 decisions · 2 days
  ●●●○○○  three camps to go

  → Camp 4 — Design
    Brand voice, visual direction, key flows.
    Have a mood board or Figma file? Drop the link.
    Otherwise type /sketch when ready.
─────────────────────────────────────────────────
```

**Composition rules:**

| Line | Content |
|---|---|
| Top border | `─── Camp [N] of 6 closed ` then dashes to ~50 chars total |
| Stat line | Camp name + count of decisions filed + duration in days |
| Progress line | Six markers, filled for closed camps, plus *"[N] camps to go"* (or *"last one"* at Camp 5) |
| Blank line | One |
| Arrow | `→ Camp [N+1] — [name]` |
| Description | One sentence on what the next camp is about |
| Action line | One sentence telling the user what to do next |
| Bottom border | Dashes to ~50 chars |

**No emoji. No "Great work!" No exclamation marks.** The box is the texture. The fact that the kit drew a line under the camp is the acknowledgment.

**The progress line is orientation, not praise.** Knowing you are three from the end is the single most useful thing the kit can tell someone mid-trail, and it costs nothing from the praise budget. Most people who abandon a long process do it because they have lost their sense of where they are, not because the next step was too hard. State the position plainly and let it do its work.

**The project/map.md update happens silently in the same beat:** the Mermaid diagram's `class` line for that camp flips from `wip` to `done`. The user sees the box; the file reflects the new state.

---

## Challenge frame

Specified in [`CHALLENGE.md`](./CHALLENGE.md). Repeated here for completeness — the frame is part of texture.

```
─── Challenge ───────────────────────────────────
  [Question, 1–3 lines max]

  [Optional second beat, 1 line]
─────────────────────────────────────────────────
```

**Composition:**
- Top border: `─── Challenge ` then dashes to ~50 chars total.
- Two-space indent on every interior line.
- Blank line before the second beat if one exists.
- No emoji, no "but seriously," no softening.

The Challenge frame and the Camp Closed frame use the same border style on purpose — they're both "the kit is asking you to engage" moments. The difference is the header word.

---

## Weather frame

Used by `/weather` at the close of Camp 2. Same border style as the Challenge frame, different header word — both are "the kit is asking you to engage" moments, but this one can end the trail.

```
─── Weather ─────────────────────────────────────
  [Reading: Press on / Reroute / Turn back]

  [One sentence on why, referencing the ledger.]

  Your turnaround rule: "[verbatim]"
  [Met / Not met.]

  What would change this: [specific evidence]
─────────────────────────────────────────────────
```

**No emoji. No softening. No encouragement after a turn back.** If the reading is turn back, the next thing on screen is the reroute options the evidence supports — not reassurance. The reading is the service.

---

## Earned acknowledgment

Triggered only after substantive engagement with a Challenge. Specified in [`CHALLENGE.md`](./CHALLENGE.md). One line, plain text, no frame.

```
That's a real answer. Filing it.
```

**This is the only place praise lives in the kit.** It is rare on purpose. When it appears, it means the user did the work — engaged with a challenge, defended a position, named a real constraint instead of hedging.

Acknowledgment never appears after a normal Open / Guided / Branch question. Those get standard echoes only. The pattern is: *normal questions get echoes, challenges that earn engagement get acknowledgment.*

**Variants — pick the one that fits the engagement:**

| Engagement | Acknowledgment |
|---|---|
| Substantive answer to a structural challenge | *"That's a real answer. Filing it."* |
| Substantive pushback on a challenge | *"Filing the disagreement at project/decisions/[file]. Moving on."* |
| Cut scope in half cleanly | *"Sharp cut. Filing the new scope."* |
| Named a regret pre-ship | *"Filed. Decide now: fix or accept."* |

Skills should not invent new acknowledgments. The kit has four. That's the budget.

### Progress markers are not praise

Distinct from acknowledgment and not counted against its budget. A progress marker states where the user is. It carries no verdict on them or on the work.

| Moment | Marker |
|---|---|
| Returning after a gap of days | *"Picking up at Camp 3. Your last decision was [x]."* |
| Half the trail done | *"That's three camps behind you. Three to go."* |
| Last camp opening | *"Camp 6. Last one."* |

Say them flatly. *"Three to go"* is orientation. *"Only three to go, you're doing great!"* is flattery wearing orientation's coat, and it spends trust the kit will want later at a challenge.

---

## Bridge handoff

When the kit sends the user out to do work it can't do (see [`BRIDGES.md`](./BRIDGES.md)). Format: numbered pre-departure block. No frame.

```
We need a real conversation with someone in your audience before
Camp 2 closes. Bridge:

1. Schedule one 30-minute call this week.
2. Use the interview guide in project/2-discover/interview-guide.md.
3. Record (with permission) or take notes during.
4. Drop the transcript or notes into project/research/ when done.

I'll be here. Type /scout when you're back.
```

**Composition:** brief context (one sentence), word "Bridge:", numbered list, return instruction.

The return instruction always names the command the user will type when they come back. This closes the loop — the user knows the kit is waiting on a specific signal, not just hoping.

---

## Bridge return

When the user pastes back a link, transcript, or screenshot from a bridge. Format: one-line pickup.

```
Got the Figma file — analysing 7 frames. Back in a moment.
```

Or:

```
Got the transcript. Filing in project/research/2026-04-30-interview-1.md.
```

The pickup names what was received and what's about to happen. No "thanks for sharing" — that's filler.

---

## Trail summit

The largest texture moment in the kit. Fires when all six camps are closed and `/ship` has succeeded. Once per project, ever.

**Format:**

```

       ┌─────────────────────────────────────┐
       │                                     │
       │           SUMMIT                    │
       │                                     │
       │           [Project name]            │
       │                                     │
       │           [date shipped]            │
       │                                     │
       └─────────────────────────────────────┘

  6 camps closed · [N] decisions filed · [N] days

  Compiled summary at project/SUMMIT.md.

  Suggested next:
    /retro      — what worked, what didn't
    /handoff    — package for client (if applicable)
    /schedule   — set a follow-up agent for week +13

```

**Composition rules:**

- Single ASCII box, three blank interior lines, project name centred, date centred.
- Below the box: stat line with camp count, decisions, duration.
- One line on the compiled summary file.
- Three suggested next-actions, each with a one-line description.
- No emoji, no "Congratulations!", no "🎉".

**The compiled summary file `project/SUMMIT.md`** is generated at this moment by reading every camp's working folder and assembling a single document — vision, brand, PRD, key decisions, link to the deployed product, and a final reflection block (below). This is the artifact the user can point at to say *"this is what we built."* It is not a celebration; it is a record.

**The summit reflection — the one section that does not get filled in.**

The kit cannot answer whether the work mattered. Only time can. So `project/SUMMIT.md` ends with a section the kit explicitly leaves empty, with three questions and a prompt to come back in three months:

```markdown
## Three months from now

Come back to this section on [date + 90 days]. Answer cold.

1. Whose life is measurably different because this exists? Name them.
   Did the beneficiary you named in project/compass.json.purpose.beneficiary
   actually benefit? If not — who did, and what does that mean?

2. What did you ship that you'd cut now?

3. What did you cut that you'd put back?
```

The date is computed from `project/compass.json.meta.shippedAt`. The kit fills in the date and the prompt; the user fills in the answers, in their own time, alone. This is the most important reflection in the kit and it cannot be done at the summit moment — it requires distance.

If `/summit` set a `/schedule` agent, the agent surfaces this section back to the user at +90 days. (See `BRIDGES.md` — this is the only "future bridge" the kit emits: a bridge to the user's later self.)

**Why this gets more texture than camp closes:** it is the single moment in the project that earns it. The user has walked the full trail. Brevity at the summit would feel cold. Restraint everywhere else makes this moment land. And the three-month reflection is what closes the loop on the kit's purpose: *the work mattered or it didn't, and the only honest test is time.*

---

## Anti-patterns

The kit must never produce these. If a skill generates one, it's failing texture:

- Confetti emoji bursts (`🎉`, `🚀`, `✨`) anywhere.
- "Great job!" / "Awesome!" / "Nice work!" — empty praise.
- Multi-paragraph celebrations after a small action.
- Progress percentages on minor actions ("You're 23% through Camp 2!").
- Streak counters, daily-use rewards, or any gamification.
- Praise after a normal echo. *Echo is not texture.*
- ASCII art on every action — only at the summit.
- Boxes around anything outside the inventory above: camp closes, challenges, the summit, and the few skill closes that use one (`/pack`, `/weather`).
- Calling out "milestone unlocked" or any video-game vocabulary.
- Borders thicker than `───` — heavier rules read as alarm, not weight.

If a skill is tempted to celebrate something that isn't in the texture inventory above, the answer is silence. The standard echo is enough.

---

## Style mode interaction

[`QUESTIONING.md`](./QUESTIONING.md) defines three style modes — Structured, Balanced, Terse. Texture interacts with them as follows:

| Texture moment | Structured | Balanced | Terse |
|---|---|---|---|
| Decision filed | Full one-liner | Full one-liner | Full one-liner |
| Note added | With counter | With counter | "Note added." |
| First commit | Full | Full | Full |
| Camp closed | Full box | Full box | Full box |
| Challenge frame | Full box | Full box | Full box |
| Earned acknowledgment | Full | Full | One word: *"Filed."* |
| Bridge handoff | Full numbered list | Full numbered list | Numbered list, no context sentence |
| Bridge return | Full | Full | "Got it. Filing." |
| Summit | Full ASCII box | Full ASCII box | Full ASCII box |

**Four things never weaken across modes:** camp-closed boxes, challenge frames, the Weather frame, the summit. These are load-bearing — Terse strips ornament from acknowledgments and bridge prose, but the structural texture moments are not negotiable. If they collapsed in Terse, the trail would have no rhythm at all.

---

## The contract, in one paragraph

Every weighted moment in the kit follows the format in this file. Texture appears only at the moments listed in the inventory; everywhere else is silent by design. Boxes are reserved for camp closes, challenge frames, the summit, and the handful of skill closes named in the anti-patterns. Praise is rare and earned — only after substantive engagement with a challenge, only with the four sanctioned acknowledgments. The summit gets the most weight because it's the only moment in the project that earns it. Quiet in-between is what makes the moments land.
