# forest

**Scale design without losing craft.** forest takes an idea through research, requirements, a design direction and a build, to something you can push. It runs inside [Claude Code](https://claude.com/claude-code) as a set of skills. There is no separate app.

Slower than tools that promise a PRD in ninety seconds, on purpose. It asks why before it asks what, records how you know each claim, and won't let you finish while still vague about who this is for.

**First time here?** [Is it for you](#is-it-for-you) → [Install](#install) → [Your first session](#your-first-session). Already running it? [The six camps](#the-six-camps), [what to do with the files](#what-you-end-up-with), [building it](#building-it).

## Is it for you

| You are | What you get |
|---|---|
| Sitting on an idea with no documents | Intake through to requirements in a sitting, then a brief to build from |
| Unsure whether the problem is real | [The gate](#the-gate), and `project/EVIDENCE.md` |
| Months into building, nothing written down | Run intake against what exists. The gaps it reports are usually the parts nobody agrees on |
| Handing work to someone else | The folder is the handover, with the reasoning attached |
| Working for a client | Client mode adds a handoff package and names what was left out |

It covers product thinking, user research, a design direction and the technical planning, across six camps.

Camp 6 also writes how the product reaches people. `/reach` sets out the position, the wedge, who first, what it replaces, how money works and the first thirty days, in your own voice, with every claim traced to something you know.

Built for digital products: web and mobile apps, sites, tools. It also runs on things with no interface such as a CLI, a newsletter or a service, where Camp 4 does voice and identity instead of colour tokens. It is not built for research projects with no product at the end, and it will keep asking you what you are shipping.

## Why forest

**It can tell you to stop.** The gate weighs your evidence by where it came from, not how it reads, and returns press on, reroute or turn back. It will not press on when the claim everything rests on is a guess.

**It records why.** Every claim tagged by source. Every design token traced to the reference it came from. In six months the folder answers *why is it this*, not just *what is it*.

**It builds.** Camp 5 compiles one brief, then works the phases in order: build, review for bugs, check against the design, commit, tick, next.

**It hands over.** A stranger can pick up the folder and carry on.

Slower than working freehand. That is the trade.

## Start a project

**You need the [Claude app](https://claude.com/download)**, with Claude Code in it. Nothing else: no Terminal, no GitHub account, nothing to install.

1. **[Download forest](https://treeline-sand.vercel.app/forest.zip).** You get `forest.zip`.
2. **Unzip it, and rename the folder** to your project's name — `lending-log`, say. Put it wherever you keep your work.
3. **Open the folder in Claude Code, in the Claude app.**
4. **Type `/pack`.**

That's it. `/pack` asks a few questions and sets the project up in that folder. From then on, open the same folder and type `/trail` to carry on.

**One download per project.** For your next idea, download again. That also gets you the newest version.

The folder looks almost empty at first: a README, a guide to building, a licence. The kit itself is in a hidden folder, `.claude/`, and your project's files appear beside the README as you work.

### Prefer Terminal?

Unzip and rename as above, then:

```bash
cd path/to/lending-log
claude
```

and type `/pack`.

### If something goes wrong

| What you see | What it means |
|---|---|
| `/pack` isn't offered | Claude Code is open in a different folder. Choose the project folder itself — the one with this README in it |
| Claude asks permission to create files | Normal on the first run. `/pack` writes the map, the compass and the camp folders into your project |
| Nothing happens when you type the command | Type `/` and Claude Code lists what it has. The forest ones are `/pack`, `/trail`, `/compass`, `/map` |
| You can't see the `.claude` folder | It is hidden on purpose. You never need to open it |

## Your first session

It takes twenty to forty minutes and you only do it once.

1. **Who you are.** Your role, whether this is your own idea or work for someone else, and how much explanation you want with each question. Answers go in `.forest/role.md` and set the tone for everything after.
2. **Who it is for.** The question the rest of the trail rests on: name one real person whose day this makes better. A category gets pushed back. "I don't know yet, Camp 2 will find out" is a real answer and gets filed as one.
3. **What you are building.** One sentence if you have it. If you don't, there is a short hunt that usually shakes something loose. If you already have a brief, a PRD or old research, point `/pack` at them instead. It places each document in the camp it belongs to and ticks only what the documents support. An inherited PRD counts as `assumed` until it is sourced, the same as anything you wrote yourself.
4. **Where you land.** Camp 1, with `project/map.md` and `project/compass.json` filled in as far as they can be. Type `/trail` to carry on.

From then on you need two commands: `/trail` to continue, and `/pack` never again on this project.

## The six camps

| Camp | What happens | What lands |
|---|---|---|
| **1 · Intake** | The idea, the constraint, the why-now | `project/1-intake/` |
| **2 · Discover** | Real conversations, then synthesis | `project/research/`, `project/2-discover/` |
| **3 · Define** | Narrow to a product. Cut what isn't v1 | `project/3-define/` |
| **4 · Design** | Tokens derived from your references, and the voice | `project/design/design.md`, `project/decisions/` |
| **5 · Build** | A brief, then the build in phases | `project/BRIEF.md`, your repo |
| **6 · Ship** | Quality, commit, push, verify | `project/SUMMIT.md` |

Camp 6 is the camp and `/ship` is the first of four commands inside it. Shipping is not the last thing that happens. See [After you ship](#after-you-ship).

**Moving between them.** `/trail` takes the camps in order and runs the right skill at each. `/compass` tells you the next step. `/map` shows where you are. `/camp <name>` jumps out of order when you have reason to.

Twenty-four commands exist. You need two: `/pack`, then `/trail`. The rest run when they apply, or are offered at the point they make sense. Full list in [`NAMING.md`](./.claude/forest/NAMING.md).

**Nine times on the trail** the kit stops and asks something awkward. What evidence you have. What you would cut if you had to halve the scope. What you expect to regret in three weeks. Each one says why it is asking, and "not sure yet" is accepted.

## The gate

When Camp 2 closes, `/weather` does five things.

1. **Asks for your stopping rule first**, before it opens the evidence. A stopping condition written after you have seen the verdict is not a stopping condition.
2. **Tags every claim by source.** `observed`, `said`, `inferred`, `assumed`. A claim sourced to "users I spoke to", with no name and no date, is `assumed`. So is anything the kit itself wrote earlier in the project.
3. **Names the load-bearing claim.** The one that, if false, takes everything else with it.
4. **Argues the other side.** They are coping. They would say yes and do nothing. The substitute already exists. You interviewed the wrong people.
5. **Returns press on, reroute or turn back**, with at least two routes either way.

You can override it. An override is filed as a decision and quoted back at you before you ship.

**Run it again after launch.** What people actually do once the thing is live counts as `observed`, which outranks everything gathered before it. `/weather` keeps both readings.

## What you end up with

```
my-idea/
├── README.md                 how forest works, and where everything is
├── project/                  everything forest writes for you
│   ├── map.md                  where you are on the trail
│   ├── compass.json            the project's direction. Every step reads it
│   ├── BRIEF.md                hand this to whoever builds it
│   ├── EVIDENCE.md             what you know, and how you know it
│   ├── SUMMIT.md               what went live, plus three questions dated ninety days out
│   ├── retro.md                what worked, what did not, what to keep
│   ├── HANDOFF.md · handoff/   client projects only
│   ├── 1-intake/ … 6-ship/     each camp's working files
│   ├── research/               your notes from talking to people
│   ├── decisions/              one file per call, with the reasoning
│   ├── design/                 the design system (design.md)
│   └── memory/                 one line per session. Local to your machine
├── app/                      the product itself, built in Camp 5
├── .forest/role.md           who you are and how much explanation you want. Local to your machine
└── .claude/                  forest itself. Hidden; you never need to open it
```

Plain markdown and one JSON file. Readable at any point, and yours to keep.

### What to do with them

| File | When you open it | What you do |
|---|---|---|
| `project/BRIEF.md` | When you are ready to build | Hand it to Claude Code in the same folder, to Claude in the browser, to v0 or Figma Make, or to a developer. [`BUILDING.md`](./BUILDING.md) has the prompts for each |
| `project/EVIDENCE.md` | When someone asks why this is worth doing | Send it. It is written for a reader who was not there |
| `project/design/design.md` | Every time something gets built | The tokens are the spec, written in [Google's design.md format](https://github.com/google-labs-code/design.md) so any tool that reads it can use them. `/camp build` checks the result against them and lists what diverged |
| `project/3-define/prd.md` | When a build question needs a ruling | The in, out and later lists settle it |
| `project/decisions/` | When someone reopens a settled argument | One file per call. Point at the file rather than re-arguing |
| `project/map.md` | Any session | Where you are, what is left, which phases have shipped |
| `project/compass.json` | Rarely by hand | Every skill reads it. Edit it if something changed and no skill caught it |
| `project/SUMMIT.md` | Ninety days after launch | Answer the three questions cold, before re-reading the rest |
| `project/retro.md` | Before you start the next thing | Three lessons, written while it is still fresh |
| `project/HANDOFF.md` | At client delivery | The document they read to carry on without you |

## Building it

Camp 5 compiles everything upstream into `project/BRIEF.md`. Scope, with the out list kept word for word. Phases you could ship on their own. How it should feel, the decisions already made, and what is still missing.

That one file is what you hand over. Ask for it earlier if you want to commission design or development before Camp 5.

**Claude Code, in the same folder.** Type `/camp build` and it works the phases itself. It takes the first one not ticked, reads the requirement in the PRD, builds it, reads the work back for bugs, checks it against the design, commits, ticks it off and moves on.

One at a time or straight through, your choice at the start. It stops when a phase needs a decision the brief does not answer. It never pushes.

**Claude in the browser, or Claude Design.** Attach `project/BRIEF.md` and `project/design/design.md`, then ask for phase 1 as an artifact. Tell it to use the tokens exactly and not to add anything outside the scope list.

**v0, Lovable, Bolt, Figma Make.** These want a prompt rather than a document. Paste the brief's first three sections and the phase you want.

**A developer or an agency.** Send `project/BRIEF.md`, `design.md` and `prd.md`, and point them at the decisions section before they start. For a client handover use `/handoff` instead, which packages the lot and verifies the access transfers.

Whoever does the building, each phase is compared with `design.md` and every divergence named, so drift gets caught while it is one component rather than twenty.

**[`BUILDING.md`](./BUILDING.md) has the full prompts for each tool**, which files to send and which to hold back, and what to do when what comes back is not what you wanted.

## While you build

Camp 5 doesn't only build. Each phase ends with `/review`, the studio's five-check quality pass, and `/test`, which writes and runs the tests for that phase. Both present findings first and change nothing until you say yes.

When something specific needs work, there is a command for it: `/refine` to harden, optimise, adapt, clarify or onboard; `/tune` to push the design bolder, quieter, colourise or normalise; `/motion`, `/animate` and `/overdrive` for movement; `/system` to document the design system as built. Before the summit, `/a11y-audit` audits accessibility against a real standard. All of them follow k-d studio's own design, brand, motion and stack standards, which come in the folder.

## After you ship

Shipping is not the last step. Camp 6 has four commands and `/ship` is the first.

1. **`/ship`** runs the quality checks, commits and pushes. It does not deploy unless the project is already set up to deploy on push.
2. **`/summit`** verifies what actually went live: analytics, metadata, performance, accessibility. Writes `project/SUMMIT.md`.
3. **`/retro`** records what worked and what did not, and three things to keep for next time.
4. **`/handoff`**, on client projects, packages the folder and verifies the access transfers.

None of these runs automatically. You pick the moment.

Then two things are left.

**Ninety days on.** `project/SUMMIT.md` carries three questions dated three months from the day you shipped. The first asks whose life is measurably different, and whether it was the person you named at intake. Answering is manual and there is no command for it. `/summit` will offer to set a reminder if your setup has a scheduling skill, or tell you to put one in your calendar.

**A second version.** When you come back, `/pack` opens cycle 2 on the same project. It archives the previous map and retro rather than deleting them, carries the beneficiary, research, decisions and design across, and resets only the camp progress. It reads the last retro's first lesson back to you before you start.

If the project stops instead, that is a recorded outcome. `/retro` runs on a parked project and asks what stopped it, what would have to be true to restart it, and what is worth keeping.

## Reference

Six files govern every skill. Read them if you want to know why it behaves as it does.

| File | Governs |
|---|---|
| [`PURPOSE.md`](./.claude/forest/references/PURPOSE.md) | Why this exists. Read first |
| [`QUESTIONING.md`](./.claude/forest/references/QUESTIONING.md) | How questions are asked, and the three style modes |
| [`CHALLENGE.md`](./.claude/forest/references/CHALLENGE.md) | When it pushes back. Challenges always advance; the gate doesn't |
| [`TEXTURE.md`](./.claude/forest/references/TEXTURE.md) | How moments earn weight. Never celebratory |
| [`BRIDGES.md`](./.claude/forest/references/BRIDGES.md) | When it sends you out: interviews, Figma, infrastructure |
| [`STATE.md`](./.claude/forest/references/STATE.md) | Where the project is, its status, and which two skills may move it |

Twenty-four commands and one gate make the twenty-five skills in `.claude/skills/`. The design standards they follow are in `.claude/forest/taste/`. `/weather` counts as a gate rather than a command because the trail fires it at you, so you never have to remember it. Vocabulary is in [`NAMING.md`](./.claude/forest/NAMING.md). The design, brand, motion and stack standards are k-d studio's own, in [`.claude/forest/taste/`](./.claude/forest/taste/).

## License

Free to use, including for your own commercial products. Not to copy, modify, redistribute, resell, or use to train AI. See [LICENSE](./LICENSE). Built by k-d studio.
